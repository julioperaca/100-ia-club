# design-system

Skill para o personal trainer montar a identidade visual da marca em cerca de 40 minutos, sem Figma, sem Canva e sem instalar nada.

## Como usar

No Claude Code, digite `/design-system` ou fale "monta minha identidade visual", "quais são minhas cores", "cara da minha marca".

Para mudar algo depois: `/design-system ajusta: quero o rosa mais vivo`.

## Antes

A skill `brain` precisa ter rodado: é de lá que vêm sua voz, sua aluna ideal e as pistas de cor. Sem a pasta `brain`, a skill avisa e para.

## O que ela faz

1. Lê seus prints do Instagram, logo e fotos (arrasta para a conversa ou põe na pasta `arquivos`). Se você não tem nada pronto, pede prints de perfis e paletas de que você gosta e cria a sua identidade a partir deles. Ensina passo a passo a tirar print, salvar imagem e mandar para o Claude.
2. Propõe paleta, 2 fontes do Google Fonts, estilo de foto, tom visual e regras de carrossel, story e página.
3. Abre no navegador uma prévia com capa de carrossel, story e topo de página de vendas com o seu nome e o seu texto.
4. Ajusta com você em até 3 voltas.
5. Salva tudo em `brain/identidade-visual.md` (com o bloco de tokens que as outras skills leem) e a prévia em `brain/identidade-visual.html`.

## Instalação

Copie a pasta `design-system` para `~/.claude/skills/` (no Windows, `C:\Users\<nome>\.claude\skills\`).

## Arquivos

| Arquivo | Para quê |
|---|---|
| `SKILL.md` | entrada, modos, contrato com o segundo cérebro, regras |
| `etapas/1-coletar.md` a `etapas/5-salvar.md` | as 5 etapas |
| `referencias/guia-de-escolhas.md` | cor, contraste, pares de fontes, regras das peças, não faça |
| `modelos/identidade-visual.html` | a prévia (só o bloco DADOS muda) |
| `modelos/identidade-visual-preenchido.md` | formato final do arquivo, com o bloco de tokens |
| `modelos/identidade-visual-vazio.md` | modelo vazio, igual ao da skill brain |

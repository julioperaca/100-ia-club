# Identidade visual

> O que é: cores, fontes, logo e estilo das suas peças. Quem preenche é a skill de design system.
> Última atualização: [dd/mm/aaaa]
> Status: [completo | em andamento]
> O que falta: [nada | o que falta]

## Cores

- primária: [nome simples] [#HEX]. Para: títulos de destaque, botões, capa. Com letra [branca | escura], leitura [ótima | boa] ([contraste]). ([fonte, ex.: apresentacao-programa.pdf, cor aproximada; proposta aprovada na conversa, dd/mm/aaaa])
- secundária: [nome] [#HEX]. Para: [uso]. ([fonte])
- destaque: [nome] [#HEX]. Para: detalhes pequenos (número, selo, sublinhado). Nunca em texto longo. ([fonte])
- fundo: [nome] [#HEX]. Para: fundo principal das peças e da página. ([fonte])
- fundo alternativo: [nome] [#HEX]. Para: fundo de seção e de cartão. ([fonte])
- texto: [nome] [#HEX]. Para: todo texto sobre fundo claro. ([fonte])
- texto suave: [nome] [#HEX]. Para: legenda, data, observação. ([fonte])
- Proporção nas peças: cerca de 60% fundo, 30% primária ou secundária, 10% destaque.

## Fontes

- títulos: [Família], pesos [700 e 800]. Por quê: [uma frase]. ([fonte])
- textos: [Família], pesos [400 e 700]. Por quê: [uma frase]. ([fonte])
- Link do Google Fonts: [url]
- Tamanho mínimo de texto numa peça de 1080 px: [32 ou 36] px.

## Logo

- [arquivos/logo.png: funciona em fundo claro e escuro; largura mínima 120 px; espaço livre em volta igual à altura de uma letra.] ou [Sem logo por enquanto: nome "[nome_publico]" escrito em [fonte de título], peso [x], na cor [primária | texto].] ([fonte])

## Estilo de foto e imagem

- [luz] ([fonte])
- [cenário] ([fonte])
- [enquadramento e clima] ([fonte])

## Referências que eu gosto

- [perfil ou print citado, ou "a confirmar"] ([fonte])

## Pistas encontradas nos seus arquivos

(O que já estava aqui continua igual. Pista que virou decisão ganha no fim "(usada na paleta, dd/mm/aaaa)".)

## Tom visual

- [adjetivo 1], [adjetivo 2], [adjetivo 3]. ([de onde veio cada um, ex.: voz.md, Tom; aluno-ideal.md, Ponto B])

## Carrossel (1080 x 1350)

- Capa: fundo [primária], título em [fonte título] [peso], até 8 palavras, cor [texto_sobre_primaria]; barrinha na cor destaque; @ no topo.
- Miolo: fundo [fundo], 1 ideia por slide, até 30 palavras; número do slide na cor [destaque ou primária].
- Último slide: fundo [secundária], chamada para ação ("[CTA na voz da pessoa]") e botão [primária] com cantos [raio botao].
- Margem de 80 px em todos os lados. Título longe das bordas laterais.

## Stories (1080 x 1920)

- Fundo [secundária] ou foto com camada [secundária] por cima.
- Topo (250 px) e base (340 px) livres.
- Uma mensagem por story, título com até 6 palavras; caixinha de pergunta com cabeçalho [primária].

## Página de vendas (topo)

- Fundo [fundo alternativo], selo [secundária], título em [fonte título] com 2 a 4 palavras em [primária], subtítulo em [texto suave].
- Botão [primária] com texto [texto_sobre_primaria], cantos [raio botao]. Foto da pessoa ao lado (no celular, embaixo).

## Não faça

- [5 a 8 itens]

## Tokens (para as outras skills)

Valores prontos para a skill de conteúdo e as que vierem depois. Não mude à mão: peça "/design-system ajusta: ...".

```json
{
  "cores": {
    "primaria": "#C2185B",
    "secundaria": "#4A1942",
    "destaque": "#FFB74D",
    "fundo": "#FFF8F3",
    "fundo_alternativo": "#F8E9EE",
    "texto": "#2B1B27",
    "texto_suave": "#6E5A66",
    "texto_sobre_primaria": "#FFFFFF",
    "texto_sobre_secundaria": "#FFFFFF"
  },
  "fontes": {
    "titulo": { "familia": "Poppins", "pesos": [700, 800] },
    "texto": { "familia": "Nunito Sans", "pesos": [400, 700] },
    "google_fonts": "https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Nunito+Sans:wght@400;700&display=swap"
  },
  "raios": { "pequeno": "8px", "medio": "16px", "pilula": "999px", "botao": "999px" },
  "espacos": { "base": "8px", "escala": [4, 8, 12, 16, 24, 32, 48, 64] },
  "pecas_1080": { "titulo_capa": "96px", "titulo": "64px", "texto": "36px", "texto_minimo": "32px", "margem": "80px" },
  "formatos": { "carrossel": "1080x1350", "story": "1080x1920", "story_area_livre": "topo 250px, base 340px" }
}
```

(Os valores acima são só exemplo de formato. As chaves são sempre estas.)

## Histórico de mudanças

- [dd/mm/aaaa]: primeira versão (skill design-system).

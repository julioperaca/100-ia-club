# Guia de escolhas

Base para a etapa 2. Adaptado do processo de identidade visual de Alina Wheeler (pesquisa, estratégia, design, pontos de contato, gestão), reduzido ao que um personal trainer usa no Instagram e numa página de vendas.

Regra mãe: design sem estratégia é decoração. Toda escolha responde "por que isso combina com a sua voz e com a sua aluna?".

## 1. Cor

### Quantas cores
- 1 primária, 1 secundária, 1 destaque, 2 fundos, 2 textos. Mais que isso vira bagunça no feed.
- Proporção nas peças: cerca de 60% fundo, 30% primária ou secundária, 10% destaque.

### O que cada cor costuma passar (use como ponto de partida, não como lei)
| Cor | Sensação comum | Cuidado |
|---|---|---|
| rosa e vinho | acolhimento, feminino, cuidado | rosa claro demais some no celular |
| laranja e coral | energia, alegria, ação | laranja claro com letra branca fica ilegível |
| vermelho | urgência, força | em excesso parece promoção |
| verde | saúde, leveza, natureza | verde-limão cansa a vista |
| azul | confiança, calma, técnica | azul médio é a cor mais comum do nicho, diferencia pouco |
| roxo e ameixa | sofisticação, transformação | escuro demais parece triste se não tiver um destaque vivo |
| preto e grafite | força, premium | precisa de uma cor viva junto, senão fica pesado |
| amarelo e mostarda | otimismo | nunca como cor de texto sobre branco |

### Contraste (o quanto o texto se destaca do fundo)
Calcule, não chute. Para cada cor em HEX:
1. Separe em três partes (R, G, B) e divida cada uma por 255.
2. Para cada parte c: se c for até 0,04045, use c / 12,92; se for maior, use ((c + 0,055) / 1,055) elevado a 2,4.
3. Luminância L = 0,2126 R + 0,7152 G + 0,0722 B.
4. Contraste = (L da mais clara + 0,05) / (L da mais escura + 0,05).

Mínimos:
- texto comum (legenda, parágrafo, botão): 4,5 ou mais;
- título grande (a partir de cerca de 40 px na peça de 1080): 3 ou mais.

Referências rápidas: branco sobre #C2185B dá cerca de 5,9; branco sobre #E91E63 dá cerca de 4,4 (não passa para texto comum); branco sobre #FF9800 dá cerca de 2,2 (não passa nunca). A prévia HTML recalcula e mostra um selo em cada par, então confira lá também.

### Cor lida de imagem
É aproximada. Print, filtro e tela mudam a cor. Escreva sempre "aproximado" e, se a pessoa souber o código exato (do Canva antigo, da gráfica, do designer), use o dela.

## 2. Fontes (só Google Fonts)

Todas abaixo têm acentos do português e são grátis. Escolha um par pelo tom.

| Tom | Título (pesos) | Texto (pesos) | Por que funciona |
|---|---|---|---|
| acolhedor e leve | Poppins (700, 800) | Nunito Sans (400, 700) | redondas, simpáticas, fáceis de ler no celular |
| acolhedor e elegante | DM Serif Display (400) | DM Sans (400, 700) | serifa delicada no título, texto limpo |
| enérgico e forte | Anton (400) | Inter (400, 700) | título alto e condensado, cabe muita força em pouco espaço |
| enérgico e esportivo | Bebas Neue (400) | Montserrat (400, 700) | cara de esporte; Bebas só tem maiúsculas |
| direto e moderno | Montserrat (800, 900) | Open Sans (400, 700) | o clássico que não erra |
| moderno e técnico | Sora (700, 800) | Inter (400, 600) | geométrica, passa método e precisão |
| premium e sofisticado | Playfair Display (700, 800) | Lato (400, 700) | contraste de serifa clássica com texto neutro |
| firme e confiável | Archivo Black (400) | Archivo (400, 600) | mesma família, consistência total |

Regras:
- No máximo 2 fontes. Variação vem de peso e tamanho, não de fonte nova.
- Só fonte do Google Fonts, com o nome exato de lá. Fonte do Canva ou paga não carrega nas imagens e a peça sai com fonte padrão. Parecidas no Google Fonts: Glacial Indifference ou Canva Sans vira Poppins ou Nunito Sans; Futura vira Jost; Gotham vira Montserrat; Avenir vira Nunito Sans; Helvetica ou Arial vira Inter; Brandon Grotesque vira Josefin Sans; Bodoni ou Didot vira Playfair Display.
- O link `google_fonts` dos tokens leva as duas famílias com os pesos escolhidos (nome com espaço vira `+`), ex.: `https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Nunito+Sans:wght@400;700&display=swap`.
- Fonte cursiva ou muito fina só em detalhe pequeno, nunca em texto.
- Tamanho mínimo de texto numa peça de 1080 px de largura: 32 px. Para aluna acima de 40 anos, 36 px.

## 3. Foto e imagem
- Foto real da pessoa vence banco de imagem. Banco de imagem de academia parece anúncio genérico.
- A foto mostra a vida da aluna ideal (casa, parque, academia de bairro) e não a vida de atleta, a menos que a aluna seja atleta.
- Luz natural ou de janela; evite flash direto.
- Coerência: o mesmo tratamento em todas (todas mais quentes, ou todas naturais). Nada de filtro diferente a cada post.
- Foto de aluna (antes e depois, treino) só com autorização registrada em `cases.md`.

## 4. Pontos de contato (as peças)

### Carrossel (1080 x 1350, formato 4:5)
- Capa: fundo primária ou secundária (ou foto com faixa escura), título com até 8 palavras, fonte de título no peso mais forte, nome ou @ pequeno no rodapé. Mantenha o título longe das bordas laterais: o perfil mostra a capa um pouco cortada dos lados.
- Miolo: fundo claro, 1 ideia por slide, até 30 palavras, número do slide ou marcador na cor destaque.
- Último slide: chamada para ação clara ("Chama no direct", "Link na bio", "Salva este post"), fundo primária ou secundária, botão desenhado com raio da marca.
- Margem interna de pelo menos 80 px em todos os lados.

### Story (1080 x 1920, formato 9:16)
- Deixe livre o topo (cerca de 250 px) e a base (cerca de 340 px): o Instagram coloca foto de perfil, barra e campo de resposta ali.
- Uma mensagem por story. Texto grande, no máximo 3 linhas de título.
- Fundo secundária ou foto; caixa de pergunta ou enquete na cor primária.

### Topo de página de vendas
- Fundo fundo ou secundária, título com a promessa na fonte de título, subtítulo na fonte de texto, um botão primária com texto_sobre_primaria, foto da pessoa ao lado (no celular, embaixo).
- Botão com cantos no raio da marca e texto de ação ("Quero minha vaga", "Falar no WhatsApp").

## 5. Raios e espaços (para os tokens)
- Raio pequeno 8 px (selos, campos), médio 16 px (cartões, botões), pílula 999 px (botão redondo).
- Tom acolhedor e leve: botões em pílula. Tom firme e técnico: raio médio ou pequeno.
- Espaçamento em múltiplos de 8: 4, 8, 12, 16, 24, 32, 48, 64.

## 6. Não faça (lista base, escolha os que se aplicam)
1. Mais de 2 fontes na mesma peça.
2. Texto sobre foto sem faixa ou sombra que garanta leitura.
3. Cor de destaque em parágrafo inteiro.
4. Letra branca sobre cor clara (amarelo, rosa claro, laranja claro).
5. Logo esticado, girado ou com sombra.
6. Filtro diferente a cada post.
7. Foto de banco de imagem de academia quando a aluna treina em casa.
8. Capa de carrossel com mais de 8 palavras no título.
9. Preto puro com cinza claro fino para texto longo (cansa a vista).
10. Peças com cores fora da paleta "só dessa vez".

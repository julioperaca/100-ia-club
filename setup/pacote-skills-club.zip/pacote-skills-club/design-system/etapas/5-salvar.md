# Etapa 5. Salvar no segundo cérebro

Tempo no encontro: 5 minutos.

O formato final está em `${CLAUDE_SKILL_DIR}/modelos/identidade-visual-preenchido.md`. Leia antes de gravar e siga a mesma ordem de seções.

## Passo 1. Preencher sem apagar

`<pasta>/identidade-visual.md` já existe (veio da skill brain). Use Edit, seção por seção:

1. **Cabeçalho**: atualize `Última atualização` (hoje), `Status` (completo se a pessoa aprovou; em andamento se não) e `O que falta` (ex.: "logo"; ou "nada" quando completo). Mantenha `O que é`.
2. **Cores**: troque a linha de exemplo entre parênteses pela lista das 7 cores (nome, HEX, para que serve, fonte). Se a cor veio de imagem, escreva "aproximado".
3. **Fontes**: as 2 fontes com pesos e para que serve cada uma, mais o link do Google Fonts.
4. **Logo**: caminho do arquivo em `arquivos/` e as regras de uso; ou "sem logo por enquanto: nome escrito em [fonte], peso [x], na cor [y]".
5. **Estilo de foto e imagem**: os itens da etapa 2.
6. **Referências que eu gosto**: perfis ou prints que a pessoa citou como bonitos, com fonte. Se não citou, "a confirmar".
7. **Pistas encontradas nos seus arquivos**: não apague nada que já está lá. Se uma pista virou decisão, acrescente no fim da linha "(usada na paleta, dd/mm/aaaa)". Se você achou pistas novas na etapa 1, acrescente com fonte.
8. Depois das seções do modelo, acrescente as seções novas na ordem do modelo preenchido: Tom visual, Carrossel, Stories, Página de vendas, Não faça, Tokens, Histórico de mudanças.

Se uma seção nova já existe (a skill já rodou antes), não duplique: edite dentro dela. Valor que mudou vira linha no Histórico de mudanças: "dd/mm/aaaa: primária de #C2185B para #D81B60 (pediu rosa mais vivo, conversa)".

## Passo 2. O bloco de tokens

Na seção `## Tokens (para as outras skills)`, um bloco de código `json` com exatamente o mesmo conteúdo do campo `tokens` do `DADOS` no HTML. É isso que a skill de conteúdo e as que vierem depois leem direto, então:
- chaves sempre com os mesmos nomes do modelo (não traduza, não invente chave nova);
- cores em HEX de 6 dígitos com `#`;
- tamanhos e raios com `px`;
- JSON válido (aspas duplas, sem vírgula sobrando, sem comentário dentro);
- `fontes` completo: `fontes.titulo.familia`, `fontes.texto.familia` e `fontes.google_fonts`, com famílias do Google Fonts escritas igual ao Google Fonts e o link contendo as duas (nome com espaço vira `+`). Fonte do Canva ou paga não entra: troque pela mais parecida do Google Fonts (veja o guia) e avise em uma linha.

Se o bloco já existe, substitua só o conteúdo dele por Edit e registre a mudança no Histórico.

## Passo 3. Conferir

- Releia o arquivo gravado e confira que nenhuma seção antiga sumiu (compare com a lista de seções do modelo).
- Grep no `.md` e no `.html` pelos dois tipos de travessão (caracteres Unicode U+2014 e U+2013): zero.
- Os HEX do bloco de tokens são iguais aos da seção Cores e aos do HTML.
- O bloco de tokens tem `fontes.titulo.familia`, `fontes.texto.familia` e `fontes.google_fonts`, e o link tem `family=` das duas famílias. Faltou algo: corrija antes de fechar.

## Salvar no meio

Se a pessoa precisar parar antes do fim, grave o que já foi decidido (mesmo só a paleta) com `Status: em andamento` e, em "O que falta", as etapas que faltam ("fontes, regras das peças, aprovação"). Na próxima vez a skill continua dali.

## Fechamento (na conversa)

> Pronto, sua identidade visual está no segundo cérebro.
> 1. Cores: [primária] e [secundária], com [destaque] nos detalhes.
> 2. Letras: [fonte título] nos títulos, [fonte texto] nos textos.
> 3. Tom: [adjetivo 1], [adjetivo 2], [adjetivo 3].
> 4. Prévia: identidade-visual.html, na pasta brain (dois cliques para abrir).
> 5. A skill de conteúdo já vai usar isso sozinha.
> 6. Para mudar algo depois: "/design-system ajusta: [o que mudar]".
>
> Próximo passo: pedir seu primeiro carrossel na skill de conteúdo e ver tudo aplicado.

# Etapa 1. Coletar o que já existe

Tempo no encontro: 10 minutos.

Objetivo: entender a cara que a marca já tem hoje, antes de propor qualquer coisa. Muita gente já tem uma cor que repete sem perceber; a gente parte dela.

## Passo 1. Ler o contexto (sem perguntar nada)

Leia, nesta ordem, só o necessário:
1. `<pasta>/identidade-visual.md`: tudo, com atenção à seção "Pistas encontradas nos seus arquivos".
2. `<pasta>/voz.md`: seções Tom, Expressões e Textos reais.
3. `<pasta>/aluno-ideal.md`: Quem é, Ponto A e Ponto B.
4. `<pasta>/negocio.md`: nome do programa, produtos, provas.
5. `<pasta>/perfil-profissional.md`: as linhas `nome_publico` e `instagram`.
6. `<pasta>/cases.md`: só os cases com `autorização para uso público: sim`.

Se `voz.md` ou `aluno-ideal.md` estiverem com `Status: vazio`, avise em uma linha ("Sua voz ainda está vazia no segundo cérebro; vou propor com base no que tenho e você confere") e siga. Não pare por isso.

## Passo 2. Pedir as imagens, ensinando como

A maioria dos personais nunca mexeu com isso. Todo pedido vai em passo a passo numerado, simples, como se a pessoa nunca tivesse feito. Uma etapa por vez: peça, espere, confira o que chegou e só então siga.

**2a. O que a pessoa já tem.** Mande primeiro:

> Agora me mostra a cara da sua marca hoje. Pode ser qualquer um destes, o que você tiver:
> 1. Print do seu feed do Instagram (a grade de fotos do perfil).
> 2. Print dos destaques (as bolinhas abaixo da bio).
> 3. Print de 2 ou 3 posts que foram bem.
> 4. Seu logo, se tiver (PNG ou PDF).
> 5. Uma ou duas fotos suas que você gosta (de corpo ou rosto, boa luz).
>
> Não sabe tirar print ou mandar para cá? Me fala "me ensina" que eu te mostro passo a passo.

**2b. Como conseguir e mandar as imagens.** Mostre só se a pessoa pedir ajuda, travar ou mandar errado. Mostre só a parte do aparelho que a pessoa usa (pergunte "você está no celular ou no computador?" se não souber).

> Para tirar print no celular:
> 1. Abra o Instagram e vá na tela que você quer mostrar (seu perfil, um post, um perfil que você gosta).
> 2. iPhone: aperte ao mesmo tempo o botão de ligar e o de aumentar o volume. Android: aperte ao mesmo tempo o botão de ligar e o de abaixar o volume.
> 3. A tela pisca e o print vai para a sua galeria de fotos.
>
> Para salvar uma imagem que você gostou (Pinterest, Google, site):
> 1. Celular: segure o dedo em cima da imagem e toque em "Salvar imagem" ou "Baixar imagem".
> 2. Computador: clique com o botão direito em cima da imagem e escolha "Salvar imagem como". Salve na Área de Trabalho, que é fácil de achar.
>
> Para mandar para mim no Claude Desktop (computador):
> 1. Se o print está no celular, passe para o computador: mande para você mesmo pelo WhatsApp Web ou por e-mail e baixe no computador.
> 2. Abra a pasta onde a imagem está (Área de Trabalho ou Downloads).
> 3. Clique na imagem, segure o botão do mouse e arraste até a caixa de mensagem aqui do Claude. Solte quando a caixa ficar destacada.
> 4. Pode arrastar várias de uma vez. Depois escreva "pronto" e envie.
>
> Se preferir, em vez de arrastar, coloque as imagens na pasta `arquivos` do seu segundo cérebro (pasta brain). Logo e fotos suas, de preferência lá, porque a prévia vai usar.

**2c. Se a pessoa não tiver material pronto (ou tiver pouco).** Não crie do zero ainda. Peça referências de que a pessoa gosta, que viram a base da proposta. Mande:

> Sem problema, a gente monta a sua identidade a partir do que você gosta. Me manda, do jeito que te ensinei acima:
> 1. Print de 2 ou 3 perfis do Instagram que você acha bonitos (de qualquer área, não precisa ser de personal).
> 2. Print de 2 ou 3 posts que chamaram sua atenção pelo visual.
> 3. Se tiver, uma imagem de cores que você gosta: pode ser uma paleta do Pinterest (pesquise "paleta de cores" mais a cor que você curte, ex.: "paleta de cores verde"), uma foto, uma roupa, um lugar.
> 4. Me diz em uma frase: tem alguma cor que você ama e alguma que você não quer de jeito nenhum?

Se mesmo assim a pessoa não tiver nada: tudo bem. Siga para a etapa 2 só com voz, aluno ideal e pistas. Diga: "Sem problema, vou criar do zero a partir de como você fala e de quem é sua aluna. Você vai ver pronto e me diz o que mudar."

Referência de outro perfil serve de inspiração (clima, tipo de cor, peso de letra). Nunca copie a paleta inteira nem a cara de outro perfil: a proposta tem de ser da pessoa.

## Passo 3. Listar o que tem na pasta

Glob em `<pasta>/arquivos/**/*`. Separe:
- imagens (.png, .jpg, .jpeg, .webp, .heic) e PDFs que pareçam visuais (apresentação, logo, post);
- logo: nome com "logo", "marca" ou imagem só com nome e símbolo em fundo liso;
- fotos da pessoa: nome com "foto", "perfil", "eu", ou imagem que mostra a própria pessoa (confirme na conversa).

Não leia de novo textos que a skill brain já leu, a não ser que sejam visuais.

## Passo 4. Olhar cada imagem (Read)

Para cada imagem ou print, anote em rascunho (ainda não grave):

| O que olhar | Como anotar |
|---|---|
| Cores que se repetem (fundo, títulos, destaques, botões) | nome simples + código HEX aproximado, ex.: "rosa escuro, cerca de #C2185B" |
| Fontes aparentes | descreva o tipo: "título grosso sem serifa, tipo Montserrat", "letra cursiva", "fina e elegante com serifa". Nunca afirme o nome exato da fonte; diga "parecida com" |
| Estilo de foto | luz (natural, estúdio, academia), cenário (casa, parque, academia), enquadramento (corpo inteiro, rosto), clima (sorrindo, treinando, séria) |
| Estilo dos posts | fundo liso ou foto, muito texto ou pouco, bordas arredondadas, ícones |
| O que funcionou | nos posts que foram bem, o que eles têm em comum visualmente |
| Logo | cores, se tem símbolo, se funciona em fundo escuro e claro |
| Referência de outro perfil ou paleta | o que a referência tem de bom para usar como inspiração: clima, família de cor, peso da letra. Marque como "referência", não como cor da marca |

Importante:
- O código HEX lido de imagem é sempre aproximado (print muda a cor, filtro muda a cor). Diga isso uma vez para a pessoa e marque cada um com "aproximado".
- Print com rosto ou nome de aluna: use só para cor e estilo. Não descreva a aluna, não anote o nome.
- Fonte de cada achado: nome do arquivo (ou "print colado na conversa, dd/mm/aaaa").

## Passo 5. Mostrar o que encontrou

Uma lista curta, no máximo 8 itens, cada um com a fonte. Exemplo:

> Olha o que eu vi:
> 1. O rosa escuro aparece no título da sua apresentação e em 3 dos 4 posts (cerca de #C2185B, aproximado). (apresentacao-programa.pdf; print-feed.png)
> 2. Seus destaques usam um rosa bem claro de fundo (cerca de #F8D7E3). (print-destaques.png)
> 3. O post que mais foi bem tem fundo escuro e letra grande branca. (print-post-top.png)
> 4. Suas fotos são em casa, luz de janela, você sorrindo. (foto-carla.jpg)
> 5. Não achei logo: vamos usar seu nome escrito na fonte de título.
>
> Tem alguma cor ou coisa aí que você odeia ou que é muito você?

Se a base veio de referências (2c), mostre o que você tirou delas do mesmo jeito, dizendo de qual print veio cada ideia.

Uma pergunta só. Anote a resposta com fonte "conversa, dd/mm/aaaa" e siga para a etapa 2.

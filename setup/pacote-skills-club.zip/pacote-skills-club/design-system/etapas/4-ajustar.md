# Etapa 4. Ajustar

Tempo no encontro: 10 minutos. No máximo 3 voltas.

## A pergunta

> Abri no seu navegador. Olha com calma a capa, o story e a página. Isso parece a sua marca? Me diz o que você mudaria, do jeito que vier: "rosa mais vivo", "letra mais fina", "não gostei do fundo escuro".

Uma pergunta só. Espere a resposta.

## Traduzir o pedido

A pessoa fala de sensação; você traduz em mudança concreta e diz o que vai fazer em uma linha antes de fazer.

| A pessoa diz | O que mudar |
|---|---|
| "mais vivo", "mais alegre" | aumentar saturação da primária ou do destaque, mantendo o contraste |
| "mais elegante", "mais sério" | escurecer a primária, trocar o par de fontes para um de tom premium ou elegante do guia |
| "mais leve", "menos pesado" | fundo mais claro, secundária mais clara ou menos usada, botão em pílula |
| "mais forte", "mais impacto" | título em fonte condensada ou peso maior, mais contraste, fundo escuro na capa |
| "não sou eu", "não gostei" sem detalhe | pergunte só: "o que incomodou mais: as cores, as letras ou o estilo das peças?" |
| "gostei", "é isso", "perfeito" | encerre as voltas e vá para a etapa 5 |

Regras:
1. Mude só o que foi pedido. Não aproveite para mexer em outra coisa.
2. Toda cor nova passa de novo pelo contraste (fórmula do guia). Se o pedido deixa ilegível ("letra branca no amarelo"), explique em uma frase e ofereça a alternativa mais próxima que funciona.
3. Atualize o bloco `DADOS` no `identidade-visual.html` (Edit) e abra de novo no navegador.
4. Anote cada volta num rascunho: o que mudou, de quanto para quanto, e o motivo dito pela pessoa. Isso vai para o "Histórico de mudanças" na etapa 5.

## Depois da terceira volta

Se ainda não está bom, não insista em voltas pequenas:

> A gente já fez 3 ajustes. Vou salvar como está, marcado como "em andamento". Na próxima vez, traz 2 ou 3 prints de perfis que você acha lindos (de qualquer área) e a gente parte deles. Se precisar, eu te ensino de novo, passo a passo, a tirar o print e mandar aqui.

Salve com `Status: em andamento` e, em "O que falta", escreva o que ainda incomoda.

## Modo Ajustar (quando a skill é chamada com "ajusta: ...")

1. Leia `<pasta>/identidade-visual.md` inteiro, inclusive o bloco de tokens.
2. Faça só o ajuste pedido em `$ARGUMENTS`, com a mesma tabela e as mesmas regras acima.
3. Se `<pasta>/identidade-visual.html` existe, atualize o bloco `DADOS` e abra no navegador. Se não existe, monte pela etapa 3.
4. Pergunte uma vez: "Ficou como você queria?" e siga para a etapa 5.

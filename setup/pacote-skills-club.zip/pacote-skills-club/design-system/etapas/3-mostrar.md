# Etapa 3. Mostrar no navegador

Tempo no encontro: 5 minutos.

## Passo 1. Montar a página

1. Leia `${CLAUDE_SKILL_DIR}/modelos/identidade-visual.html`.
2. Se `<pasta>/identidade-visual.html` já existe, copie-o antes para `<pasta>/identidade-visual-anterior.html` (Read e Write). Nunca perca a versão anterior.
3. Grave `<pasta>/identidade-visual.html` com o conteúdo do modelo, trocando **só** o bloco entre `/* DADOS INICIO` e `/* DADOS FIM */`. O resto do arquivo fica igual.

Como preencher o bloco `DADOS`:

| Campo | O que vai |
|---|---|
| `nome` | `nome_publico` do perfil-profissional.md |
| `instagram` | `instagram` do perfil-profissional.md (com @) |
| `programa` | nome do programa em negocio.md; se não houver, "Programa Personalizado" |
| `data` | hoje, dd/mm/aaaa |
| `adjetivos` | os 3 adjetivos da etapa 2 |
| `logo` | caminho relativo do logo a partir da pasta, ex.: `arquivos/logo.png`. Vazio se não tem logo (aí aparece o nome na fonte de título) |
| `foto` | caminho relativo de uma foto da pessoa, ex.: `arquivos/foto-carla.jpg`. Vazio se não tem (aparecem as iniciais) |
| `tokens` | exatamente o mesmo JSON que vai para o bloco de tokens do identidade-visual.md (ver etapa 5) |
| `nomes_cores` | para cada papel: `[nome simples, para que serve]` |
| `textos` | frases na voz da pessoa (ver abaixo) |
| `foto_estilo` | 3 a 5 itens da etapa 2 |
| `nao_faca` | 5 a 8 itens da etapa 2 |

Textos da prévia:
- Escreva como a pessoa escreve: use expressões e o jeito de chamar a aluna que estão em `voz.md`. Nada de texto genérico de exemplo.
- Use só informação que está no segundo cérebro (produto, preço, provas). O que está "a confirmar" não entra.
- Capa: até 8 palavras. Miolo: até 30 palavras. Story: título com até 6 palavras.
- Em `pagina_titulo`, a parte entre asteriscos (`*assim*`) aparece na cor primária. Use em 2 a 4 palavras, no máximo.
- Sem travessão, sem emoji, acentuação completa.
- JSON válido: aspas duplas, vírgula entre itens, nenhuma vírgula sobrando no último item.

`google_fonts`: monte o link com as duas fontes e os pesos, trocando espaço por `+`:
`https://fonts.googleapis.com/css2?family=Poppins:wght@700;800&family=Nunito+Sans:wght@400;700&display=swap`
Pesos em ordem crescente, separados por `;`.

## Passo 2. Abrir no navegador

- Mac: `open "<pasta>/identidade-visual.html"`
- Windows (PowerShell): `Start-Process "<pasta>\identidade-visual.html"` (se não abrir, `explorer.exe "<pasta>\identidade-visual.html"`)
- Linux: `xdg-open "<pasta>/identidade-visual.html"`

Se nenhum comando funcionar, ensine em passos:

> Vamos abrir a prévia na mão:
> 1. Abra o Finder (Mac) ou o Explorador de Arquivos (Windows, o ícone de pasta amarela na barra de baixo) ou o app Arquivos (Linux).
> 2. Entre na sua pasta de usuário e depois na pasta brain.
> 3. Dê dois cliques no arquivo identidade-visual.html. Ele abre no navegador.

A página precisa de internet só para carregar as fontes. Sem internet, ela abre com uma fonte do sistema; avise se a pessoa estiver offline.

## Passo 3. Conferir antes de perguntar

Releia o bloco que você gravou e confira:
- todas as 9 cores em HEX de 6 dígitos com `#`;
- os pares obrigatórios passam no contraste (a página mostra o selo; "Leitura fraca" em primária, secundária, fundo ou fundo alternativo é erro seu, corrija antes de mostrar);
- caminhos de logo e foto existem (Glob);
- nenhum travessão e nenhum emoji (Grep no arquivo pelos dois tipos de travessão, os caracteres Unicode U+2014 e U+2013; com Grep use o padrão `\x{2014}|\x{2013}`).

Depois vá para a etapa 4.

# Etapa 2. Propor o sistema

Tempo no encontro: 10 minutos.

Leia antes `${CLAUDE_SKILL_DIR}/referencias/guia-de-escolhas.md`. As regras de cor, contraste, pares de fontes e peças estão lá. Não escolha de memória.

## Passo 1. Tom visual (3 adjetivos)

A partir do Tom de `voz.md` e de quem é a aluna em `aluno-ideal.md`, escolha 3 adjetivos que descrevem como as peças devem parecer. Eles mandam em todas as escolhas seguintes.

- Um adjetivo vem da voz (ex.: voz "direta, próxima" vira "próxima").
- Um vem do resultado que a aluna quer (ex.: "emagrecer sem sofrer" vira "leve").
- Um dá a energia (ex.: "enérgica", "firme", "calma").

Evite adjetivos vazios como "moderna", "profissional", "bonita": todo mundo quer isso.

## Passo 2. Paleta

Monte 7 cores, cada uma com nome simples, HEX, para que serve e o porquê em uma frase:

| Papel | Para que serve |
|---|---|
| primária | a cor da marca: títulos de destaque, botões, capa de carrossel |
| secundária | contraponto: fundos escuros de peça, faixas, segunda cor de destaque |
| destaque | detalhe pequeno: sublinhado, selo, número, ícone. Nunca em texto longo |
| fundo | fundo claro principal (quase branco, com um leve tom da marca) |
| fundo alternativo | fundo de seção ou de cartão, um pouco mais escuro que o fundo |
| texto | texto principal sobre fundo claro (quase preto, nunca preto puro com cor fria) |
| texto suave | legenda, data, observação |

Regras:
1. Parta do que foi encontrado na etapa 1. Se a pessoa já usa uma cor com frequência e não odeia, ela vira a primária (ajustada se precisar de contraste). Se a base veio de referências de outros perfis ou paletas (etapa 1, 2c), use a família de cor e o clima de que ela gostou para criar uma paleta própria, nunca a cópia da referência, e respeite a cor que ela disse que não quer.
2. Calcule o contraste dos pares obrigatórios com a fórmula do guia e mostre o resultado: texto sobre fundo, texto sobre fundo alternativo, branco (ou texto) sobre primária, branco sobre secundária. Mínimo 4,5 para texto comum e 3 para título grande. Se não passar, escureça ou clareie a cor até passar e diga que ajustou.
3. Defina `texto_sobre_primaria` e `texto_sobre_secundaria`: branco `#FFFFFF` ou a cor de texto, a que tiver mais contraste.

## Passo 3. Fontes (2, do Google Fonts)

Escolha um par da tabela do guia que combine com os 3 adjetivos. Para cada uma: nome, pesos (ex.: 700 e 800 para título; 400 e 700 para texto) e o porquê em uma frase. Se a pessoa já usa uma fonte parecida nos posts, prefira o par que tem ela.

Só vale fonte que existe no Google Fonts, com o nome escrito igual ao de lá (ex.: `Nunito Sans`, não `Nunito sans` nem `NunitoSans`). Se a marca usa uma fonte do Canva ou paga (ex.: Glacial Indifference, Canva Sans, Futura, Gotham, Avenir), escolha a mais parecida do Google Fonts e diga isso em uma linha: "Sua fonte Glacial Indifference não existe no Google Fonts, então usei a Poppins, que é a mais parecida, para as imagens saírem certas."

## Passo 4. Foto e imagem

Em 3 a 5 linhas: luz, cenário, enquadramento, roupa e clima. Baseie no que funcionou nas fotos dela e no que a aluna precisa enxergar (ex.: mãe que treina em casa precisa ver treino em casa, não academia lotada).

## Passo 5. Logo

- Tem logo: diga em que fundo ele funciona (claro, escuro, ambos), tamanho mínimo e espaço livre em volta (no mínimo a altura de uma letra do logo).
- Não tem: "Seu nome escrito na fonte de título, peso [x], na cor [primária ou texto]. Isso é sua marca por enquanto." Logo novo fica fora desta skill.

## Passo 6. Regras das peças

Use as regras do guia para carrossel (capa, miolo, último slide com chamada para ação), story e topo de página de vendas, já com as cores e fontes escolhidas. Escreva de forma que outra skill consiga seguir sem perguntar (ex.: "capa: fundo primária, título em texto_sobre_primaria, até 8 palavras").

## Passo 7. Não faça

5 a 8 itens: os gerais do guia que mais se aplicam a esta pessoa, mais o que ela disse que odeia na etapa 1.

## Passo 8. Mostrar a proposta na conversa

Curto, em lista numerada. Exemplo de formato:

> Minha proposta, pensada para "acolhedora, enérgica, descomplicada":
> 1. Rosa principal #C2185B: é a cor que você já usa. Com letra branca, leitura ótima (5,9).
> 2. Ameixa #4A1942: para fundo de story e de post de impacto, como o que mais foi bem.
> ...
> 8. Títulos em Poppins 800 (redonda e forte), texto em Nunito Sans 400 (fácil de ler no celular).
>
> Vou te mostrar isso aplicado, é mais fácil decidir vendo.

Não pergunte "gostou?" aqui. Vá direto para a etapa 3.

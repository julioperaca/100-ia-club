# O jeito do Peraça de escrever copy

Tirado das aulas do Peraça na mentoria (Action Day de Copy, o agente de copy da mentoria, Action Day Conteúdo 100% e Action Day Instagram e Análise de Perfis). Esta é a base da skill: as etapas aplicam o que está aqui.

Copy, para o Peraça, é a comunicação persuasiva que conduz a pessoa até uma ação. Não é "três dicas sobre tal coisa": é uma condução, do primeiro olhar até o convite.

---

## Parte 1. As 10 regras

**1. Toda copy tem um objetivo, e o objetivo é uma ação.** Antes de escrever, saiba o que a pessoa faz no fim: seguir o perfil, mandar mensagem no direct, chamar no WhatsApp. Pense no CTA antes, nunca de improviso no fim.

**2. Primeiro os pré-requisitos, depois a estrutura.** O que faz a copy funcionar não é a estrutura, é ter claro: com quem você fala (aluna ideal), as dores e desejos dela, os inimigos comuns, o novo caminho (seu método com os pilares) e as suas narrativas. Sem isso, qualquer estrutura sai fraca. Tudo isso está no cérebro: `aluno-ideal.md` e `metodo.md`.

**3. Poucos temas, muitos ângulos.** O público tem de 3 a 5 temas que não podem faltar (as dores e desejos mais urgentes). Não precisa inventar tema novo todo dia: fale das mesmas coisas de jeitos diferentes. A estrutura pode até se repetir; o que muda é a headline, a história, o gancho, a dor e o caminho.

**4. Headline é dor ou desejo mais curiosidade.** A primeira frase (a capa do carrossel, o começo do reels, a primeira linha da legenda) toca numa dor ou num desejo e deixa a pessoa curiosa. Entra "com o pé na porta", nunca com "Oi, tudo bem? Aqui é a Carla". O Peraça escreve a headline por último, depois de saber o CTA. Detalhes e modelos em `headlines.md`.

**5. Toda afirmação é argumentada.** Não basta dizer "aeróbio não funciona" ou "isso vira uma máquina de queimar gordura". Explique o porquê, o mínimo para a pessoa pensar "eu não sabia disso". Os argumentos de cada pilar estão em `metodo.md`.

**6. A solução é o seu método, e você diz o que fazer, não como.** Na hora da solução entra o seu caminho: o método, um pilar, o conceito dele. Nada de "disciplina, sono e beber água". Entregue um pedaço e deixe curiosidade, como filme de suspense: conscientiza, mas não responde tudo. Quem entrega tudo não precisa ser contratado.

**7. Específico vende, genérico não.** "Resultado" é qualquer coisa. "Emagrecer" é melhor. "Voltar a fechar a calça jeans de 2019" é o que a pessoa enxerga. O que é difícil de entender é difícil de vender.

**8. Todo conteúdo tem uma moral.** Quem termina de ler sai com uma conclusão ("não é sobre treinar mais, é sobre o estímulo certo pra tua idade"). Se o texto não deixa nenhuma conclusão, falta a moral.

**9. Gancho de verdade, nunca de mentira.** Contexto real abre bem: "hoje recebi uma mensagem de uma aluna", "ontem na academia uma mulher me perguntou". Não chame atenção para A e fale de B. E não fale do que você não viveu: um personal homem não diz "eu sei como é ser mulher"; ele diz "eu vejo isso todo dia com as minhas alunas".

**10. O texto é para quem está em cima do muro.** Post não é para o ego nem para a aluna que já é sua. Até no repost do treino de uma aluna, a legenda fala com quem ainda não comprou ("Quem te viu, quem te vê: há 4 meses ela largava o treino na segunda").

Dois ajustes de tom que ele ensina:
- **Tom.** A mesma ideia pode sair amigável, motivacional ou com cobrança. Use o tom de `voz.md`; varie de propósito, nunca por acaso.
- **A pitada da pessoa.** A IA entrega a base; o personal troca as frases pelas palavras dele. Por isso a skill pergunta "isso parece você?" e ajusta.

---

## Parte 2. As 5 estruturas

O Peraça usa quase sempre as duas primeiras. Escolha uma por variação, e declare.

### PEPO: Promessa, Erros, Passo a passo, Oferta

Melhor para: atrair seguidor novo. Começa no desejo, e desejo chama atenção.

| Parte | O que vai | De onde tirar |
|---|---|---|
| Promessa | o desejo dela, com curiosidade (é a headline) | Ponto B de `aluno-ideal.md` |
| Erros | o inimigo comum: o que ela faz ou o que o mercado vende e você não concorda, com argumento. Pode abrir com gancho de contexto | inimigo comum e argumentos do pilar em `metodo.md`; Caminhos comuns |
| Passo a passo | o seu novo caminho: um pilar ou parte do método, o que fazer e não como fazer, deixando curiosidade | conceito do pilar em `metodo.md` |
| Oferta | o convite para o próximo passo (CTA) | etapa 2 |

### PCS: Problema, Causa, Solução

Melhor para: conteúdo que gera reflexão e conversa no direct.

| Parte | O que vai | De onde tirar |
|---|---|---|
| Problema | um problema dela, já em forma de headline ("você emagrece, mas a barriga não vai embora") | Ponto A, linguagem da aluna |
| Causa | por que acontece, com argumento que ela não sabia | argumentos do pilar |
| Solução | o caminho do seu método: o que fazer, não como | conceito do pilar |
| CTA | o convite | etapa 2 |

Cuidado que o Peraça aponta: promessa não é problema. "Secar a barriga sem treinar todo dia" é promessa (vai na PEPO). O problema seria "por isso você vive no efeito sanfona".

### PAS: Problema, Agitação, Solução

Começa chamando atenção (headline, foto ou frase forte), levanta o problema, agita: fala mais dele, de outro jeito, e das consequências de continuar nele. Depois a solução e o CTA.

### PISA: Problema, Implicação, Solução, Ação

Quase igual à PCS, mas no lugar da causa vem a implicação: o que acontece na vida dela se o problema não for resolvido ("você está só cumprindo tabela na academia", "perde músculo junto com a gordura"). Depois a solução e a ação.

### História com moral

Para conexão e identidade. Contexto (uma cena real: mensagem de aluna, conversa na academia, algo que você viveu), a dificuldade, o problema e o que ele implica, o novo caminho, a sugestão e a moral da história. A moral é o que ela leva. Funciona em carrossel, reels com texto na tela, stories e legenda longa.

### Qual usar

| Objetivo (como a pauta escreve) | Primeira escolha | Segunda |
|---|---|---|
| atrair (ganhar seguidor) | PEPO | PAS |
| conscientizar | PCS | PAS |
| converter (conversa no direct ou WhatsApp) | PCS | PISA |
| conectar (bastidor, identidade) | História com moral | PCS |
| provar (case autorizado) | História com moral | PEPO |

As duas variações usam estruturas diferentes.

Quando a pauta traz uma "Estrutura sugerida" (ex.: "erro comum e o certo", "o que eu faria hoje", "crença, bastidor, enquete, chamada"), a Variação A segue a sugestão da pauta, encaixada na estrutura de copy mais próxima (erro comum e o certo cabe na PCS; o que eu faria hoje cabe na PEPO; crença e bastidor cabem na História com moral), e declara as duas. A Variação B usa outra estrutura da tabela.

---

## Parte 3. Os 4 tipos de tema

Quando a pessoa não sabe sobre o que falar, ou a pauta não trouxe tema:

| Tipo | O que é | Uso |
|---|---|---|
| Tema inevitável | as 3 a 5 dores e desejos mais urgentes, o que ela quer e não o "como" | conteúdo que vende e que atrai |
| Tema complementar | dores menores do mesmo público | variar a vitrine |
| Interesse da audiência | assunto em alta que ela consome, sempre puxado para a sua mensagem | gancho, principalmente nos stories |
| Identidade | suas ideias, valores, rotina, uma história sua | conexão, não venda direta |

Para vender, toque em dor e desejo. Identidade gera conexão.

---

## Parte 4. As perguntas que o agente de copy da mentoria faz

O agente de copy que o Peraça entregou aos mentorados pergunta, antes de escrever: o objetivo do conteúdo; para quem é; a dor ou o desejo principal; por que essa mulher não consegue resolver isso sozinha (o inimigo); a solução do seu jeito; o resultado que ela busca, não só físico, o que ela quer sentir e viver; onde o conteúdo vai ser usado (formato); e o CTA. E avisa: quanto menos contexto, mais genérica sai a copy.

Esta skill tira quase tudo isso do cérebro e da pauta, e só pergunta o que falta (etapa 2).

# Como fica cada formato

Leia só a seção do formato pedido, a de legenda e, se houver modelo de post, a parte "Os 7 modelos de post" logo abaixo. A base (headline, introdução, desenrolar, conclusão e CTA) e a estrutura do desenrolar (PEPO, PCS, PAS, AIDA, ADP ou História com moral) são as mesmas em qualquer formato: o formato só diz como elas se dividem em slides, falas ou stories.

O texto sai com os rótulos do formato combinado com a skill `conteudo` (`Título:`, `Apoio:`, `Texto:`, `Botão:`, `Figurinha:`), porque é dali que ela monta as imagens. O modelo completo está em `modelos/texto.md`.

O que vem das aulas do Peraça está dito assim. O que é decisão do pacote (as aulas não dão número) aparece como "padrão do pacote", e a pauta ou a pessoa podem mudar.

Destaque: em cada slide ou story, 1 a 3 palavras entre asteriscos (`*40 minutos*`) ficam na cor da marca. No máximo um destaque por slide ou story. Use na palavra que carrega a ideia, não em enfeite.

---

## Os 7 modelos de post

A ordem das ideias slide a slide de cada modelo está em `${CLAUDE_SKILL_DIR}/../conteudo/referencias/formatos.md` (a fonte; leia a seção do modelo pedido antes de escrever). Aqui fica só o que muda no texto:

| # | Modelo | Formato | Headline | O que o texto leva |
|---|---|---|---|---|
| 1 | Foto, nicho e headline | carrossel, até 10 | livre: dor ou desejo mais curiosidade | `Nicho:` e `Imagem:` na capa; `Imagem:` no slide 2, que precisa fazer sentido sozinho |
| 2 | Troque isso por isso | carrossel, 10 | "Faça isso para [desejo]" | de 4 a 6 pares: `Título:` começa com "Troque", `Texto:` com "Por" |
| 3 | Foi assim que | carrossel, 10 | "Foi assim que [nome] alcançou [resultado] em [tempo]" | `Imagem:` e `Nicho:` na capa; `Print:` nos slides 4 a 8. Só com case autorizado |
| 4 | Frase sobre foto | post único | a frase é dele, da `voz.md` | `## Post` só com `Título:` (a frase, até 20 palavras) e `Imagem:`. A copy inteira vai na `## Legenda` |
| 5 | Esse é o segredo | post único ou capa de reels | "Esse é o segredo para [desejo]" | `## Post` só com `Título:` (a headline), `Imagem:` e `Nicho:` opcional. A copy inteira vai na `## Legenda` |
| 6 | Plano prático | carrossel, 10 (8 sem case) | "Plano prático para [sair de A e chegar em B]" | `Imagem:` e `Nicho:` na capa; `Print:` nos slides 7 e 8 |
| 7 | Carrossel tweet | carrossel | a da estrutura escolhida | `Foto de perfil:` abaixo de `Uso:`; frases curtas, de 1 a 3 por slide; `Print:` onde houver prova |

Em todo modelo, por baixo, vale a base: headline, introdução, desenrolar (na estrutura escolhida), conclusão (a moral) e CTA. Nos modelos 4 e 5 a base inteira vai na legenda; a imagem leva só a frase ou a headline.

Sem pauta e sem modelo pedido, escolha o modelo pelo "Quando sugerir" da fonte, ou use `Modelo: livre`.

**Anúncio ou vitrine (carrossel).** Anúncio: no máximo 10 slides. Se passar, junte os slides do meio; nunca corte a capa, a conclusão ou o CTA. Vitrine: até 20.

**Prova com print.** Quando o texto afirma um resultado em que alguém pode não acreditar (um prazo, uma mudança, "ela voltou a correr"), a linha `Print:` vem logo depois, no mesmo slide ou no seguinte. Sem o arquivo ainda: `Print: pedir (o que o print prova)`. Só print autorizado, sem telefone, sem foto de exame, sem dado de saúde. Sem print, a frase fica mais moderada. Nunca invente resultado.

---

## 1. Carrossel

Das aulas: o primeiro slide é a headline (a capa), o último é o CTA, e os do meio desenvolvem a estrutura. A capa é o que a pessoa vê no perfil: muita gente nem abre, só lê as capas.

Quantos slides: o que a pauta disser. Sem pauta, padrão do pacote: 8.

| Slide | Rótulos | O que vai |
|---|---|---|
| 1 (capa) | `Título:` até 8 palavras; `Apoio:` opcional, uma linha | a headline: dor ou desejo mais curiosidade, nunca a resposta. O Apoio puxa para o próximo slide |
| 2 | `Título:` opcional; `Texto:` | confirma a headline com a cena ou a frase dela (linguagem da aluna). Ela pensa "sou eu" |
| 3 até o penúltimo | `Título:` opcional, até 6 palavras; `Texto:` até 30 palavras | a estrutura, uma parte por slide: na PCS, problema, causa (com argumento), solução; na PEPO, erros (com argumento) e o passo a passo (o pilar, o que fazer, não como). O penúltimo costuma ser a moral |
| último (final) | `Título:` curto; `Texto:` o convite; `Botão:` opcional | o CTA, com a ação exata |

Regras:
- `Texto:` até 30 palavras por slide do meio. Uma ideia por slide.
- `Estilo: destaque` (fundo de outra cor) em no máximo 2 slides do meio: use no slide da virada ou da moral.
- Cada slide puxa o próximo: o fim de um deixa uma pergunta que o seguinte responde.
- O nome do método ou do pilar pode aparecer na solução, nunca na capa.
- Assunto técnico só ligado ao desejo: não "sua zona de frequência cardíaca", e sim "a intensidade do treino decide se você queima gordura".
- Legenda do carrossel: curta, reforça a moral e repete o CTA (seção 5).

## 2. Reels

Das aulas: o começo do reels é a headline (e a capa do reels também); tem que gerar curiosidade logo no início. A pessoa assiste sem som, então o texto na tela precisa contar a ideia sozinho. O Peraça pede roteiro de vídeo de até 30 segundos quando transforma um post em reels.

Duração: o que a pauta disser. Sem pauta, padrão do pacote: até 30 segundos (perto de 75 palavras faladas no total).

| Parte | Rótulos e linhas | O que vai |
|---|---|---|
| `## Gancho` | `Título:` até 8 palavras; `Apoio:` opcional | a headline. Vira a capa do reels e o texto dos primeiros 3 segundos. Pode abrir com contexto real ("hoje uma aluna me mandou isso") |
| `## Roteiro` | uma fala por linha; `[TELA: ...]` e `[cena: ...]` em linhas próprias, quando ajudar | a estrutura em falas curtas, uns 20 a 25 segundos |
| `## CTA` | a fala do convite e o `[TELA: ...]` dele | até 5 segundos |

Regras:
- Fala de gente, não de texto lido: frases que a pessoa diria olhando pra câmera.
- Se a pauta pedir reels curto de cena com "leia a legenda" (5 a 7 segundos), o Roteiro vira a cena e uma frase de tela, e a estrutura inteira vai para a legenda.
- A legenda do reels repete a ideia em texto para quem não ouviu (seção 5).

## 3. Stories

Das aulas: stories nutrem quem já chegou no perfil e geram conexão. Ideias que o Peraça usa: contar uma história, bastidor com texto intencional (que mostra o diferencial, não o evento), repost de aluna com texto para quem está em cima do muro, story de exercício dizendo para quem serve, caixinha de perguntas respondida em vídeo. O fim leva para o direct.

Quantos stories: o que a pauta disser. Sem pauta, padrão do pacote: 5.

| Story | Rótulos | O que vai |
|---|---|---|
| 1 | `Título:`; `Texto:` opcional | o gancho: a headline ou o contexto real |
| 2 ao penúltimo | `Título:` curto; `Texto:` até 25 palavras; `Figurinha:` quando houver | a estrutura, uma parte por story. Interação simples (enquete de sim ou não, caixinha) se ajudar a conversa |
| último | `Título:`; `Texto:`; `Figurinha:` se for link ou caixinha | CTA para o direct: "me manda [PALAVRA] no direct" |

Regras:
- `Figurinha:` descreve a figurinha que a pessoa coloca no Instagram: `enquete "Você já largou o treino por causa de uma semana corrida?"`, `caixinha "Me conta tua semana"`. A imagem deixa o espaço marcado.
- Print de aluna só com autorização e sem dado pessoal à mostra.
- `## Legenda` com `sem legenda`, a não ser que a pauta diga que vai para o feed.

## 4. Post único

| Parte | Rótulos | O que vai |
|---|---|---|
| `## Post` | `Título:` (a headline); `Texto:` curto | a imagem: headline e, no máximo, duas linhas de apoio ou o relato do case |
| `## Legenda` | | a estrutura inteira, na legenda |

Bom para prova (o relato de um case autorizado, entre aspas) e para frase de posição.

## 5. Legenda

Vai junto de todo post e pode ser pedida sozinha.

| Bloco | O que vai | Limite |
|---|---|---|
| Primeira linha | a headline ou outra porta para a mesma ideia (é a única linha que aparece antes do "mais") | até 125 caracteres |
| Corpo | a estrutura em parágrafos curtos, com linha em branco entre eles | 40 a 150 palavras |
| Moral | a conclusão em uma frase | 1 linha |
| CTA | a ação exata, uma só | 1 linha |

Regras:
- Legenda de carrossel e de reels é mais curta (40 a 80 palavras): o conteúdo está na arte.
- Termina com um pedido só. Se a pessoa costuma terminar com pergunta (veja `voz.md`), o CTA pode vir em forma de pergunta.
- Hashtag só se a pessoa usa (até 5, no fim).
- Preço só se a pessoa costuma mostrar preço.
- Sem asteriscos na legenda (destaque é só da imagem).

## 6. CTA

Os dois que o Peraça mais usa:

| Objetivo | Como fica | Exemplo de forma |
|---|---|---|
| seguir | fala da oportunidade e manda seguir | "Pra mais conteúdo de como [desejo], segue o [@ do cérebro]." |
| direct | convida pra conversa, de gente pra gente | "Se você quer [desejo] e não sabe por onde começar, me manda uma mensagem no direct. Sou eu que respondo." |

Outros que valem: chamar no WhatsApp ("toca no link da bio e me chama no WhatsApp"), mandar uma palavra no direct ("me manda SEMANA no direct"), preencher a avaliação, estar na live.

O que o Peraça não recomenda: "comente [palavra]" em perfil pequeno, porque quase ninguém quer ser o primeiro a comentar. Se a pauta ou a pessoa pedir comentário, troque por "me manda [palavra] no direct" e avise em uma linha; se ela insistir, faça.

Regras:
- Um CTA por peça. A ação é exata (qual palavra, onde tocar).
- O CTA é o da pauta (`Chamada para ação`). "seguir" vira CTA de seguir; "conversar no direct" e "avaliação" viram direct com palavra.

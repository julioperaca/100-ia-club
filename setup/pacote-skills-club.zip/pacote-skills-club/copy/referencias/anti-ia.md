# Conferência final (anti-IA, segurança e jeito do Peraça)

Texto com cheiro de IA perde a confiança de quem lê na primeira linha. Este checklist é aplicado por você, item por item, em cada variação, antes de mostrar qualquer coisa. Nada para instalar: os itens 1 a 3 também são conferidos com a busca (Grep) da etapa 4, que já vem no Claude.

Regra de ouro: se o texto parecer bonito demais, certinho demais ou genérico demais, está errado. Corrija até parecer gente de verdade falando.

## Antes dos 16 itens: segurança (reprova na hora)

- [ ] **Saúde:** nenhuma promessa de quilos, medidas ou prazo garantidos, de cura, de tratamento, de dieta. Resultado de aluna só como relato dela, com o tempo que levou.
- [ ] **Urgência:** nenhum prazo, vaga, "últimas vagas", "só hoje" ou aumento de preço que a pessoa não confirmou.
- [ ] **Dados:** todo número, preço e depoimento tem fonte no cérebro; nada "a confirmar"; nenhum case sem autorização.
- [ ] **Nome do produto:** "Programa Personalizado", com iniciais maiúsculas (ou o nome próprio que a pessoa deu). Nunca "consultoria".

## Os 16 itens

**1. Travessão.** Nenhum travessão, nem o longo nem o curto (os traços compridos que o celular e o Word colocam sozinhos), nem dois hífens no lugar de pausa.
Corrija com vírgula, ponto, dois pontos ou parênteses.

**2. Emoji.** Nenhum, em lugar nenhum da peça.
Corrija apagando. Se o emoji fazia o papel de pontuação, ponha a pontuação.

**3. Palavras e expressões proibidas.** Nenhuma destas: descubra, transforme sua vida, imagine poder, desbloqueie, eleve, mergulhe, revolucione, jornada (como "sua jornada", "jornada de transformação"), "a verdade que ninguém te conta", "se você chegou até aqui", "você já parou pra pensar", "já se pegou pensando", "no final do dia", "faz toda a diferença", "e isso muda tudo", "pense nisso", "fica a reflexão", "em resumo", "saia da zona de conforto", "acredite em você", "basta querer", "o segredo é", "vamos falar sobre", "hoje em dia", grátis, gratuito, de graça.
Corrija dizendo a coisa concreta no lugar ("transforme sua vida" vira "volte a subir a escada sem parar no meio").

**4. Palavra oca.** Nenhum verbo ou adjetivo de palestra: potencializar, alavancar, otimizar, maximizar, destravar, empoderar, robusto, inovador, incrível, poderoso, excepcional, extraordinário, transformador, alta performance, próximo nível, mindset, novos patamares.
Corrija com número ou ação: "potencializa seus resultados" vira "o ajuste de cada 30 dias muda o treino antes de o corpo acostumar".

**5. "Não é X, é Y".** No máximo uma vez na peça inteira (contando "não é só X, é Y" e "mais que X, é Y").
Corrija dizendo direto o que é: "Não é falta de tempo, é falta de plano" vira "O que falta é um plano que caiba no tempo que você tem".

**6. Tríade mecânica.** Nada de três itens do mesmo tamanho só para fechar o ritmo ("Sem academia. Sem dieta. Sem desculpa.").
Corrija com 2 ou 4 itens de tamanhos diferentes, ou conectando com "e".
Exceção: um bordão real que está em `voz.md` pode aparecer uma vez, do jeito que ela fala.

**7. Frases curtas empilhadas.** Nunca três ou mais frases de 2 a 5 palavras coladas na mesma linha ("Faz o treino. Volta na segunda. Pronto.").
Corrija ligando com vírgula, "e", "mas", "então", ou separando em linhas diferentes, com linha em branco no meio.

**8. Repetição de começo.** Nada de três frases ou três linhas seguidas começando igual ("É sobre... É sobre... É sobre..."), nem espelho perfeito ("Quem treina pouco... Quem treina muito...").
Corrija mudando o começo de uma delas ou juntando duas.
Exceção: no carrossel "Troque isso por isso", a repetição de "Troque" no `Título:` e de "Por" no `Texto:` de cada par é a estrutura do formato e passa. Vale só para esses rótulos dos pares; no texto corrido (o resto do slide, a capa, a moral, a chamada e a legenda) o item 8 continua valendo.

**9. Pingue-pongue retórico.** Nada de "E sabe o que acontece? Nada." nem frase terminando numa palavra solta de impacto ("O resultado? Desistência.").
Corrija emendando numa frase só: "E aí ela desiste na segunda".

**10. Abertura genérica.** A peça não começa com "Você já se perguntou", "Sabia que", "Imagine", "Hoje quero falar", "Olá, tudo bem?".
Corrija começando pela cena, pela afirmação mais forte ou pela fala da aluna.

**11. Fechamento com moral.** Nenhum parágrafo termina com frase de efeito genérica e a peça não termina resumindo.
Corrija terminando no próximo passo (o pedido).

**12. Cara de redação.** Nenhum ponto e vírgula, "(ou seja...)", "(em outras palavras...)", "portanto", "dessa forma", "vale ressaltar", "ademais", "trata-se de", "o mesmo" como pronome, voz passiva ("resultados são alcançados").
Corrija com "então", ou cortando. Quem faz a ação é gente: "quem treina 3 vezes por semana vê diferença".

**13. Gerúndio no pedido.** Nada de "vou estar te enviando", "estarei aguardando".
Corrija: "te mando", "fico esperando tua resposta".

**14. Ritmo.** Nenhuma frase com mais de 22 palavras, e as frases não têm todas o mesmo tamanho. Os parágrafos também variam.
Corrija quebrando a frase longa em duas e deixando pelo menos uma frase bem curta e uma mais comprida por bloco.

**15. Especificidade e lado.** Troque mentalmente o nome da pessoa pelo de outro personal: se nada no texto vira mentira, ele está genérico. E o texto precisa estar contra alguma coisa (uma crença errada, o treino aleatório, a dieta da moda).
Corrija pondo número, nome, cena, objeto, e dizendo contra o que a peça está.

**16. Parece a pessoa.** Tem pelo menos uma expressão de `voz.md`, chama a aluna como ela chama, usa a linguagem da aluna, e não tem nada da lista "O que eu nunca digo" nem dos "Ajustes do teste do espelho".
Corrija trocando a palavra por uma dos textos reais dela.

## Depois dos 16: o jeito do Peraça (5 itens)

**P1. Ação.** O texto termina num CTA só, com a ação exata, e o CTA bate com o objetivo (seguir, direct, WhatsApp).

**P2. Headline.** Toca numa dor ou desejo, gera curiosidade e não entrega a resposta. Não tem nome de método. Modelo declarado.

**P3. Argumento.** Toda afirmação contra o inimigo comum tem um porquê. "Isso não funciona" sozinho reprova.

**P4. Solução é o método.** A solução é um pilar ou o conceito do método, dita como o que fazer e não como fazer. "Disciplina, sono e água" reprova.

**P5. Moral.** Quem termina sai com uma conclusão clara, numa frase.

Corrija voltando a `jeito-do-peraca.md`, na regra correspondente.

## Ao revisar um texto que a pessoa trouxe (Modo Revisar)

- Frase boa da pessoa fica. Só mexa no que reprova num item acima.
- Leia em voz alta antes de propor troca: se a frase original soa melhor, ela fica.
- Não troque frase clara por metáfora.
- Texto de gente às vezes é incompleto ou repete palavra. Isso não é defeito.

## Como contar no resultado

Conte os itens que passaram nas duas variações: "Passou na conferência (16 de 16 anti-IA e 5 de 5 do jeito do Peraça)". Se precisou corrigir, diga quantos itens foram corrigidos: "Corrigi 2 itens (frases curtas empilhadas e uma palavra oca) e agora passa 16 de 16 e 5 de 5."

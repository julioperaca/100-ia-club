# Modelos de headline

Headline é a primeira frase: a capa do carrossel, o começo do reels, a primeira linha da legenda, o primeiro story. Para o Peraça, a moral da headline é tocar numa dor ou num desejo e gerar curiosidade.

Os modelos abaixo são os que o Peraça ensina nas aulas de copy e de conteúdo. Cada um vem de uma headline campeã que vendeu muito no mundo (do swipe de headlines clássicas), e a entrega declara as duas coisas: o código do modelo e a campeã de onde ele vem.

Como usar:
1. Escolha o modelo pela estrutura e pela dor ou desejo (tabela no fim).
2. Mantenha o esqueleto e troque o conteúdo pelo que está no cérebro: o desejo do Ponto B, a dor do Ponto A, a objeção real, a palavra da aluna, o tempo real de um case.
3. Declare: "Headline: modelo P04 do Peraça (É por isso que), que vem de "Why Some People Almost Always Make Money in the Stock Market"".

Os exemplos "Para personal" são inventados, só para mostrar o formato. No texto real, tudo vem do cérebro.

Nos modelos de post (`formatos.md`, parte "Os 7 modelos de post"):
- Modelo 1 (Foto, nicho e headline): a headline é livre, desde que fale de dor ou desejo e desperte curiosidade. Os modelos abaixo servem de inspiração; se não usar nenhum, declare "Headline: livre (modelo 1)".
- Modelos 2, 3, 5 e 6 já trazem o começo da headline ("Faça isso para", "Foi assim que", "Esse é o segredo para", "Plano prático para"): siga o do modelo e declare o P0X mais próximo (P01, P11, P05, P08).
- Modelo 4 (Frase sobre foto): a frase da imagem é dele, da `voz.md`, e não segue modelo. A headline da legenda sai daqui.

## Regras de toda headline

- Uma frase, até 8 palavras na capa de carrossel e no gancho de reels (o limite da imagem); até 15 na primeira linha da legenda e na página.
- Algo concreto dentro: tempo, lugar, objeto, idade, a palavra dela (40 minutos, em casa, a calça jeans, depois dos 40).
- Nunca entrega a resposta. "Seu glúteo não cresce porque falta carga" já respondeu: ninguém precisa abrir.
- Nunca o nome do método ou do pilar na headline. Ela quer o resultado, não o nome.
- Assunto técnico só ligado ao desejo ("a intensidade do treino decide se você queima gordura").
- "Entenda o motivo" sozinho é pouco: prometa também a saída ("entenda o motivo e o que fazer").
- Resultado grande o bastante para importar, e real. Quilos, medidas e prazo garantido nunca: resultado com número só como relato de case autorizado, com o tempo que ela levou.
- "Descubra" é palavra proibida (cheiro de IA). Onde o Peraça diz "descubra como", use "veja como" ou "é assim que".

---

## P01. Faça isso para

- **Modelo:** Faça isso para [desejo] [sem a objeção]
- **Vem de:** "This Weird Trick Made Me $10,000 Richer" (o "isso" esconde o jeito e gera curiosidade)
- **Para personal:** Faça isso pra voltar a treinar na segunda sem precisar compensar o fim de semana
- **Cuidado:** o "isso" tem que ser entregue no conteúdo, pelo menos em parte.

## P02. Se a sua meta é, siga esse plano

- **Modelo:** Se a sua meta é [desejo], siga esse plano / Se você [quem é], siga essa estratégia
- **Vem de:** "If You're Over 40, Read This Warning" (chama exatamente quem é)
- **Para personal:** Se a sua meta é emagrecer e não engordar de novo, siga esse plano
- **Cuidado:** fale da rotina ou da idade, nunca do corpo dela ("se você está acima do peso" ofende).

## P03. Essa é a melhor forma de

- **Modelo:** Essa é a melhor forma de [desejo] [para quem ou quando]
- **Vem de:** "How to Make Money in Your Spare Time" (a família "como", com o quando)
- **Para personal:** Essa é a melhor forma de perder barriga depois dos 30 sem morar na academia
- **Cuidado:** o "para quem" é o que dá força. Sem ele, fica genérico.

## P04. É por isso que

- **Modelo:** É por isso que você ainda não [desejo que ela tenta e não consegue]
- **Vem de:** "Why Some People Almost Always Make Money in the Stock Market" (promete explicar a diferença)
- **Para personal:** É por isso que você emagrece, mas a barriga não vai embora
- **Cuidado:** combina com PCS. O conteúdo explica o motivo e mostra a saída.

## P05. Esse é o segredo para

- **Modelo:** Esse é o segredo para [desejo bem específico]
- **Vem de:** "The Secret of Making People Like You"
- **Para personal:** Esse é o segredo pra calça antiga voltar a fechar sem dieta da sopa
- **Cuidado:** nada de "segredo milagroso". O segredo é um pilar seu, com argumento.

## P06. Evite, seguindo esse caminho

- **Modelo:** Evite [problema] seguindo esse caminho / Não cometa esses erros se você quer [desejo]
- **Vem de:** "Warning: Don't Buy Any Insurance Until You Read This" (comando que avisa que a escolha está errada)
- **Para personal:** Não cometa esses erros se você quer treinar em casa e ver resultado
- **Cuidado:** o número de erros bate com o que o conteúdo mostra.

## P07. O maior erro que

- **Modelo:** Esse é o maior erro que [público] comete ao tentar [desejo]
- **Vem de:** "A Little Mistake That Cost a Farmer $3,000 a Year"
- **Para personal:** Esse é o maior erro que mãe que trabalha fora comete ao tentar emagrecer
- **Cuidado:** o erro é o inimigo comum de um pilar, e vem com argumento.

## P08. N passos para

- **Modelo:** [N] passos para [desejo] / Plano prático para [desejo]
- **Vem de:** "[X] passos simples para [resultado]", a fórmula derivada de "67 Ways to Increase Your Direct Mail Response"
- **Para personal:** 3 passos pra treinar em casa 40 minutos e não largar no primeiro mês
- **Cuidado:** passo a passo e checklist chamam atenção, mas diga o que fazer, não o como inteiro.

## P09. O melhor treino para, sem

- **Modelo:** Esse é o melhor treino para [desejo] sem [objeção comum]
- **Vem de:** "Now You Can [Resultado Desejado] Without [Sacrifício]"
- **Para personal:** Esse é o melhor treino pra secar a barriga sem passar uma hora na esteira
- **Cuidado:** o "sem" tem que ser verdade no seu método. As objeções estão em `aluno-ideal.md`.

## P10. Faça isso por, e veja

- **Modelo:** Faça isso por [tempo real] e veja [mudança que ela enxerga]
- **Vem de:** "Lose 20 Pounds in 20 Days", na versão segura
- **Para personal:** Faça isso por 4 semanas e veja a escada do prédio ficar mais leve
- **Cuidado:** a original promete quilos, e isso não pode. O tempo e a mudança vêm de um case autorizado ou do prazo do método, e o texto diz que cada corpo responde de um jeito.

## P11. Foi isso que minha aluna fez

- **Modelo:** Foi isso que minha aluna fez para [resultado real que ela contou]
- **Vem de:** "How I Improved My Memory in One Evening" (relato pessoal, específico, com resultado visível)
- **Para personal:** Foi isso que a Rê fez pra calça jeans de 2019 voltar a fechar
- **Cuidado:** só com case autorizado. Bom para post de resultado, ligando o resultado a um pilar.

## P12. É isso que acontece quando

- **Modelo:** É isso que acontece quando você [faz a coisa certa ou a errada]
- **Vem de:** "O que acontece quando você [ação simples]?", fórmula derivada de "Do You Make These Mistakes in English?"
- **Para personal:** É isso que acontece quando você troca a ficha todo mês achando que mudou o treino
- **Cuidado:** ótima para o inimigo comum de um pilar.

## P13. Se você, esse pode ser seu erro

- **Modelo:** Se você [faz X] e [não tem o resultado], esse pode ser o seu principal erro
- **Vem de:** "Do You Make These Mistakes in English?" (a pessoa se testa na hora)
- **Para personal:** Se você treina todo dia e a barriga não sai, esse pode ser o seu erro
- **Cuidado:** combina com PCS e PAS.

---

## Qual modelo para qual estrutura

| Estrutura | Modelos que combinam |
|---|---|
| PEPO (começa no desejo) | P01, P02, P03, P05, P09 |
| PCS (começa no problema) | P04, P13, P12 |
| PAS | P07, P13, P06 |
| AIDA | P01, P09, P02 |
| ADP | P11, P10, P03 |
| História com moral | P11, P10, ou o contexto real como gancho ("Hoje uma aluna me mandou...") |

As duas variações usam modelos diferentes.

Gancho de contexto real (História com moral) também vale como headline, e não precisa de modelo: declare "gancho de contexto, regra 9 do jeito do Peraça".

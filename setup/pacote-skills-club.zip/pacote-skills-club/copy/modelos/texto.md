# Formato dos arquivos do conteúdo

Dois arquivos na pasta do conteúdo (`<pasta>/conteudo/<AAAA-MM-DD>-<slug>/`), ao lado da `pauta.md`:
- `texto.md`: o texto escolhido, no formato combinado com a skill `conteudo` (o Modo Montar dela lê este arquivo para fazer as imagens). É o mesmo formato de `conteudo/referencias/formato-do-texto.md`. Não mude nada.
- `variacoes.md`: as duas variações, como foram feitas e de onde veio cada dado. Rascunho de consulta.

## texto.md

Regras do combinado:
- Primeira linha: `# <tema>` (o tema da pauta, sem "Pauta:").
- Segunda linha: `Formato: carrossel` (ou `reels`, `stories`, `post único`).
- Sem cabeçalho de 4 linhas neste arquivo: ele vive no `variacoes.md`.
- Cada parte começa com um título `##` exatamente como abaixo. Nenhum outro título `##`.
- Dentro de cada parte, linhas com rótulo: `Título:`, `Apoio:`, `Texto:`, `Botão:`, `Figurinha:` (e `Estilo: destaque` em até 2 slides do meio). Linha sem rótulo continua o rótulo de cima.
- Destaque na cor da marca: 1 a 3 palavras entre asteriscos (`*40 minutos*`), no máximo um destaque por slide ou story.
- Sempre termina com `## Legenda` (pronta para colar; não vai para a imagem).

### Carrossel

```
# [tema]
Formato: carrossel

## Slide 1
Título: [headline da capa, até 8 palavras, com 1 destaque]
Apoio: [uma linha que puxa pro próximo slide, opcional]

## Slide 2
Título: [opcional, até 6 palavras]
Texto: [até 30 palavras]

(um "## Slide N" por slide do meio; "Estilo: destaque" em no máximo 2 deles)

## Slide [último]
Título: [a chamada, curta]
Texto: [o convite com a ação exata]
Botão: [texto curto do botão, opcional]

## Legenda
[legenda completa, com o CTA no fim]
```

### Reels

```
# [tema]
Formato: reels

## Gancho
Título: [headline, até 8 palavras: vira a capa do reels e o texto dos primeiros 3 segundos]
Apoio: [uma linha, opcional]

## Roteiro
[uma fala por linha]
[TELA: texto que aparece na tela, quando ajudar]
[cena: indicação para gravar, só se ajudar]

## CTA
[a fala do convite]
[TELA: texto do convite]

## Legenda
[legenda completa]
```

### Stories

```
# [tema]
Formato: stories

## Story 1
Título: [curto]
Texto: [até 25 palavras]
Figurinha: [só se tiver: enquete "pergunta?", caixinha "pergunta", link]

(um "## Story N" por story)

## Legenda
sem legenda
```

(Se os stories forem repostados no feed, a legenda vem no lugar de "sem legenda".)

### Post único

```
# [tema]
Formato: post único

## Post
Título: [headline]
Texto: [o texto da imagem, curto]

## Legenda
[legenda completa]
```

### Só legenda (sem imagem)

```
# [tema]
Formato: post único

## Legenda
[legenda completa]
```

## variacoes.md

```
# Variações: [tema]

> O que é: as duas variações do texto de [formato] sobre [tema] e como foram feitas. A versão final está em texto.md.
> Última atualização: [dd/mm/aaaa]
> Status: [em andamento ou completo]
> O que falta: [escolher entre A e B, ou nada]

## Variação A

Estrutura: [PEPO, PCS, PAS, PISA ou História com moral; e a estrutura sugerida pela pauta, se usou]
Headline: modelo [P0X] do Peraça ([nome]), que vem de "[headline campeã]"
Pilar: [nome do pilar]

[o texto, no formato do texto.md, com os títulos rebaixados para ###: ### Slide 1, ### Legenda]

## Variação B

(igual)

## Como foi feita

- Pauta: [caminho da pauta, ou "sem pauta"]
- Versão final: [A, B ou mistura], escolhida por [a pessoa, na conversa, dd/mm/aaaa]
- Conferência: [16 de 16 anti-IA, 5 de 5 do jeito do Peraça, buscas vazias]

## De onde veio cada dado

- [dado usado] ([arquivo do cérebro, seção])
- [expressão da voz usada] (voz.md)

## Ajustes pedidos

- [dd/mm/aaaa] [o que a pessoa pediu e o que mudou]
```

# Formato dos arquivos do conteúdo

Dois arquivos na pasta do conteúdo (`<pasta>/conteudo/<AAAA-MM-DD>-<slug>/`), ao lado da `pauta.md`:
- `texto.md`: o texto escolhido, no formato combinado com a skill `conteudo` (o Modo Montar dela lê este arquivo para fazer as imagens). É o mesmo formato de `conteudo/referencias/formato-do-texto.md`. Não mude nada.
- `variacoes.md`: as duas variações, como foram feitas e de onde veio cada dado. Rascunho de consulta.

## texto.md

Regras do combinado:
- Primeira linha: `# <tema>` (o tema da pauta, sem "Pauta:").
- Segunda linha: `Formato: carrossel` (ou `reels`, `stories`, `post único`).
- Logo abaixo, `Modelo: <nome exato>`: Foto, nicho e headline | Troque isso por isso | Foi assim que | Frase sobre foto | Esse é o segredo | Plano prático | Carrossel tweet | livre.
- Só no carrossel, logo abaixo: `Uso: anúncio | vitrine`. Anúncio: no máximo 10 slides.
- Só no Carrossel tweet, logo abaixo de `Uso:`: `Foto de perfil: <arquivo>` (ou `Foto de perfil: pedir`).
- Sem cabeçalho de 4 linhas neste arquivo: ele vive no `variacoes.md`.
- Cada parte começa com um título `##` exatamente como abaixo. Nenhum outro título `##`.
- Dentro de cada parte, linhas com rótulo: `Título:`, `Apoio:`, `Texto:`, `Botão:`, `Figurinha:` (e `Estilo: destaque` em até 2 slides do meio). Linha sem rótulo continua o rótulo de cima.
- Rótulos de imagem, dentro de qualquer slide ou do `## Post`:
  - `Nicho:` a faixa de 1 a 3 palavras em caixa alta acima do título (capa).
  - `Imagem:` nome do arquivo da foto de fundo, na pasta do post (`foto-capa.jpg`). Se o aluno ainda não mandou: `Imagem: pedir (o que a foto deve mostrar)`.
  - `Print:` nome do arquivo do print de prova, um por linha (pode repetir). Se ainda não tem: `Print: pedir (o que o print prova)`.
- Destaque na cor da marca: 1 a 3 palavras entre asteriscos (`*40 minutos*`), no máximo um destaque por slide ou story.
- Sempre termina com `## Legenda` (pronta para colar; não vai para a imagem).

### Carrossel

```
# [tema]
Formato: carrossel
Modelo: [nome do modelo, ou livre]
Uso: [anúncio ou vitrine]

## Slide 1
Nicho: [só se o modelo pede, ex.: MULHERES 40+]
Título: [headline da capa, até 8 palavras, com 1 destaque]
Apoio: [uma linha que puxa pro próximo slide, opcional]
Imagem: [arquivo, ou pedir (o que a foto deve mostrar), só se o modelo pede]

## Slide 2
Título: [opcional, até 6 palavras]
Texto: [até 30 palavras]
Print: [arquivo, ou pedir (o que o print prova), logo depois de um resultado]

(um "## Slide N" por slide do meio; "Estilo: destaque" em no máximo 2 deles)

## Slide [último]
Título: [a chamada, curta]
Texto: [o convite com a ação exata]
Botão: [texto curto do botão, opcional]

## Legenda
[legenda completa, com o CTA no fim]
```

### Reels

```
# [tema]
Formato: reels
Modelo: [livre, ou Esse é o segredo quando a capa do reels segue esse modelo]

## Gancho
Título: [headline, até 8 palavras: vira a capa do reels e o texto dos primeiros 3 segundos]
Apoio: [uma linha, opcional]

## Roteiro
[uma fala por linha]
[TELA: texto que aparece na tela, quando ajudar]
[cena: indicação para gravar, só se ajudar]

## CTA
[a fala do convite]
[TELA: texto do convite]

## Legenda
[legenda completa]
```

### Stories

```
# [tema]
Formato: stories
Modelo: livre

## Story 1
Título: [curto]
Texto: [até 25 palavras]
Figurinha: [só se tiver: enquete "pergunta?", caixinha "pergunta", link]

(um "## Story N" por story)

## Legenda
sem legenda
```

(Se os stories forem repostados no feed, a legenda vem no lugar de "sem legenda".)

### Post único

```
# [tema]
Formato: post único
Modelo: [Frase sobre foto, Esse é o segredo ou livre]

## Post
Nicho: [opcional, só no Esse é o segredo]
Título: [headline, ou a frase no Frase sobre foto]
Texto: [o texto da imagem, curto; fica fora no Frase sobre foto e no Esse é o segredo]
Imagem: [arquivo, ou pedir (o que a foto deve mostrar), quando o modelo pede foto]

## Legenda
[legenda completa; no Frase sobre foto e no Esse é o segredo, a copy inteira: headline, introdução, desenrolar, moral e CTA]
```

### Só legenda (sem imagem)

```
# [tema]
Formato: post único
Modelo: livre

## Legenda
[legenda completa]
```

## variacoes.md

```
# Variações: [tema]

> O que é: as duas variações do texto de [formato] sobre [tema] e como foram feitas. A versão final está em texto.md.
> Última atualização: [dd/mm/aaaa]
> Status: [em andamento ou completo]
> O que falta: [escolher entre A e B, ou nada]

## Variação A

Estrutura: [PEPO, PCS, PAS, AIDA, ADP ou História com moral; e a estrutura sugerida pela pauta, se usou]
Modelo: [modelo de post, ou livre]
Headline: modelo [P0X] do Peraça ([nome]), que vem de "[headline campeã]"
Pilar: [nome do pilar]

[o texto, no formato do texto.md, com os títulos rebaixados para ###: ### Slide 1, ### Legenda]

## Variação B

(igual)

## Como foi feita

- Pauta: [caminho da pauta, ou "sem pauta"]
- Versão final: [A, B ou mistura], escolhida por [a pessoa, na conversa, dd/mm/aaaa]
- Estrutura da Variação A: [escolhida pela pessoa no cardápio, ou "pode ser" na sugerida]
- Uso: [anúncio ou vitrine, e quem disse: a pauta ou a pessoa]
- Prints: [cada `Print:` usado, o que prova e por que está ali; ou "sem print, frases moderadas"]
- Conferência: [16 de 16 anti-IA, 5 de 5 do jeito do Peraça, buscas vazias]

## De onde veio cada dado

- [dado usado] ([arquivo do cérebro, seção])
- [expressão da voz usada] (voz.md)

## Ajustes pedidos

- [dd/mm/aaaa] [o que a pessoa pediu e o que mudou]
```

# [Headline ou CTA]: [produto ou tema]

> O que é: [tipo] para [objetivo], [produto]. Feita com a skill copy.
> Última atualização: [dd/mm/aaaa]
> Status: [em andamento ou completo]
> O que falta: [o que ficou de fora por estar a confirmar, ou "escolher entre A e B", ou "nada"]

## Versão final

[Headline ou CTA: a escolhida, pronta para copiar.]

## Variação A

Estrutura: [estrutura do Peraça]
Headline: modelo [P0X] do Peraça ([nome]), que vem de "[headline campeã]"

[texto]

## Variação B

(igual)

## Como foi feita

- Estrutura: [a estrutura usada]
- Versão final: [A, B ou mistura], escolhida por [a pessoa, na conversa, dd/mm/aaaa]
- Conferência: [16 de 16 anti-IA, 5 de 5 do jeito do Peraça, buscas vazias]

## De onde veio cada dado

- [dado usado] ([arquivo do cérebro, seção])

## Ajustes pedidos

- [dd/mm/aaaa] [o que a pessoa pediu e o que mudou]

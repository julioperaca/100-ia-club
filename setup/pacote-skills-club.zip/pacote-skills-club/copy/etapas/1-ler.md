# Etapa 1. Ler o cérebro e achar a pauta (sem perguntar nada)

Tempo no encontro: 1 minuto.

Objetivo: chegar na etapa 2 sabendo com quem a pessoa fala, qual é o método dela, como ela escreve e, se existir, o que a pauta já decidiu.

## Passo 1. Ler o cérebro, nesta ordem

1. `<pasta>/voz.md`: tudo. Anote em rascunho o tom, as expressões do jeito que estão escritas, como chama a aluna, o que nunca diz (vale como proibição, junto com os "Ajustes do teste do espelho") e, nos textos reais, o tamanho das frases, se termina com pergunta, se usa "pra".
2. `<pasta>/aluno-ideal.md`: Quem é, Ponto A, Ponto B, Objeções e Linguagem que ele usa. São as dores e desejos (regra 2 do Peraça).
3. `<pasta>/metodo.md`: nome, promessa, e de cada pilar: nome, conceito, inimigo comum e argumentos. Também Caminhos comuns, Ponto A e Ponto B e "O que o método não promete". É a munição: o inimigo vira os Erros, o argumento vira a Causa, o conceito vira a Solução.
4. `<pasta>/negocio.md`: nome do programa, produtos e preços atuais (nunca o Histórico de preços), Como a venda acontece, Números, Provas.
5. `<pasta>/cases.md`: só os cases com `autorização para uso público: sim`.
6. `<pasta>/perfil-profissional.md`: `nome_publico`, `instagram`, `whatsapp`, `cref`.

Arquivo que não existe ou está com `Status: vazio`: siga com o que tem.

Separe, só para você:
- **Pode usar:** todo item com fonte e sem "a confirmar".
- **Não pode usar:** "a confirmar", campo vazio, case sem autorização, dado de saúde de aluna.

`metodo.md` em formato antigo (pilares com "aprende, faz, por que funciona" e sem "inimigo comum"): use "por que funciona" como argumento e a tabela "Caminhos comuns" como inimigo.

## Passo 2. Achar a pauta

1. Se o `$ARGUMENTS` cita uma pasta ou um tema de pauta, procure por ele. Se não, Glob `<pasta>/conteudo/*/pauta.md`.
2. Pautas com `Status: pauta pronta` (ou sem `texto.md` na mesma pasta) são as que estão esperando texto.
   - Nenhuma: siga sem pauta.
   - Uma: use essa.
   - Mais de uma: mostre como lista numerada (data e tema) e pergunte "Qual dessas você quer escrever agora?", com a última opção "Outro tema, sem pauta".
3. Leia a pauta inteira (o modelo é o `pauta.md` da skill `conteudo`). Anote:
   - o tema (a linha `# Pauta: ...`, sem o "Pauta:"): vira a primeira linha do `texto.md`;
   - `Formato` (carrossel de N slides, reels, stories (N), post único);
   - `Tipo` e `Objetivo` (atrair, conscientizar, conectar, provar, converter);
   - `Pilar ou inimigo comum`: o pilar de `metodo.md` que dá a munição;
   - `Chamada para ação`: o CTA;
   - `Ideia central`: é a moral do texto;
   - `Caminho do post`: a ordem das ideias, que a Variação A segue;
   - "Para o /copy": estrutura sugerida, palavras da aluna (entram no texto) e o que não pode (vale como regra);
   - o modelo de post: a linha `Modelo:`, ou a "Estrutura sugerida" quando ela traz o nome de um dos 7 modelos (Foto, nicho e headline, Troque isso por isso, Foi assim que, Frase sobre foto, Esse é o segredo, Plano prático, Carrossel tweet);
   - `Uso:` (anúncio ou vitrine), se a pauta já disser. Se não disser, a etapa 2 pergunta.
   Use o que vier, mesmo com outro nome de campo.
4. Pauta com `texto.md` já feito, e a pessoa pediu essa pauta: é ajuste. Vá para a etapa 4 com o `texto.md` atual e salve como `texto-v2.md` na etapa 5.

## Passo 3. Uma linha para a pessoa

> Já li seu cérebro: sua aluna é [quem é, em 6 palavras], seu método é o [nome] e você fala [tom].

Com pauta, acrescente: "Peguei a pauta de [data]: [formato] sobre [tema], pilar [pilar], pra [objetivo]."

Se faltar algo que enfraquece a copy (método sem pilares, nenhum case autorizado), uma linha: "Ainda não tenho [o quê]. Sai sem isso, e depois vale completar no /brain."

Siga para a etapa 2.

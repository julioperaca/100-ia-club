# Etapa 5. Salvar

Tempo no encontro: 1 minuto.

Objetivo: deixar o texto escolhido no lugar onde a próxima skill vai buscar, pronto para copiar e colar.

## Passo 1. Conteúdo de Instagram: o texto.md

1. Grave `<pasta>/conteudo/<pasta do conteúdo>/texto.md` (Write) no formato de `${CLAUDE_SKILL_DIR}/modelos/texto.md`, só com a versão escolhida (ou a Variação A, se a pessoa não escolheu, e isso fica dito no `variacoes.md`).
2. Formato combinado com a skill `conteudo`, sem mudar nada: linha 1 `# <tema>`, linha 2 `Formato: <carrossel | reels | stories | post único>`, logo abaixo `Modelo: <nome do modelo ou livre>`, no carrossel `Uso: <anúncio | vitrine>` e, no Carrossel tweet, `Foto de perfil: <arquivo ou pedir>`; partes `## Slide N`, `## Gancho`, `## Roteiro`, `## CTA`, `## Story N`, `## Post`; sempre `## Legenda` no fim; dentro das partes, os rótulos `Título:`, `Apoio:`, `Texto:`, `Botão:`, `Figurinha:`, `Nicho:`, `Imagem:`, `Print:`. Nenhum outro título `##` e nenhum cabeçalho `>` no `texto.md`: estrutura, headline e fontes ficam no `variacoes.md`.
3. Com pauta: na `pauta.md` (Edit), troque só a linha `> Status: ...` por `> Status: texto pronto` e a linha `> Próximo passo: ...` por `> Próximo passo: rodar /conteudo montar para gerar as imagens`.
4. Se já existe um `texto.md` nessa pasta, não escreva por cima: grave `texto-v2.md` (ou `-v3`) e diga qual é o mais novo.
5. No `variacoes.md` (Edit): `Status: completo`, a seção "Como foi feita" (estrutura, modelo de headline e campeã, pilar, conferência) e "De onde veio cada dado" (cada número, case e expressão, com a fonte), e "Ajustes pedidos" com a data.

## Passo 2. Headline e CTA soltos

No arquivo de `<pasta>/copys/` gravado na etapa 4 (Edit), no formato de `${CLAUDE_SKILL_DIR}/modelos/copy-salva.md`:
1. "Versão final": a escolhida, limpa.
2. "Variação A" e "Variação B" ficam para consulta.
3. "Como foi feita", "De onde veio cada dado", "Ajustes pedidos".
4. Cabeçalho: `Status: completo` e `O que falta:` com o que ficou de fora (ou "nada").

Ajuste de algo já completo vira arquivo novo com `-v2` e anota no cabeçalho de qual veio.

## Passo 3. Fechar a conversa

Até 5 linhas:

> Salvei em [caminho curto, ex.: conteudo/2026-10-30-barriga-depois-dos-40/texto.md].
> Versão final: [A ou B], estrutura [nome], headline do modelo [P0X].
> Ficou de fora: [o que estava a confirmar, ou "nada"].
> Falta mandar: [cada `Imagem: pedir` e `Print: pedir`, em poucas palavras; ou tire esta linha]
> [Próximo passo, conforme a peça]

Próximo passo por peça (a última linha da conversa, sempre pronta):
- Carrossel, stories ou post único: "Texto pronto. Agora digite /conteudo montar para eu fazer as imagens."
- Reels: "Texto pronto. Grava olhando pra câmera, com o texto da tela do roteiro. Para a capa do reels, digite /conteudo montar."
- Legenda: "Cola no post. Se quiser outra versão pra testar, pede /copy outro ângulo."
- Headline ou CTA: "Usa a que você escolheu e guarda a outra pra testar depois."

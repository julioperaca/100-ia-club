# Etapa 2. Só o que falta: tema, formato, objetivo, CTA

Tempo no encontro: 2 minutos.

Objetivo: ter as respostas que o agente de copy da mentoria pede antes de escrever (objetivo, público, dor ou desejo, inimigo, solução, resultado buscado, formato e CTA), perguntando só o que o cérebro e a pauta não responderam. Uma pergunta por vez. No máximo 4.

O que já vem pronto, sem perguntar:
- público, dor e desejo, resultado buscado: `aluno-ideal.md`
- inimigo e solução: o pilar em `metodo.md`
- tudo que a pauta trouxe

## Pergunta 1. Tema (só sem pauta)

> Sobre o que você quer falar? Pode ser uma dor ou um desejo da tua aluna, um erro que ela comete, uma história que aconteceu. Se preferir, escolho um dos teus temas.

Se ela pedir para você escolher, ofereça 3 opções numeradas, cada uma ligando uma dor ou desejo de `aluno-ideal.md` a um pilar de `metodo.md` (ex.: "1. A barriga que não sai mesmo treinando (pilar Força que Evolui)").

Descubra o pilar sozinho: o tema conversa com o inimigo comum de qual pilar? Diga em uma linha qual escolheu.

## Pergunta 2. Formato (só se não veio)

> Vai virar o quê?
> 1. Carrossel
> 2. Reels
> 3. Stories
> 4. Só a legenda
> 5. Só a headline ou o CTA

## Pergunta 3. Objetivo e CTA (só se não veio)

Uma pergunta, já com o CTA dentro:

> No fim, o que você quer que ela faça?
> 1. Te seguir (pra mais conteúdo assim)
> 2. Te mandar mensagem no direct
> 3. Te chamar no WhatsApp

Se a pessoa falar "comentar uma palavra", explique em uma linha que o Peraça não recomenda em perfil pequeno (quase ninguém quer ser o primeiro a comentar) e ofereça o direct. Se ela insistir, faça.

Direct com palavra: use a palavra que ela já usa (veja `voz.md`); se não houver, sugira "QUERO".

## Pergunta 4. Contexto real (opcional, uma vez)

Só quando a melhor estrutura for História com moral, ou quando o tema pedir um gancho de contexto:

> Aconteceu alguma coisa real com isso? Uma mensagem de aluna, uma conversa na academia, algo seu. Se não, eu sigo sem.

Sem resposta ou "não": siga sem história. Nunca invente cena.

## Antes de seguir

Repita o pedido em uma linha, sem pedir confirmação:

> Combinado: [formato] sobre [tema], pilar [pilar], pra [objetivo/CTA]. Escrevendo as duas versões.

Siga para a etapa 3.

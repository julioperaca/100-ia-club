# Etapa 4. Conferência e "isso parece você?"

Tempo no encontro: 5 a 8 minutos.

Objetivo: só mostrar texto que passou na conferência, e só fechar quando a pessoa disser que parece ela.

## Passo 1. Gravar o rascunho

Grave as duas variações antes de mostrar, para nada se perder se a conversa fechar:

- **Conteúdo:** `<pasta>/conteudo/<pasta do conteúdo>/variacoes.md`. Com pauta, a pasta é a da pauta. Sem pauta, crie `<pasta>/conteudo/<AAAA-MM-DD>-<slug>/`, com a data de hoje e o tema em poucas palavras, minúsculo, sem acento, com hífen (`2026-10-30-barriga-depois-dos-40`). Se a pasta já existe e não é dessa peça, use `-2`.
- **Headline ou CTA soltos:** `<pasta>/copys/AAAA-MM-DD-<tipo>.md` (`headline`, `cta`). Se já existe, `-2`, `-3`. Nunca escreva por cima.

Formato: `${CLAUDE_SKILL_DIR}/modelos/texto.md` (parte "variacoes.md") ou `${CLAUDE_SKILL_DIR}/modelos/copy-salva.md`, com `Status: em andamento`.

## Passo 2. Conferência automática (Grep no arquivo)

Rode estas buscas com a ferramenta Grep no arquivo que acabou de gravar, uma por vez, com o padrão exatamente como está entre as crases. Cada uma precisa voltar vazia. Não precisa instalar nada.

1. Travessão (longo e curto): `[\x{2014}\x{2013}]`
2. Emoji: `[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}\x{1F000}-\x{1F2FF}]`
3. Palavras proibidas: `(?i)\b(descubra|desbloque\w*|eleve|elevar|mergulh\w*|revolucion\w*|jornada|incrível|poderos[oa]|mindset|consultoria)\b|transforme sua vida|imagine poder|próximo nível`
4. Clichês de IA: `(?i)ninguém te conta|se você chegou até aqui|você já parou pra pensar|já se pegou|no final do dia|no fim do dia|faz toda a diferença|e isso muda tudo|pense nisso|fica a reflexão|em resumo|saia da zona de conforto|acredite em você|basta querer|vamos falar sobre|hoje em dia|grátis|gratuit[oa]|de graça`
5. Acento faltando: `(?i)\b(nao|voce|tambem|entao|sessao|ate|so|ja)\b`
6. Promessa de saúde: `(?i)\b\d+\s?(kg|quilos?|cm)\b|\bgarantid[oa]\b|\bcura\b|emagre[cç]a em \d+`

"jornada" só reprova como clichê ("sua jornada"). "Jornada de trabalho" pode ficar. No item 6, número de quilos ou centímetros só fica se for relato de case autorizado, entre aspas, com o tempo que ela levou; "garantido" só fica se for uma garantia real do `negocio.md`.

Se o Grep não estiver disponível, faça a mesma conferência lendo o texto palavra por palavra.

Achou algo: corrija com Edit e rode a busca de novo.

## Passo 3. Conferência de leitura

Abra `${CLAUDE_SKILL_DIR}/referencias/anti-ia.md` e passe cada variação pela segurança, pelos 16 itens e pelos 5 itens do jeito do Peraça. Para cada item reprovado, reescreva o trecho com Edit usando a correção do próprio item. Depois confira as regras do formato em `referencias/formatos.md` (número de slides ou stories, limite de palavras, um CTA; anúncio com no máximo 10 slides; `Print:` logo depois de cada resultado afirmado, ou a frase moderada; `Nicho:` e `Imagem:` onde o modelo pede).

Item 8 (repetição de começo) no carrossel "Troque isso por isso": "Troque" abrindo o `Título:` e "Por" abrindo o `Texto:` de cada par é a estrutura do formato e não reprova. A exceção vale só para esses rótulos dos pares; no texto corrido (o resto do slide, a capa, a moral, a chamada e a legenda), o item 8 vale normalmente.

Só siga quando as duas passarem em tudo. Se depois de duas reescritas um item ainda falhar, troque a frase inteira por outra, mais simples.

## Passo 4. Mostrar

Na conversa, nesta ordem:

1. Variação A e Variação B, cada uma com Estrutura, Headline (modelo e campeã de origem), Pilar, Modelo e o texto.
2. Para cada `Print:`, uma linha dizendo por que ele está ali (ex.: "Pus o print no slide 6 porque ali eu digo que ela não faltou nenhuma semana, e quem lê pode duvidar.").
3. Uma linha: "Passou na conferência: 16 de 16 anti-IA, 5 de 5 do jeito do Peraça, e as buscas de travessão, emoji, palavras proibidas, acento e promessa de saúde vazias."
4. Se algo ficou de fora por estar "a confirmar", uma linha dizendo o quê.
5. A pergunta, exatamente assim:

> Isso parece você? Me diz qual das duas você prefere e o que você nunca falaria desse jeito. O Peraça sempre coloca a pitada dele: se quiser trocar alguma frase pelas suas palavras, me manda.

## Passo 5. Ajustar (até 3 voltas)

- "Gostei da A" ou "da B": essa é a escolhida. Pergunte só se quer mudar alguma frase; se não, etapa 5.
- "Eu não falo assim": troque pela palavra dela. Se ela não disser qual, ofereça duas opções tiradas dos textos reais de `voz.md`.
- Mandou a frase dela: entra do jeito que ela escreveu, só corrigindo travessão, emoji e acento.
- "Ficou comprido" ou "curto": ajuste o tamanho mantendo a estrutura.
- "Mistura as duas": junte, mas com uma estrutura e um modelo de headline, e declare quais.
- Pedido que fere uma regra (quilos prometidos, vaga que não existe, depoimento sem autorização, "consultoria"): explique em uma linha por que não entra e ofereça a versão segura.

Toda versão ajustada passa de novo pelos Passos 2 e 3 antes de ser mostrada.

Depois da terceira volta: "Essa é a minha melhor versão. Se quiser mexer depois, é só pedir /copy ajusta e dizer o que mudar."

Se a pessoa disser algo sobre a voz que vale para sempre ("eu nunca falo 'mulherada'"), diga no fim: "Para todas as skills saberem disso, rode: /brain atualiza: eu nunca falo 'mulherada'." Esta skill não escreve em `voz.md`.

Siga para a etapa 5.

# Etapa 3. Escrever as 2 variações

Tempo no encontro: 4 minutos.

Objetivo: duas versões completas, cada uma com uma estrutura do Peraça e um modelo de headline diferentes, na voz da pessoa.

## Passo 1. Abrir as referências

1. `${CLAUDE_SKILL_DIR}/referencias/jeito-do-peraca.md`: as 10 regras e as estruturas. Na primeira vez da conversa, leia inteiro.
2. `${CLAUDE_SKILL_DIR}/referencias/formatos.md`: só a seção do formato pedido e a de legenda.
3. `${CLAUDE_SKILL_DIR}/referencias/headlines.md`.

## Passo 2. Montar a munição (rascunho seu, não mostra)

Antes de escrever, preencha em poucas palavras, do cérebro:
- **Dor ou desejo:** a frase da aluna (Linguagem que ele usa), não a sua.
- **Inimigo comum:** o do pilar escolhido.
- **Argumento:** o porquê, do pilar (em linguagem de aluna, use a tabela de tradução do pilar se houver).
- **Solução:** o conceito do pilar, o que fazer. Não o como.
- **Prova:** case autorizado ou número, se houver.
- **Moral:** a conclusão em uma frase (com pauta, é a "Ideia central").
- **CTA:** o da pauta ou da etapa 2.
- **Palavras da aluna e o que não pode:** os da parte "Para o /copy" da pauta, se houver.

Se faltar inimigo ou argumento, use os Caminhos comuns de `metodo.md`. Se não houver nada, a variação usa História com moral ou PEPO mais leve e você avisa no fim.

## Passo 3. Escolher estrutura e headline de cada variação

- Pela tabela "Qual usar" de `jeito-do-peraca.md`: a variação A usa a primeira escolha para o objetivo; a B, outra estrutura.
- Com pauta: a Variação A segue o "Caminho do post" e a "Estrutura sugerida" da pauta, encaixadas na estrutura de copy mais próxima, e declara as duas.
- Para cada uma, um modelo de headline que combine (tabela no fim de `headlines.md`). Modelos diferentes nas duas.
- Escreva a headline por último, depois do resto (como o Peraça faz), mas já sabendo o modelo.

## Passo 4. Escrever na voz da pessoa

Siga o formato bloco a bloco (`formatos.md`), colocando a estrutura dentro dele. Enquanto escreve:

- **As palavras dela.** Pelo menos uma expressão de `voz.md` e uma frase da Linguagem da aluna em cada variação. Bordão, uma vez por peça no máximo.
- **Chame a aluna como ela chama.** "Menina" é "menina". Se ela usa "pra" e "tua", você usa.
- **Argumente.** Cada erro ou causa leva um porquê (regra 5).
- **Solução sem entregar tudo.** O que fazer e por que funciona; o detalhe do como fica para a conversa (regra 6).
- **Concreto.** Tempo, lugar, objeto, número do cérebro. Um detalhe concreto por slide, fala ou story.
- **Uma ideia por peça e uma moral.**
- **Um CTA só, no fim**, com a ação exata.

Nunca entra: preço "a confirmar", case sem autorização, número fora do cérebro, promessa de quilos, medidas ou prazo garantido, dieta, urgência não confirmada, a palavra "consultoria".

## Passo 5. Montar o rascunho de entrega

Para cada variação, deixe pronto (ainda não mostre):

```
Variação A
Estrutura: PCS (problema, causa, solução), seguindo a estrutura sugerida da pauta "erro comum e o certo"
Headline: modelo P04 do Peraça (É por isso que), que vem de "Why Some People Almost Always Make Money in the Stock Market"
Pilar: [nome]

### Slide 1
Título: É por isso que você *larga na quarta*
Apoio: Arrasta que eu te mostro.

### Slide 2
Texto: ...
...
### Legenda
...
```

Use exatamente as partes e os rótulos de `modelos/texto.md` (`Slide N`, `Gancho`, `Roteiro`, `CTA`, `Story N`, `Post`, `Legenda`; `Título:`, `Apoio:`, `Texto:`, `Botão:`, `Figurinha:`), porque a versão escolhida vai direto para o `texto.md`. Confira os limites: capa e gancho até 8 palavras no `Título:`, `Texto:` até 30 palavras no carrossel e 25 nos stories, um destaque com asteriscos por slide ou story.

Siga para a etapa 4. Nada é mostrado antes da conferência.

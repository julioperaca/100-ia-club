# oferta

Skill para o personal trainer montar a oferta do Programa Personalizado online em cerca de 45 minutos: entregas, bônus, garantia, preço e nome, com resumo de uma página e as mensagens de WhatsApp prontas. Sem chave, sem planilha e sem instalar nada.

## Como usar

No Claude, digite `/oferta` ou fale "cria minha oferta", "quanto eu cobro", "que bônus eu dou", "preciso de uma garantia".

Para mudar algo depois: `/oferta ajusta: quero tirar o bônus 2`.

## Antes

A skill `brain` precisa ter rodado: é de lá que vêm seus preços, sua aluna ideal, seu método, seus cases e sua voz. Sem a pasta `brain`, a skill avisa e para. Com o método pronto (`/criador-de-metodo`), a oferta sai melhor.

## O que ela faz

1. Lê o que você vende hoje e pergunta só o que falta (quantas fecham, objeções, quantas alunas você atende bem).
2. Dá nota para a oferta de hoje e mostra onde ela perde força.
3. Monta a oferta nova: entregas do seu método, bônus que respondem as objeções da sua aluna, garantia que você consegue cumprir, vagas e prazo só se forem verdadeiros, preço com a parcela na frente e um nome.
4. Revisa tudo contra os erros que derrubam uma oferta e contra promessa de saúde.
5. Entrega o resumo de uma página e de 5 a 8 mensagens de WhatsApp na sua voz.
6. Salva em `brain/ofertas/` e, se você aprovar, acrescenta a oferta no `negocio.md` sem apagar nada.

## O que ela nunca faz

- prometer quilos, centímetros, cura ou dieta;
- inventar vaga, prazo ou preço "de";
- mudar preço no ar ou mandar mensagem para alguém.

## Instalação

Copie a pasta `oferta` para `~/.claude/skills/` (no Windows, `C:\Users\<nome>\.claude\skills\`).

## Arquivos

| Arquivo | Para quê |
|---|---|
| `SKILL.md` | entrada, modos, contrato com o segundo cérebro, regras |
| `etapas/1-diagnosticar.md` a `etapas/4-revisar-e-entregar.md` | as 4 etapas |
| `referencias/guia-da-oferta.md` | equação de valor, bônus, garantia, escassez, preço, nome, erros, o que nunca prometer |
| `modelos/oferta-modelo.md` | formato do arquivo salvo em `brain/ofertas/` |

# Etapa 1. Diagnosticar a oferta de hoje

Tempo no encontro: 10 minutos.

Objetivo: entender o que ele vende hoje, por quanto, para quem e onde a oferta perde força, antes de propor qualquer coisa.

## Passo 1. Ler o contexto (sem perguntar nada)

Leia, nesta ordem:
1. `<pasta>/negocio.md`: tudo. Anote cada produto, preço, formas de pagamento, Histórico de preços, Como a venda acontece, Números e Provas.
2. `<pasta>/aluno-ideal.md`: Quem é, Ponto A, Ponto B, Objeções, Linguagem.
3. `<pasta>/metodo.md`: nome, promessa, pilares, O que o aluno recebe, Prazos, O que diferencia meu jeito.
4. `<pasta>/cases.md`: só os cases com `autorização para uso público: sim`.
5. `<pasta>/voz.md`: Tom, Expressões, Como eu chamo o aluno, O que eu nunca digo.
6. `<pasta>/perfil-profissional.md`: as linhas `nome_publico`, `whatsapp`, `forma_entrega`, `prazo_resposta`.

Se `metodo.md` estiver com `Status: vazio`, avise em uma linha ("Seu método ainda está vazio; vou montar as entregas com o que está no negocio.md. Depois vale rodar /criador-de-metodo.") e siga. Se `negocio.md` não tiver nenhum produto com preço, pergunte o que vende e por quanto antes de tudo.

## Passo 2. Mostrar o que entendeu

Em uma mensagem só:

> Pelo seu segundo cérebro, hoje você vende:
> 1. [produto]: [duração], [preço como está no arquivo], [o que inclui em uma linha].
> 2. ...
> Para: [aluna ideal em uma linha].
> Seu método: [nome], com a promessa "[promessa]".
> Prova que posso usar: [case autorizado ou anos de profissão e número de alunas].
> Está certo? Se algo mudou, me fala.

Preço marcado "a confirmar" no arquivo: pergunte aqui.

## Passo 3. Perguntar só o que falta (uma por vez)

Pergunte apenas o que não está no cérebro. "Não sei" e "pula" são respostas aceitas; registre como "a confirmar".

1. **Fechamento:** "De cada 10 pessoas que te chamam perguntando do programa, mais ou menos quantas fecham?"
2. **Objeções:** "Quando alguém não fecha, o que ela costuma dizer? Me fala as 3 frases que você mais ouve." (pule se `aluno-ideal.md` já tiver Objeções preenchidas; mostre as de lá e pergunte se falta alguma)
3. **Capacidade:** "Quantas alunas você consegue atender bem ao mesmo tempo, sem perder qualidade? E quantas você tem hoje?"
4. **Alternativa real:** "Você atende presencial? Quanto cobra a aula?" (se não atende, "Quanto um personal presencial cobra a aula na tua cidade, mais ou menos?" e registre como estimativa dele)
5. **Pagamento:** "No cartão, em quantas vezes você parcela, e os juros ficam com você ou com a aluna?" (pule se o arquivo já disser)

Se o fechamento for de 7 ou mais em 10, avise: "Você fecha muito. Isso costuma querer dizer que o preço está baixo para o que você entrega." Se for de 2 ou menos, avise: "O problema pode estar na conversa de venda, e não só na oferta. Leve isso para o encontro de quinta."

## Passo 4. Dar as notas da oferta de hoje

Leia `${CLAUDE_SKILL_DIR}/referencias/guia-da-oferta.md`, seção 1. Dê nota de 1 a 5 para a oferta atual nas 4 perguntas, cada uma com o porquê em uma frase e a fonte:

> Diagnóstico da oferta de hoje:
> 1. Resultado concreto: [nota]/5. [porquê]
> 2. Certeza de que vai conseguir: [nota]/5. [porquê]
> 3. Rapidez para sentir diferença: [nota]/5. [porquê]
> 4. Pouco esforço para ela: [nota]/5. [porquê]
> Onde a oferta mais ganha: [a nota mais baixa], porque [frase].

Feche a etapa com: "Agora vou montar a oferta nova em cima disso." Siga para a etapa 2 sem esperar outra resposta, a não ser que a pessoa corrija algo.

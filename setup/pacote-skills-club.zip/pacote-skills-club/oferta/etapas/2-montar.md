# Etapa 2. Montar: valor, entregas e bônus

Tempo no encontro: 15 minutos.

Antes de começar, tenha à mão `${CLAUDE_SKILL_DIR}/referencias/guia-da-oferta.md`, seções 1 a 3.

## Passo 1. Decidir o que é a oferta nova

Decida e mostre em 3 linhas:
- **Base:** qual produto de hoje vira a oferta nova, ou se é um produto novo. Se o `metodo.md` tem prazo de Ponto B (ex.: 4 meses) e nenhum plano tem essa duração, proponha um plano com a duração do método: a promessa e o prazo passam a casar.
- **Resultado que ela compra:** o Ponto B em palavras da aluna (use a Linguagem de `aluno-ideal.md`), sem número de balança.
- **Para quem é e para quem não é:** uma linha cada.

## Passo 2. Entregas do método

Monte a tabela "dor, como fazer para, entrega" (guia, seção 2) com 4 a 8 linhas. Regras:
- Toda entrega vem de `metodo.md` (O que o aluno recebe, pilares) ou de `negocio.md` (o que está incluído). Cite a fonte.
- Entrega que ele já faz e não conta (correção por vídeo, mensagem de segunda) entra com destaque: é valor que já existe.
- Não acrescente entrega que ele não faz hoje sem perguntar: "Você conseguiria fazer [X] para todas as alunas?"

## Passo 3. Bônus que derrubam objeções

1. Liste as objeções: as de `aluno-ideal.md` e as que ele disse na etapa 1. Se não houver nenhuma, use as 3 mais comuns do guia e marque "(objeção comum, a confirmar com o personal)".
2. Para cada objeção forte, proponha um bônus (guia, seção 3). De 2 a 4 bônus no total.
3. Mostre assim:

> Bônus que proponho:
> 1. [Nome com benefício]: [o que é, em uma linha]. Derruba: "[objeção]". Você entrega assim: [como, quanto tempo leva].
> 2. ...
> Você consegue entregar esses para todas as alunas que entrarem?

4. Para cada bônus, pergunte o valor real só se ele já vende ou venderia aquilo avulso ("Você cobraria quanto por uma chamada avulsa dessas?"). Sem preço real, o bônus fica "incluído", sem número.
5. Ajuste o que ele pedir. Se ele recusar todos, ofereça uma troca, não insista.

## Passo 4. Nova nota

Refaça as 4 notas da equação de valor com a oferta nova e mostre lado a lado:

> | Pergunta | Hoje | Oferta nova | O que mudou |
> |---|---|---|---|

Se alguma nota não subiu, diga em uma frase o que poderia subir e siga. Nota nova nunca é 5 em "certeza de que vai conseguir" sem case autorizado.

## Salvar no meio

Se a pessoa parar aqui, grave o arquivo da oferta (etapa 4, Passo 4) com `Status: em andamento` e "O que falta: garantia, escassez, preço, nome, revisão".

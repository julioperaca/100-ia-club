# Etapa 4. Revisar, entregar e salvar

Tempo no encontro: 10 minutos.

## Passo 1. Revisão dos erros

Passe a oferta inteira pela tabela da seção 8 do guia (`${CLAUDE_SKILL_DIR}/referencias/guia-da-oferta.md`) e pela seção 9 (o que nunca prometer). Corrija o que falhar antes de mostrar. Mostre o resultado em uma linha por item que passou com ajuste ("Bônus 3 tirado: não derrubava nenhuma objeção") e uma linha final: "Revisão: 10 de 10 itens conferidos."

## Passo 2. Resumo de uma página

Na conversa, no formato da seção "Resumo de uma página" do modelo `${CLAUDE_SKILL_DIR}/modelos/oferta-modelo.md`. Cabe numa tela de celular rolando pouco: nome, para quem, resultado, entregas, bônus, garantia, escassez (ou "sem escassez: não existe uma verdadeira"), preço na ordem certa, prova.

## Passo 3. Mensagens de WhatsApp

Escreva de 5 a 8 mensagens curtas, para mandar uma depois da outra para quem já conversou com ele e pediu para saber como funciona. Regras:

1. **Na voz dele:** use o Tom, as Expressões e o jeito de chamar a aluna de `voz.md`. Nada que esteja em "O que eu nunca digo".
2. **Curtas:** de 1 a 4 linhas cada. Uma ideia por mensagem.
3. **Ordem:**
   1. retoma o que ela contou (dor dela, com as palavras da Linguagem de `aluno-ideal.md`), com espaço para o personal trocar pelo que ela disse de verdade: `[o que ela te contou]`;
   2. o que é a oferta e o resultado que ela busca, sem número de balança;
   3. como funciona: as entregas principais;
   4. os bônus, cada um ligado à objeção que derruba;
   5. a garantia, com o nome;
   6. a prova: case autorizado, com as palavras da aluna (pule se não houver case autorizado e use anos de profissão e alunas atendidas);
   7. o preço: parcela primeiro, depois comparação e valor por dia, por último o à vista; escassez só se for verdadeira, com o motivo;
   8. o próximo passo, com uma pergunta simples ("Quer que eu te mande o link?" ou "Prefere parcelado ou à vista?").
4. **Sem pressão falsa:** nada de "só hoje", "últimas vagas" sem número real, "corre".
5. **Forma:** sem travessão, sem emoji, sem as palavras proibidas da regra 7 do SKILL.md.

Mostre cada mensagem em um bloco separado, numerado, pronto para copiar.

## Passo 4. Salvar a oferta

1. Nome do arquivo: `ofertas/AAAA-MM-DD-<nome>.md`, com a data de hoje e o nome da oferta em minúsculas, sem acento, palavras ligadas por hífen (ex.: `ofertas/2026-10-30-calca-fecha-4-meses.md`).
2. Leia `${CLAUDE_SKILL_DIR}/modelos/oferta-modelo.md` e preencha todas as seções, cada item com fonte e data.
3. Write se o arquivo não existe. Se já existe (mesma oferta, mesmo dia), Edit, sem apagar; mudanças vão para "Histórico de mudanças".
4. Status: `completo` se a pessoa aprovou a oferta; `em andamento` se não. "O que falta": o que ficou "a confirmar".
5. Confirme em uma linha: "Anotado em ofertas/[arquivo]: oferta completa."

## Passo 5. Atualizar o negocio.md (só com aprovação)

Pergunte uma vez: "Quer que eu coloque essa oferta no seu negocio.md, para as outras skills (copy, conteúdo) já usarem?"

Se a resposta não for um sim claro, não mexa no `negocio.md`. Diga onde a oferta ficou salva e siga para o fechamento.

Se sim, só por Edit e só acrescentando:
1. **Produto novo:** acrescente um bloco `### Produto N` (N = próximo número) depois do último produto, antes de `## Histórico de preços`, com os mesmos campos dos outros (nome, formato, duração, preço, formas de pagamento, o que está incluído, para quem é), cada um com a fonte "(oferta aprovada na conversa, dd/mm/aaaa; detalhes em ofertas/[arquivo])".
2. **Produto antigo com preço novo:** troque só o valor na linha `- preço:` do produto e acrescente em `## Histórico de preços` a linha "- [produto]: [preço antigo, exatamente como estava] até dd/mm/aaaa ([fonte antiga])". O valor antigo nunca some do arquivo.
3. **Produto antigo que deixa de ser vendido:** não apague o bloco. Acrescente no fim dele a linha "- situação: deixou de ser vendido em dd/mm/aaaa, no lugar entrou [oferta] (conversa, dd/mm/aaaa)". Só faça isso se a pessoa disser que vai parar de vender.
4. **Cabeçalho:** atualize "Última atualização" para hoje. Em "O que falta", tire só o item que esta oferta respondeu (ex.: o parcelamento confirmado) e mantenha o resto.
5. Nunca mexa em outras seções (história, diferencial, números, provas).
6. Releia o `negocio.md` e confira: todos os produtos e todas as linhas de Histórico de preços de antes continuam lá.
7. Confirme em uma linha: "Anotado em negocio.md: Produto 3, [nome], [parcela] ou [à vista] (nada foi apagado; preço antigo, se mudou, está no histórico)."

Se a pessoa contou objeções novas ou o número de fechamento na etapa 1, sugira em uma linha: "As objeções que você me contou valem ir para o seu aluno-ideal.md. É só dizer /brain atualiza: e colar."

## Passo 6. Conferir

- Grep no arquivo da oferta pelos dois tipos de travessão (caracteres Unicode U+2014 e U+2013): zero.
- Nenhum emoji no arquivo nem nas mensagens.
- Toda parcela vezes o número de parcelas bate com o total escrito.
- Todo case citado está com autorização sim em `cases.md`.
- Nenhum "consultoria" no arquivo nem nas mensagens: o produto é "Programa Personalizado", com iniciais maiúsculas (ou o nome próprio dele).

## Fechamento (na conversa)

> Pronto, sua oferta está no segundo cérebro.
> 1. Nome: [nome].
> 2. Preço: [parcela], ou [à vista].
> 3. Bônus: [nomes].
> 4. Garantia: [nome].
> 5. Arquivo: ofertas/[arquivo], na pasta brain.
> 6. Para mudar algo depois: "/oferta ajusta: [o que mudar]".
>
> Próximo passo: mandar a oferta nova para as 3 últimas pessoas que perguntaram e não fecharam.

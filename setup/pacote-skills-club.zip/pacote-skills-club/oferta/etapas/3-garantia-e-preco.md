# Etapa 3. Garantia, escassez, preço e nome

Tempo no encontro: 10 minutos.

Use `${CLAUDE_SKILL_DIR}/referencias/guia-da-oferta.md`, seções 4 a 7.

## Passo 1. Garantia

Proponha uma garantia no formato "Se você [fizer a parte dela] e [o que pode não acontecer] em [prazo], eu [o que o personal faz]". Prefira a condicional com tempo extra (guia, seção 4): ela depende do esforço da aluna e do trabalho do personal, nunca do corpo dela.

> Garantia que proponho: "[nome da garantia]". [texto completo]
> Por que essa: [uma frase].
> Pergunta: se todas as alunas pedirem, você consegue cumprir?

Se ele hesitar, diminua (prazo menor, um mês extra em vez de devolução). Se ele quiser garantir quilos ou centímetros, explique em uma frase por que não ("o corpo dela depende de sono, comida e hormônio, que você não controla; a garantia tem que ser sobre o que você controla") e mantenha a sua proposta.

## Passo 2. Escassez e urgência

Com os números da etapa 1:
- Se ele disse quantas atende bem (N) e quantas tem hoje (M), e sobram vagas: "Vagas abertas: N menos M, porque [motivo real: cada aluna tem correção por vídeo e ajuste mensal com você]."
- Se não disse, ou se as vagas são muitas (mais de 15), a oferta sai sem escassez de vagas.
- Urgência: pergunte uma vez "Tem alguma data de verdade? Turma que começa junto, preço que vai subir, bônus que acaba?" Se não tiver, a oferta sai sem urgência.

Diga sempre o que ficou de fora e por quê: "Não coloquei prazo porque não existe um de verdade. Prazo inventado queima tua confiança."

## Passo 3. Preço

1. Faça a conta por mês da oferta de hoje (preço dividido pelos meses) e mostre.
2. Proponha o preço novo: à vista e parcelado, com parcela limpa. Justifique em uma frase ligando a mais valor (bônus, garantia, prazo do método). Confira a conta: parcela vezes número de parcelas.
3. Monte a ancoragem honesta (guia, seção 6), só com valores que existem:

> Comparação que você pode usar:
> 1. [alternativa real]: [conta] = R$ [valor] (fonte: [o que ele disse]).
> 2. Seus preços de hoje para o mesmo período: R$ [valor].
> 3. Bônus com preço real: [nome] R$ [valor]; os outros, incluídos.

4. Mostre a ordem de apresentação: parcela, depois comparação e valor por dia, por último o à vista.

Se ele quiser outro preço, aceite e refaça as contas. Se ele quiser um preço "de" maior para riscar, recuse em uma frase e use a comparação com a alternativa real no lugar.

## Passo 4. Nome

Proponha 3 nomes (guia, seção 7), recomende um e diga por quê. Use o nome do método se existir. Confirme a escolha.

## Salvar no meio

Se a pessoa parar aqui, grave o arquivo da oferta (etapa 4, Passo 4) com `Status: em andamento` e "O que falta: revisão, resumo, mensagens".

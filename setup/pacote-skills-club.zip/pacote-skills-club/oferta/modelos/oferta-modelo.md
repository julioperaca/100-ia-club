# Oferta: [nome da oferta]

> O que é: a oferta montada com a skill de oferta, com resumo, contas e mensagens de WhatsApp.
> Última atualização: [dd/mm/aaaa]
> Status: [em andamento ou completo]
> O que falta: [o que ficou "a confirmar", ou "nada"]

Cada item termina com a fonte entre parênteses. O que ainda não se sabe fica escrito "a confirmar".

## Resumo de uma página

**[Nome da oferta]**
Para: [quem é, em uma linha]
Resultado que ela busca: [Ponto B nas palavras dela, sem número de balança]
Duração: [prazo]

O que ela recebe:
1. [entrega]
2. ...

Bônus:
1. [nome]: [o que é]. Para quem diz "[objeção]".
2. ...

Garantia: [nome]. [texto completo]

Vagas e prazo: [vagas reais com o motivo] ou "sem escassez: não existe uma verdadeira hoje". [prazo real] ou "sem prazo".

Preço: [parcela] no cartão. [comparação honesta]. [valor por dia]. À vista: [valor].

Prova: [case autorizado com as palavras da aluna] ou [anos de profissão, alunas atendidas].

## Diagnóstico da oferta de hoje

- O que vendia: [produtos e preços] (negocio.md)
- Fechamento: [x de cada 10] ou a confirmar (conversa, dd/mm/aaaa)
- Capacidade: atende bem até [N], tem hoje [M] (conversa, dd/mm/aaaa)

| Pergunta | Hoje | Oferta nova | O que mudou |
|---|---|---|---|
| Resultado concreto | /5 | /5 | |
| Certeza de que vai conseguir | /5 | /5 | |
| Rapidez para sentir diferença | /5 | /5 | |
| Pouco esforço para ela | /5 | /5 | |

## Entregas

| Dor | Como fazer para | Entrega | Fonte |
|---|---|---|---|

## Bônus

### Bônus 1: [nome com benefício]
- derruba a objeção: "[objeção]" (fonte)
- o que é: 
- como o personal entrega: 
- valor: R$ [preço real avulso] (fonte) ou "incluído"

## Garantia

- nome: 
- texto: "Se você [...], eu [...]."
- condição que ela cumpre e como o personal confere: 
- o que o personal faz: 
- lembrete legal: na compra pela internet, a aluna já tem 7 dias de arrependimento por lei.

## Escassez e urgência

- vagas: [N menos M, motivo] ou "sem escassez" (fonte)
- prazo: [data real e por quê] ou "sem prazo" (fonte)

## Preço e ancoragem

- oferta de hoje por mês: [contas]
- preço novo: [parcela] x [n] = R$ [total no cartão]; à vista R$ [valor] (proposta aprovada na conversa, dd/mm/aaaa)
- por mês: R$ [valor]; por dia: menos de R$ [valor]
- comparações honestas:
  1. [alternativa real]: [conta] = R$ [valor] (fonte)
  2. [preços de hoje para o mesmo período]: R$ [valor] (negocio.md)
- ordem de apresentação: parcela, comparação, valor por dia, à vista.

## Nome

- escolhido: [nome] (proposta aprovada na conversa, dd/mm/aaaa)
- considerados: [nome 2]; [nome 3]

## Revisão dos erros

- [x] não dá para comparar só pelo preço
- [x] cada bônus derruba uma objeção
- [x] garantia com "se você fizer, eu faço", possível de cumprir
- [x] escassez e prazo verdadeiros (ou ausentes)
- [x] nenhum preço "de" inventado
- [x] parcela antes do total
- [x] nenhuma promessa de saúde
- [x] nenhuma entrega sobrando
- [x] agenda dá conta se todas as vagas entrarem
- [x] cases só com autorização

## Mensagens de WhatsApp

Para mandar uma depois da outra, a quem já pediu para saber como funciona. Troque o que estiver entre colchetes pelo que a pessoa te contou.

### Mensagem 1
### Mensagem 2
(até 8)

## Histórico de mudanças

- [dd/mm/aaaa]: primeira versão (skill de oferta).

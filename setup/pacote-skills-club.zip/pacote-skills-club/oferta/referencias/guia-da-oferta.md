# Guia da oferta

Base de todas as etapas. Linguagem simples, exemplos de Programa Personalizado online de treino.

## 1. A equação de valor (em 4 perguntas)

Uma oferta vale mais quando a pessoa sente que:

1. **O resultado é grande e concreto.** "Voltar a fechar a calça jeans antiga" vale mais que "emagrecer". Use o Ponto B do `aluno-ideal.md` e a promessa do `metodo.md`.
2. **Ela vai conseguir.** Prova (case autorizado, anos de profissão, número de alunas), garantia e um método com passos claros aumentam a certeza.
3. **Não vai demorar para sentir diferença.** Prazo do Ponto B e, principalmente, uma primeira vitória rápida (treino pronto em 3 dias, correção na primeira semana).
4. **Não vai dar trabalho demais.** Treino curto, em casa, sem material caro, alguém lembrando e ajustando.

Os dois primeiros aumentam o valor; os dois últimos, quando diminuem, também aumentam. Para cada pergunta, dê uma nota de 1 a 5 para a oferta de hoje e diga por quê em uma frase. A nota mais baixa é onde a oferta nova mais ganha.

Atalho de percepção: muitas vezes não é preciso mudar o serviço, e sim mostrar o que já existe. Correção por vídeo, mensagem de segunda e ajuste mensal são entregas que muitos personais fazem e não contam.

## 2. Entregas: do problema à solução

Para cada dor do Ponto A, escreva "Como fazer para..." e diga qual entrega do método resolve:

| Dor | Como fazer para | Entrega |
|---|---|---|
| não tenho tempo | treinar em 40 minutos, em casa, no horário que sobra | treino no app montado para a rotina |
| largo na segunda | voltar no mesmo dia depois de um fim de semana fora do plano | mensagem de presença toda segunda |
| não sei se estou fazendo certo | treinar com a técnica certa desde a primeira semana | correção por vídeo |

Ferramenta pronta (lista, plano curto, roteiro) vale mais que aula, porque dá menos trabalho para a aluna.

## 3. Bônus

Regras:
1. **Cada bônus derruba uma objeção específica** da aluna ideal. Sem objeção, sem bônus.
2. **Nome com o benefício.** Não "PDF de exercícios", e sim "Plano B de 20 Minutos para a semana que aperta".
3. **Prefira ferramenta a conteúdo:** lista, plano pronto, roteiro, chamada curta com objetivo.
4. **Resolva o próximo problema** antes que ela tropece nele (o material que ela não tem, a semana de viagem, o mês 2 em que muita gente larga).
5. **O personal precisa conseguir entregar** para todas as alunas que entrarem. Bônus que estoura a agenda vira problema.
6. **Valor só com preço real.** Se ele vende ou venderia aquilo avulso, por quanto? Se não tem preço real, o bônus aparece como "incluído", sem número.
7. **Bônus de parceiro** (desconto com nutricionista, loja de material) só se a parceria existir ou ele confirmar que vai fechar.
8. **2 a 4 bônus.** Mais que isso parece enchimento.
9. **Desconto nunca substitui bônus.** Na hora de fechar, acrescentar valor é melhor que baixar preço.

Objeções comuns e bônus que respondem:

| Objeção | Bônus possível |
|---|---|
| "Não tenho tempo" | versão curta de cada treino para os dias corridos |
| "Não tenho material em casa" | lista do material básico com preço de referência e primeira semana só com o peso do corpo |
| "Já tentei e não consegui manter" | chamada de revisão no mês em que mais gente larga |
| "Tenho medo de me machucar" | correção de execução por vídeo nas primeiras semanas |
| "Viajo muito" | treino de hotel e de quarto |
| "Não sei se funciona pra mim" | case autorizado de alguém parecido com ela |

## 4. Garantia

A maior trava de quem compra é o medo de pagar e não dar certo. Garantia tira esse peso de cima dela.

Estrutura: **"Se você [fizer a parte dela] e [o que pode não acontecer] em [prazo], eu [o que o personal faz]."** Sem a parte do que o personal faz, a garantia soa fraca.

Tipos que um personal consegue cumprir:

| Tipo | Exemplo | Quando |
|---|---|---|
| Satisfação no começo | "Nos primeiros 7 dias, se não for pra você, devolvo tudo." | Lembrete: na compra pela internet, 7 dias de arrependimento já são direito dela por lei. Use como base, não como diferencial. |
| Condicional com tempo extra | "Se você fizer os 3 treinos por semana e mandar o check-in de segunda por 30 dias e sentir que o treino não cabe na tua rotina, eu refaço o plano do zero e te dou mais um mês sem custo." | A mais indicada: premia quem se esforça e depende do personal, não do corpo dela. |
| Condicional com devolução | "Se fizer tudo combinado por 60 dias e achar que não valeu, devolvo o valor." | Só se ele tiver caixa e tranquilidade para devolver. |

Regras da garantia:
1. A condição é algo que ela controla e que ele consegue conferir (treinos registrados no app, check-in respondido).
2. O que ele promete é algo que ele controla: refazer, ajustar, dar tempo extra, devolver.
3. **Nunca** garantir quilos, centímetros, exame, cura ou "resultado em X dias".
4. Dê um nome à garantia com o benefício ("Garantia do Treino que Cabe").
5. Pergunte se ele aguenta cumprir para 100% das alunas. Se hesitar, diminua.

## 5. Escassez e urgência (só as verdadeiras)

Escassez falsa queima a confiança de vez. Se não existir uma verdadeira, a oferta sai sem.

Verdadeiras para personal:
- **Vagas:** ele atende bem até N alunas e tem M hoje. Vagas = N menos M. Precisa dos dois números.
- **Turma com data:** as novas alunas começam todas juntas numa data real.
- **Preço que sobe:** o preço muda numa data e não volta. Só se ele vai mesmo subir.
- **Bônus com limite real:** a chamada de revisão é só para as primeiras X porque a agenda dele só tem X horários.

Nunca: contador que reinicia, "últimas vagas" que nunca acabam, prazo que é estendido quando alguém pede, "só hoje" que volta semana que vem, preço "de" que ninguém nunca pagou.

## 6. Preço e ancoragem

Princípios:
1. **Preço pelo valor, não pelo concorrente.** Quem compete pelo menor preço sempre perde para alguém mais barato.
2. **Âncora honesta:** compare com algo que existe e que ela entende.
   - quanto custaria a alternativa real (presencial 3 vezes por semana no mesmo período, pelo preço que ele cobra ou cobraria a aula);
   - os preços atuais dele somados para o mesmo período;
   - o valor avulso real de cada bônus que tem preço.
3. **Ordem da apresentação:** primeiro a parcela; depois o que mostra que vale (comparação com a alternativa, valor por dia); por último o à vista. Nunca abrir pelo total.
4. **Valor por dia** ajuda: parcela dividida por 30, arredondada para cima ("menos de R$ 3 por dia").
5. **Arredonde a parcela** para um número limpo (R$ 89,70 ou R$ 97) e confira a conta do total (parcela x número de parcelas). Pergunte se a maquininha ou plataforma dele cobra juros da aluna ou dele: isso muda o à vista.
6. **Subir preço com mais valor.** Se a oferta nova entrega mais (bônus, garantia, prazo certo do método), é natural custar mais por mês que o plano antigo. Mostre a conta por mês nos dois.
7. **Desconto só em troca de algo** (pagar à vista, plano mais longo), nunca porque ela pediu.

## 7. Nome da oferta

Um bom nome junta 3 a 4 destes elementos: o nome do método ou um jeito próprio de fazer; para quem é; o benefício que ela entende; o prazo.

Modelo: "[Método ou jeito próprio]: [benefício] em [prazo] para [quem]".

Exemplos:
- "Calça Fecha 4 Meses: treino de 40 minutos em casa para mães que trabalham fora"
- "Método 3x40: força em casa em 12 semanas para mulheres sem tempo"

Proponha 3 nomes, recomende um e diga por quê. Teste: dá para comparar com o "plano trimestral" de qualquer outro personal? Se dá, o nome está genérico.

## 8. Os erros que derrubam uma oferta (revisão final)

| Erro | Pergunta de conferência |
|---|---|
| Oferta igual à de todo mundo | Dá para comparar só pelo preço com outro personal? |
| Bônus de enfeite | Cada bônus derruba uma objeção nomeada? |
| Garantia fraca ou impossível | Tem "se você fizer, eu faço"? Ele consegue cumprir para todas? |
| Escassez ou prazo falso | Os números das vagas e as datas são reais? |
| Preço "de" inventado | Cada valor de comparação existe de verdade? |
| Abrir pelo total | A parcela aparece antes do total em todo texto? |
| Promessa de saúde | Tem quilo, centímetro, cura ou prazo de resultado no corpo garantido? |
| Oferta inchada | Cada entrega resolve um problema da aluna? |
| Agenda estourada | Se entrarem todas as vagas, ele dá conta de tudo que prometeu? |
| Case sem autorização | Todo case citado está com autorização sim? |

Qualquer "sim" para um erro: corrija antes de entregar.

## 9. O que nunca prometer

- quilos, centímetros, percentual de gordura ou exame garantidos;
- cura, tratamento ou melhora de doença, dor ou lesão;
- dieta, cardápio ou suplemento (alimentação é com nutricionista);
- resultado em X dias como certeza ("em 30 dias você vai...").

Pode dizer: o Ponto B como objetivo do método, o case autorizado com as palavras da aluna e o que ela vai receber e fazer.

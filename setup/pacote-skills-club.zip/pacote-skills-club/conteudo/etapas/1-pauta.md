# Modo Pauta. Decidir o que postar

Tempo no encontro: 10 minutos.

Antes de começar, leia `${CLAUDE_SKILL_DIR}/referencias/jeito-do-peraca.md`. Ele é a régua de cada decisão abaixo. Leia também `${CLAUDE_SKILL_DIR}/referencias/formatos.md`: são os 7 modelos de post (Foto, nicho e headline; Troque isso por isso; Foi assim que; Frase sobre foto; Esse é o segredo; Plano prático; Carrossel tweet) e as regras que valem para todos (tamanho, anúncio ou vitrine, prova com print, imagens).

## Passo 1. Ler o cérebro antes de perguntar

Leia `negocio.md`, `aluno-ideal.md`, `metodo.md`, `cases.md` e `voz.md`. Não mostre o que leu; anote para você:
- 3 a 5 temas inevitáveis: as dores e desejos mais fortes do Ponto A e do Ponto B, com as palavras da seção "Linguagem".
- 2 a 3 temas complementares.
- Os pilares do `metodo.md` com conceito, inimigo comum e argumentos; os caminhos comuns.
- Cases com autorização "sim".
- O momento do negócio: seguidores, se vai abrir turma e quando, como a venda acontece.
- Se já existem pautas em `<pasta>/conteudo/` (para não repetir tema da semana anterior).

Se `metodo.md` está vazio ou sem pilares: avise uma vez ("Seu método ainda não está no cérebro, então as pautas vão se ligar às dores da sua aluna. Quando você contar seu método ao /brain, elas ficam mais fortes.") e siga, sem inventar pilar.

## Passo 2. Uma pergunta só

Se a pessoa veio do Modo Espiar e escolheu ideias, pule esta pergunta: monte uma pauta por ideia escolhida (ou a semana inteira com elas, se disse "todas"), usando o formato e o gancho da ideia como ponto de partida e citando em "Por quê" de onde ela veio (`espiao/<arquivo>.md`). Se `$ARGUMENTS` já diz semana ou post, pule também. Senão:

> Monto a sua semana (5 pautas) ou a pauta de um post só?

"Um post": pergunte "Já tem tema na cabeça ou eu escolho?" e monte 1 pauta (ou 3 opções de tema para ela escolher, se ela pedir para escolher).

## Passo 3. Escolher o plano da semana

Decida sozinho, pela régua (seções 3, 7 e 9 da referência), e diga o plano em uma linha antes das pautas:
- Perfil pequeno ou começando: 3 posts de atrair ou conscientizar, 1 de conectar, 1 de provar; nada de oferta direta no feed.
- Turma abrindo em até 4 semanas: diga em que semana do aquecimento ela está e puxe o mix (semanas 1 e 2 mais conscientizar; 3 caminho e prova; 4 prova e oferta).
- Sem campanha: 2 conscientizar, 1 atrair, 1 conectar, 1 provar.
- A maioria dos posts é de tema inevitável. Pelo menos 1 pauta por pilar do método ao longo da semana, e pelo menos 1 pauta ataca um inimigo comum.
- 5 pautas = 3 a 4 posts de feed (mínimo do Peraça: 3 por semana) mais 1 a 2 sequências de stories. Não repita formato em dias seguidos.
- Datas: a partir do próximo dia útil, nos dias que fizerem sentido (ex.: segunda, terça, quarta, quinta, sexta). Use a data real.

## Passo 4. Montar as pautas

Para cada pauta decida: tema (desejo, específico, palavras da aluna), tipo, objetivo, pilar ou inimigo comum, formato, chamada (seguir, direct, avaliação ou palavra), ideia central e o caminho do post.

Modelos: para cada pauta de feed, confira em `formatos.md` se a condição de "Quando sugerir" de algum dos 7 modelos bate com o cérebro (case autorizado, inimigo comum com vários hábitos, objeção principal, frase da voz). Se bater, use o modelo e escreva o nome exato dele na pauta; o caminho do post segue a estrutura dele, adaptada ao tema. Na semana, pelo menos 2 pautas usam um modelo. Não repita o mesmo modelo em dias seguidos nem em duas semanas seguidas (veja as pautas que já existem em `conteudo/`). "Foi assim que" só com case de autorização "sim".

Modelos da pessoa: liste com Glob `<pasta>/meus-modelos/*.md`. Cada arquivo é um modelo que ela criou, com "Quando sugerir" e "Estrutura". Eles entram na escolha junto com os 7, e têm preferência quando a condição bate: foram feitos por ela. Na pauta, escreva o nome exato do modelo e marque `(meu modelo)` depois dele, por exemplo `Modelo: Mito ou verdade (meu modelo)`. Se a pessoa pediu "no modelo X" e X é um modelo dela, use esse.

Confira cada uma antes de mostrar:
- O tema passa no teste da amiga no banheiro da festa? Não é o "como"?
- A solução é o método (ou o inimigo comum rebatido pelo argumento do pilar)?
- Tem moral da história clara?
- Prova só de case autorizado. Nada de promessa de quilos, prazo de resultado, dieta.
- Zero travessão, zero emoji.

Mostre assim, uma pauta por bloco, curto:

> Plano da semana: turma abre em 4 semanas e você tem 3.800 seguidores, então esta semana é de conscientizar, com uma prova no fim.
>
> **1. Segunda, carrossel de 10 slides, modelo Troque isso por isso**
> Tema: [tema]
> Objetivo: conscientizar | Tipo: inevitável | Pilar 1: Treino que Cabe (inimigo: só treino de uma hora funciona)
> Ideia central: [uma frase]
> Por quê: [uma linha]
>
> **2. ...**
>
> Quais eu gravo? Pode dizer "todas" ou os números.

Tema e ideia central podem usar as palavras da aluna, mas não são o texto do post: nada de capa pronta, slide escrito ou legenda.

## Passo 5. Gravar as escolhidas

Antes de gravar, se alguma pauta escolhida for carrossel, pergunte uma vez só:

> Algum desses carrosséis vai virar anúncio, ou todos são só para a sua vitrine? Pergunto porque o anúncio aceita no máximo 10 criativos (slides), e o post normal do perfil aceita até 20.

Grave a resposta em `Uso:` em cada pauta. Anúncio: o caminho do post cabe em até 10 slides. Vitrine: pode passar de 10, até 20. Se a pessoa não souber, use "vitrine" e diga que dá para mudar depois.

"Todas", "tanto faz" ou "pode": grave todas. Para cada pauta escolhida:
1. Pasta: `<pasta>/conteudo/AAAA-MM-DD-<slug>/`, com a data de postar. `<slug>`: 2 a 5 palavras do tema, minúsculas, sem acento, com hífen. Se já existe, use `-2`.
2. Criar pasta: Mac e Linux `mkdir -p "<caminho>"`; Windows `New-Item -ItemType Directory -Force "<caminho>" | Out-Null`.
3. Grave `pauta.md` seguindo `${CLAUDE_SKILL_DIR}/modelos/pauta.md`, com tudo preenchido e "Referência de aula" citando a ideia do Peraça usada.
4. Confira com Grep nos arquivos gravados: zero travessão (padrão de busca `\x{2014}|\x{2013}`). Se aparecer, troque por vírgula ou ponto e grave de novo.

Uma linha por arquivo gravado: "Gravei a pauta 1 em conteudo/2026-10-27-treino-de-35-minutos/."

## Fechamento

> Pronto: [N] pautas gravadas em brain/conteudo/.
> Se algum modelo pede foto ou print, já vá separando: [lista curta, ex.: "pauta 1: 2 fotos suas no estúdio; pauta 3: print da Ana"]. Eu peço de novo na hora de montar.
> Agora rode /copy para escrever o texto da primeira pauta ([tema]). Ele lê a pauta.md e grava o texto.md na mesma pasta.
> Com o texto pronto, volte aqui com "/conteudo montar" que eu gero as imagens.
>
> Stories: além das pautas, um story por dia mantém a aluna perto. Um bom começo esta semana: [ideia de identidade em uma linha, de voz.md ou do dia a dia].

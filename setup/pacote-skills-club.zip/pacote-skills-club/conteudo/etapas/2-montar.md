# Modo Montar. Do texto pronto para a imagem

Tempo no encontro: 5 minutos.

`<peca>` é a pasta do post: `<pasta>/conteudo/AAAA-MM-DD-<slug>/`.

## Passo 1. Achar o texto

1. Se `$ARGUMENTS` traz uma pasta ou um tema, use. Senão, liste com Glob as pastas de `<pasta>/conteudo/` que têm `texto.md`. Uma só sem PNG: use essa. Várias: mostre as 3 mais recentes numeradas e pergunte qual.
2. Sem nenhum `texto.md`: pare e diga "Ainda não tem texto pronto para montar. Rode /copy na pauta que você quer postar; ele grava o texto.md e aí eu monto as imagens." Se a pasta tem `pauta.md`, diga o tema dela. Nunca escreva o texto você mesmo.
3. Leia `texto.md` seguindo `${CLAUDE_SKILL_DIR}/referencias/formato-do-texto.md`. Descubra o formato pela linha `Formato:` ou pelos títulos (`## Slide`, `## Gancho`, `## Story`, `## Post`).

| Formato | Modelo | Peças | Tamanho |
|---|---|---|---|
| carrossel | `modelos/carrossel.html` | `slide-01.png` ... | 1080 x 1350 |
| post único | `modelos/carrossel.html` com 1 slide de capa | `post.png` | 1080 x 1350 |
| reels | `modelos/vertical.html` com 1 tela `reels` | `capa-reels.png` | 1080 x 1920 |
| stories | `modelos/vertical.html` com 1 tela `story` por story | `story-01.png` ... | 1080 x 1920 |

## Passo 2. Pegar as cores e fontes

1. Leia `<pasta>/identidade-visual.md`, a seção `## Tokens (para as outras skills)` e o bloco `json` dentro dela. Esse JSON é o `tokens`, inteiro: copie do jeito que está, sem resumir, sem tirar campo e sem trocar nome de fonte (o bloco `fontes` precisa ir com `titulo`, `texto` e `google_fonts`).
2. Status vazio, seção ausente ou JSON inválido: use `"tokens": null` (visual neutro, cinza e branco) e avise uma vez: "Usei um visual neutro porque sua identidade visual ainda não está pronta. Depois do /design-system, peça para montar de novo."
3. Leia também as seções `## Carrossel` e `## Stories` de `identidade-visual.md`. Se pedem limite de palavras diferente, use na conferência do Passo 4.
4. Leia `nome_publico` e `instagram` em `perfil-profissional.md`.

## Passo 3. Gravar o HTML da peça

Leia o modelo e grave uma cópia em `<peca>/carrossel.html` ou `<peca>/vertical.html`, trocando **só** o que está entre `/* DADOS INICIO` e `/* DADOS FIM */`. O resto fica igual: é o motor visual.

**carrossel.html** (`nome`, `instagram`, `tema`, `tokens`, `slides`):
- `## Slide 1`: `{ "tipo": "capa", "titulo": "<Título>", "apoio": "<Apoio>" }`
- slides do meio: `{ "tipo": "miolo", "titulo": "<Título>", "texto": "<Texto>" }`; com `Estilo: destaque`, acrescente `"estilo": "destaque"`.
- último slide: `{ "tipo": "final", "titulo": "<Título>", "texto": "<Texto>", "botao": "<Botão>" }`
- post único: um item só, `{ "tipo": "capa", "titulo": "<Título>", "apoio": "<Texto>" }`.

Opcionais do carrossel (sem eles, tudo sai como antes). Veja a linha `Estrutura sugerida:` da `pauta.md` da pasta, se existir:
- **Troque isso por isso:** todo slide do meio com `Título:` começando por "Troque" e `Texto:` começando por "Por" ganha `"par": true` (rótulo "Troque" na cor de alerta, "Por" na cor de acerto, das cores `alerta` e `acerto` dos tokens; sem elas, destaque e primária). Alterne o fundo: nos pares em slide de número par, acrescente `"fundo": "escuro"`. Nos pares, `"fundo"` substitui o `"estilo": "destaque"`; fora dos pares, o `Estilo: destaque` continua valendo. O texto fica igual ao `texto.md`: o modelo só separa a primeira palavra como rótulo.
- **Plano prático:** procure na pasta `<peca>` uma foto do personal (`.jpg`, `.jpeg`, `.png`, `.webp`). Achou: acrescente `"imagem": "<nome do arquivo>"` no slide de capa (ela sai escurecida com a cor secundária). Mais de uma: use a que tem "capa" no nome, senão a primeira. Nenhuma: capa normal e, no fechamento, diga em uma linha: "Para a capa com foto, coloque uma foto sua na pasta do post e peça para montar de novo."
- `"fundo": "escuro"` e `"imagem"` também valem em qualquer slide do meio, se a pessoa pedir.

**vertical.html** (`nome`, `instagram`, `tema`, `tokens`, `telas`):
- reels: `{ "tipo": "reels", "titulo": "<Título do Gancho>", "apoio": "<Apoio>" }`
- cada story: `{ "tipo": "story", "titulo": "<Título>", "texto": "<Texto>", "figurinha": "<Figurinha>" }`. Alterne `"estilo": "claro"` em stories pares para a sequência não ficar igual.

O `tokens` entra no DADOS exatamente como está no `identidade-visual.md` (Passo 2), o bloco inteiro. Resumir ou reescrever o bloco `fontes` faz a peça sair com fonte padrão.

Regras do texto dentro do JSON:
- Exatamente o texto do `texto.md`. Não reescreve, não corta, não acrescenta. Campo ausente: deixe fora do item.
- `*palavra*` continua com asterisco (vira a cor de destaque). Quebra de linha: `\n`.
- JSON válido: aspas duplas, vírgula entre itens, nada sobrando no último. Aspas dentro do texto viram `\"`.

## Passo 4. Achar o navegador e conferir se coube

**Mac** (Bash): `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`; sem Chrome, `/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge`.

**Linux** (Bash): o primeiro que existir.

```bash
C=$(command -v google-chrome google-chrome-stable chromium chromium-browser microsoft-edge | head -n 1); echo "$C"
```

Se não sair nada, não há navegador: vá para "Se não der certo".

**Windows** (PowerShell): o primeiro que existir.

```powershell
$exe = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
         "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
         "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
         "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") |
       Where-Object { Test-Path $_ } | Select-Object -First 1
```

Conferência (troque `<peca>` pelo caminho completo e `<arquivo>` por `carrossel.html` ou `vertical.html`):

**Mac:**
```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --user-data-dir=/tmp/conteudo-navegador --virtual-time-budget=6000 --dump-dom "file://<peca>/<arquivo>" 2>/dev/null | grep -o 'id="relatorio">[^<]*'
```

**Linux** (com o `$C` achado acima):
```bash
"$C" --headless=new --user-data-dir=/tmp/conteudo-navegador --virtual-time-budget=6000 --dump-dom "file://<peca>/<arquivo>" 2>/dev/null | grep -o 'id="relatorio">[^<]*'
```

**Windows:**
```powershell
$url = "file:///" + ("<peca>" -replace '\\','/') + "/<arquivo>"
& $exe --headless=new --user-data-dir="$env:TEMP\conteudo-navegador" --virtual-time-budget=6000 --dump-dom $url 2>$null | Select-String 'id="relatorio">[^<]*' | ForEach-Object { $_.Matches.Value }
```

- "OK, todo texto coube": siga.
- "TEXTO NÃO COUBE nos slides 3, 5": não corte você. Gere as imagens mesmo assim e, no fechamento, diga: "Os slides 3 e 5 ficaram apertados. Peça ao /copy: encurta os slides 3 e 5 de <pasta>. Depois rode /conteudo montar de novo."
- "FONTE NÃO CARREGOU: <Família>": não gere em silêncio. Avise em uma linha simples e espere a resposta: "A fonte <Família> não está no Google Fonts, então as imagens sairiam com uma fonte padrão. Rode /design-system muda minha fonte para escolher uma parecida do Google Fonts. Quer que eu gere assim mesmo?" Só gere se a pessoa disser que quer.
- Sem resposta: siga, a conferência visual do Passo 6 cobre.

## Passo 5. Gerar os PNGs

Um PNG por peça. Troque `N` pelo número de slides ou de stories; `L,A` pelo tamanho (`1080,1350` para carrossel e post único; `1080,1920` para reels e stories); `<nome>` por `slide`, `story`; arquivo único usa `post.png` ou `capa-reels.png` com `#1`.

**Mac (sequência):**
```bash
C="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; D="<peca>"
for i in $(seq 1 N); do n=$(printf "%02d" $i); "$C" --headless=new --user-data-dir=/tmp/conteudo-navegador --hide-scrollbars --force-device-scale-factor=1 --window-size=L,A --virtual-time-budget=6000 --screenshot="$D/<nome>-$n.png" "file://$D/<arquivo>#$i" 2>/dev/null; done; ls -l "$D"/*.png
```

**Mac (peça única):**
```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --user-data-dir=/tmp/conteudo-navegador --hide-scrollbars --force-device-scale-factor=1 --window-size=L,A --virtual-time-budget=6000 --screenshot="<peca>/capa-reels.png" "file://<peca>/vertical.html#1" 2>/dev/null
```

**Linux:** os mesmos comandos do Mac, trocando a primeira linha da sequência por `C=$(command -v google-chrome google-chrome-stable chromium chromium-browser microsoft-edge | head -n 1); D="<peca>"` e, na peça única, o caminho do Chrome por `"$C"`.

**Windows (sequência):**
```powershell
$d = "<peca>"; $url = "file:///" + ($d -replace '\\','/') + "/<arquivo>"
1..N | ForEach-Object { $n = "{0:D2}" -f $_; & $exe --headless=new --user-data-dir="$env:TEMP\conteudo-navegador" --hide-scrollbars --force-device-scale-factor=1 --window-size=L,A --virtual-time-budget=6000 --screenshot="$d\<nome>-$n.png" "$url#$_" 2>$null | Out-Null }
Get-ChildItem "$d\*.png" | Select-Object Name, Length
```

Confira: um arquivo por peça, todos com tamanho maior que zero. Faltou algum: rode só aquele número de novo.

## Passo 6. Olhar as imagens antes de entregar

Abra com Read a capa e a peça com mais texto. Confira:
- texto inteiro, sem corte, longe das bordas (no vertical, nada no topo de 250 px nem na base de 340 px);
- dá para ler no celular: letra grande, contraste bom;
- cores e fontes da identidade visual (ou o neutro);
- no Troque isso por isso: rótulos "Troque" e "Por" com cores diferentes e fundos alternando; no Plano prático com foto: texto da capa legível sobre a foto;
- @ e nome certos;
- nenhum caractere estranho (quadradinho, `&amp;`, asterisco sobrando), zero travessão, zero emoji.

Algo errado no visual: corrija o `DADOS` (nunca o texto), gere de novo só a peça afetada e olhe outra vez.

## Passo 7. Abrir a pasta e fechar

Abrir: Mac `open "<peca>"`; Linux `xdg-open "<peca>"`; Windows `Start-Process "<peca>"` (se não abrir, `explorer.exe "<peca>"`). Atualize o `Status:` da `pauta.md` para `imagens prontas`, se ela existir.

> Pronto, as imagens estão na pasta que abri.
> [Carrossel: N imagens, slide-01 a slide-N, na ordem.] [Capa do reels: capa-reels.png, escolha ela como capa na hora de postar.] [Stories: N imagens, coloque a figurinha no espaço marcado.]
> A legenda está no texto.md, na parte "Legenda".
> Para postar: no Instagram, toque no +, escolha as imagens na ordem, cole a legenda e publique. Se o celular não vê a pasta, mande as imagens para você mesma pelo WhatsApp.

## Se não der certo

Sem navegador, ou PNG vazio depois de duas tentativas: abra o HTML da peça (Mac `open`; Linux `xdg-open`; Windows `Start-Process`). Ele mostra a prévia de todas as peças. Diga: "Não consegui gerar as imagens aqui. A prévia está aberta; dá para tirar print de cada uma ou montar no Canva com esses textos." No Linux sem navegador achado, acrescente: "Para gerar as imagens, instale o Google Chrome: baixe o arquivo .deb em google.com/chrome e dê dois cliques nele."

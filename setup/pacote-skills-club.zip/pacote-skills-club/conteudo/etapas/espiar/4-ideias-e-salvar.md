# Modo Espiar, etapa 4. Cinco ideias e salvar

Tempo no encontro: 5 minutos.

Objetivo: sair com 5 ideias de post prontas para virar conteúdo, e a análise guardada no segundo cérebro.

## Passo 1. Montar as 5 ideias

Regras:
1. Cada ideia nasce de um padrão que funciona para o concorrente (etapa 2) ou de uma lacuna (etapa 3). Pelo menos 2 das 5 vêm de lacunas.
2. Cada ideia está ligada a um pilar do `metodo.md` (ou, se o método estiver vazio, a uma dor do `aluno-ideal.md`).
3. Varie o formato: no máximo 3 do mesmo (carrossel, reels, foto única).
4. Varie o tipo de gancho: no mínimo 3 tipos diferentes (ver seção "Ganchos" do guia).
5. O gancho é escrito na voz do personal: use as expressões de `voz.md`, o jeito de chamar a aluna e a linguagem do `aluno-ideal.md`. Nada que o `voz.md` diga que ele nunca fala.
6. Nenhum gancho repete frase do concorrente. Pegue a estrutura, troque tudo.
7. Case só se estiver com `autorização para uso público: sim` em `cases.md`.
8. Sem promessa de quilos com prazo, sem antes e depois de corpo, sem promessa de cura.

Formato de cada ideia:

```
### Ideia 1. <título curto da ideia>
- formato: carrossel | reels | foto única
- gancho: "<a primeira frase ou o texto da capa, na voz dele>"
- tipo de gancho: provocação | erro comum | resultado | identificação | número e prazo | curiosidade | autoridade
- de onde veio: <padrão da @fulana ou lacuna>, (fonte)
- ligado a: <pilar do método ou dor da aluna>, (fonte no cérebro)
- chamada no fim: <direct, comentar palavra, salvar, link na bio>
```

Só a ideia e o gancho. Não escreva o post, a legenda nem o roteiro: a ideia vira pauta no Modo Pauta desta skill, e o texto é da skill `copy`.

## Passo 2. Conferir antes de salvar

Releia a análise e as ideias e confira:
- [ ] Todo número tem fonte; nenhum foi estimado.
- [ ] O que tem menos de 3 ocorrências está como "pista".
- [ ] Nenhum gancho copia frase do concorrente.
- [ ] Os ganchos soam como os "Textos reais" do `voz.md`.
- [ ] Sem travessão, sem emoji, acentuação completa.
- [ ] Sem estas palavras: descubra, transforme sua vida, imagine poder, desbloqueie, eleve, jornada (como clichê), mergulhe, revolucione.

Corrija o que falhar antes de salvar.

## Passo 3. Salvar

1. Nome do arquivo: `<pasta>/espiao/AAAA-MM-DD-@perfil.md` com a data de hoje e o @ sem espaço (ex.: `2026-10-30-@fulana.fit.md`). Comparação: `AAAA-MM-DD-@perfil1-@perfil2.md`.
2. Glob para ver se já existe. Se existir, use `-2` no fim (`2026-10-30-@fulana.fit-2.md`). Nunca grave por cima.
3. Leia `${CLAUDE_SKILL_DIR}/modelos/relatorio-espiao.md`, preencha e grave com Write (a pasta `espiao` é criada junto, se não existir).
4. Status do cabeçalho: `completo` se teve números e 10 posts ou mais; `em andamento` se a análise foi só qualitativa ou com poucos posts, com o que falta escrito em "O que falta" (ex.: "prints com números de curtidas").

## Passo 4. Fechar na conversa

> Pronto. Salvei a análise em `brain/espiao/<nome do arquivo>`.
>
> A @fulana em 2 linhas: ...
>
> O que você pode aproveitar: ...
> Lacuna que ela deixa pra você: ...
>
> As 5 ideias:
> 1. (reels) "gancho"
> 2. ...
>
> Quer transformar essas ideias na pauta da semana?

Se a pessoa disser sim (ou escolher algumas ideias), vá para o Modo Pauta (`${CLAUDE_SKILL_DIR}/etapas/1-pauta.md`) levando as ideias escolhidas: cada uma vira uma pauta, com o formato e o gancho daqui como ponto de partida. Não releia o cérebro do zero; você já leu na etapa 1.

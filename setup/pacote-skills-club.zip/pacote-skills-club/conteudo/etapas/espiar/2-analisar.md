# Modo Espiar, etapa 2. Analisar o perfil

Tempo no encontro: 5 minutos.

Objetivo: entender por que o perfil funciona (ou não), com prova, antes de comparar com o personal.

## Passo 1. Ler o guia

Leia `${CLAUDE_SKILL_DIR}/referencias/metodo-de-analise.md` inteiro. É ele que diz o que olhar e quando algo é padrão.

## Passo 2. Medir

Com a lista de posts montada na etapa 1:
1. Calcule o engajamento de cada post que tem número e a média do perfil (seção 2 do guia).
2. Marque os posts acima da curva.
3. Se forem reels, calcule a mediana das views e marque os que estouraram.
4. Se não houver número, use os sinais do próprio perfil (fixados, destaques, repetição) e escreva isso.

## Passo 3. Analisar parte por parte

Siga a seção 3 do guia, nesta ordem, uma linha de conclusão por item:
1. Bio e topo (para quem fala, promessa, prova, chamada e link).
2. Destaques.
3. Oferta e chamada para ação.
4. Temas (com a proporção).
5. Formatos (o mais usado e o que mais performa).
6. Ganchos (tipo mais usado e tipo dos posts acima da curva, com 2 ou 3 exemplos exatos entre aspas e a fonte).
7. Estrutura do carrossel e do reels que foram bem.
8. Frequência.
9. Tom.

## Passo 4. Concluir

Feche com o que pede a seção 4 do guia: posicionamento em 2 linhas, 3 padrões mais fortes com prova, o que ela não faz.

Se for comparação, faça os passos 2 a 4 para cada perfil e depois monte a tabela da seção 5 do guia.

## Passo 5. Mostrar na conversa (curto)

> Olhei o perfil da @fulana. Em resumo:
> 1. Ela fala com ... e promete ...
> 2. O que mais funciona pra ela: ... (prova: ...)
> 3. ...
> 4. ...
> Agora vou ver o que disso serve pra você.

Não espere aprovação para seguir; vá direto para a etapa 3 (`${CLAUDE_SKILL_DIR}/etapas/espiar/3-comparar.md`). Se a pessoa corrigir algo ("não, ela é nutricionista, não personal"), ajuste e siga.

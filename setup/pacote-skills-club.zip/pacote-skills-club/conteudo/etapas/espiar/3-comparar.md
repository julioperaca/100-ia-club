# Modo Espiar, etapa 3. Comparar com o seu cérebro

Tempo no encontro: 5 minutos.

Objetivo: transformar a análise de outra pessoa em decisão para o personal. Sem esta etapa, a análise é só curiosidade.

## Passo 1. Mesma aluna ou não

Compare a aluna dela (da etapa 2) com `aluno-ideal.md`:
- **Mesma aluna** (mesma idade, mesmo momento, mesma dor): é concorrente direta. O que funciona para ela tende a funcionar para ele, e as lacunas dela são oportunidade direta.
- **Aluna parecida** (mesma dor, outro momento de vida, ou o contrário): aproveita a estrutura, troca o exemplo.
- **Outra aluna** (referência de outro nicho): aproveita só a forma (formato, gancho, estrutura), nunca o tema.

Diga qual dos três em uma linha.

## Passo 2. O que você pode aproveitar

Para cada padrão forte da etapa 2, pergunte: isso cabe no método, na promessa e na voz dele? Se sim, entra aqui, sempre com a adaptação:

| O que ela faz | Como fica do seu jeito | Por quê (cérebro) |
|---|---|---|
| ... | ... | ligado a um pilar, à aluna ou a um case (com a fonte) |

De 3 a 5 linhas. Ligue sempre a um pilar do `metodo.md`, a uma dor do `aluno-ideal.md` ou a um case autorizado de `cases.md`.

## Passo 3. O que não combina com você

Liste o que funciona para ela mas bate de frente com `voz.md` (tom, o que nunca diz), com a promessa do `metodo.md` ("O que o método não promete") ou com as regras da profissão. Uma linha por item, com o motivo e a fonte.

Exemplos de motivo: "você fala leve e sem cobrança; o tom de bronca dela não é você (voz.md, Tom)", "seu método não promete quilos (metodo.md)".

## Passo 4. Lacunas que ela não ocupa

O espaço vazio é o mais valioso. Procure:
1. Dores do `aluno-ideal.md` (Ponto A, objeções, linguagem) que não aparecem em nenhum post dela.
2. Partes do seu método (pilares, acompanhamento, prazos) que ela não mostra no dela.
3. Provas que você tem e ela não mostra (cases autorizados, anos de profissão, número de alunas).
4. Formatos ou temas que ela quase não usa.

De 3 a 5 lacunas, cada uma com: o que falta no perfil dela, o que você tem para ocupar (com fonte no cérebro).

## Passo 5. Se for comparação de vários perfis

Acrescente uma linha por perfil na tabela da etapa 2 com o personal como última coluna, usando o que está no cérebro dele (e "não sei pelo cérebro" onde faltar, nunca inventando). Depois diga: em que ponto ele já está à frente, em que ponto está atrás e qual espaço nenhum dos perfis ocupa.

## Passo 6. Mostrar na conversa (curto)

Três listas curtas: aproveitar (3 itens), não combina (2 itens), lacunas (3 itens). Siga para a etapa 4 (`${CLAUDE_SKILL_DIR}/etapas/espiar/4-ideias-e-salvar.md`) sem esperar.

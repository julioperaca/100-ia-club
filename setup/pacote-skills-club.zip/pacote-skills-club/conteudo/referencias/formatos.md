# Formatos de pauta prontos

Estruturas de carrossel que o Peraça usa no próprio perfil e que funcionam para o personal. O Modo Pauta sugere estes formatos como ideia quando a condição de "Quando sugerir" bate com o cérebro. Cada formato diz a ordem das ideias, slide a slide. A frase de cada slide é do /copy: aqui não tem texto pronto.

Como usar na pauta:
- No campo "Estrutura sugerida" da `pauta.md`, escreva o nome do formato exatamente como no título abaixo.
- No campo "Caminho do post", adapte a estrutura ao tema da pauta, uma linha por bloco de slides.
- Os números de slide são ponto de partida. Carrossel menor (7 ou 8 slides) junta os blocos do meio, nunca a capa, a moral ou a chamada.

---

## 1. História de aluna

**Para que serve:** provar que o método funciona com uma pessoa real, mostrando o antes, o ajuste e a evolução em marcos. É o formato de prova mais forte do perfil, porque o resultado vem com a fala da própria aluna.

**Estrutura (10 slides):**
1. Capa: foto da aluna (ou do personal com a aluna), a etiqueta de quem é o público e a promessa do caso: o nome dela, o resultado e o tempo que levou.
2. Contraste: o que a maioria faz para chegar nesse resultado e a pista de que existe um caminho mais simples. Termina puxando para o próximo slide.
3. O inimigo comum: por que o caminho que todo mundo segue trava. Um argumento só, do pilar do `metodo.md`.
4. Ponto de partida: como a aluna chegou, com o print de uma mensagem dela contando a situação.
5. O ajuste: o que mudou, nomeando a ideia do método sem entregar o passo a passo, e o primeiro resultado com print.
6 a 8. Os marcos: um marco por slide, cada um com uma frase curta de resultado em destaque e o print da mensagem com o trecho importante grifado.
9. A moral: o resultado veio do método aplicado com constância, e o mérito é da aluna. Aqui mora a ideia central.
10. Chamada: falar com o desejo de quem leu e pedir uma ação só (direct com palavra ou avaliação). A legenda repete a mesma chamada.

**Quando sugerir:**
- Objetivo provar, e existe em `cases.md` um case com `autorização para uso público: sim` que tenha ponto de partida e pelo menos dois marcos com print ou relato.
- Semana 3 ou 4 do aquecimento de turma, ou um por semana sem campanha.
- Sem case autorizado: não sugira. Diga em uma linha que o formato fica guardado para quando houver case.

**Cuidados:** só dado que a aluna autorizou; esconda telefone, foto de exame e qualquer dado de saúde no print. O marco é o que está no case, sem prometer o mesmo prazo para quem lê. Nada de quilos em prazo.

**Exemplo para personal trainer:**
- Tema: a aluna que largava o treino toda vez que a semana apertava.
- Caminho: capa com a aluna e "6 meses sem faltar uma semana"; contraste entre esperar sobrar tempo e ter um treino que cabe no dia; inimigo comum "só treino de uma hora vale"; print dela contando que já tinha desistido três vezes; ajuste para treinos de 30 minutos com versão curta para semana corrida; marcos (primeiro mês completo, voltou a subir escada sem cansar, carga dobrada no agachamento); moral sobre constância; chamada para a avaliação.

---

## 2. Troque isso por isso

**Para que serve:** mostrar, em pares lado a lado, o hábito que a aluna tem hoje e o que ela pode fazer no lugar. Cada par rebate um pedaço do inimigo comum. Alcança gente nova porque é fácil de salvar e mandar para uma amiga.

**Estrutura (10 slides):**
1. Capa: a etiqueta do público, uma promessa de ação ("faça isto para chegar em X") e uma linha de apoio com um ganho a mais.
2. O erro coletivo: muita gente faz X para chegar em Y e não chega, e você vai mostrar o jeito certo. Termina puxando para o próximo slide.
3 a 8. Os pares: um par por slide. Em cima, "troque isso" com o hábito comum (cor de alerta). Embaixo, "por isso" com a alternativa ligada ao método (cor de acerto). Alternar fundo claro e escuro ajuda a leitura. O último par é o mais forte e o mais perto do que você vende.
9. A moral: o princípio que une todos os pares, em duas frases. É a ideia central.
10. Chamada: seguir o perfil, dizendo o que ela ganha seguindo você.

**Quando sugerir:**
- Objetivo atrair ou conscientizar, perfil pequeno ou sem campanha.
- O `metodo.md` tem um inimigo comum com vários comportamentos errados, ou o `aluno-ideal.md` lista vários hábitos que travam a aluna.
- Bom para a vitrine: um por mês segura a grade sem cansar.

**Como fica na imagem:** cada par é um slide com `Título:` começando por "Troque" e `Texto:` começando por "Por". O Modo Montar marca o slide como par (`"par": true`): o rótulo "Troque" sai na cor de alerta e o "Por" na cor de acerto, e os pares alternam fundo claro e escuro (`"fundo": "escuro"` nos pares de número par). As duas cores vêm dos tokens do design system (`cores.alerta` e `cores.acerto`); sem elas, alerta usa a cor de destaque e acerto a primária. A repetição de "Troque" e "Por" nos rótulos é a estrutura do formato e está liberada na conferência anti-IA do /copy; no texto corrido, não.

**Cuidados:** cada "por isso" precisa de motivo, mesmo que curto, senão vira lista de opinião. Nada de troca de dieta, cardápio ou suplemento. De 4 a 6 pares; mais que isso cansa.

**Exemplo para personal trainer:**
- Tema: parar de recomeçar o treino toda segunda.
- Pares: começar a semana com tudo e cansar na quarta, por começar com dois treinos e somar um por mês; copiar treino de vídeo, por um treino montado para a rotina dela; pular o treino quando a agenda aperta, por ter uma versão de 20 minutos guardada; medir o progresso só pela balança, por olhar a carga, a roupa e o fôlego; treinar sozinha sem saber se está certo, por ter alguém corrigindo a execução.
- Moral: constância vem de um plano que cabe na vida dela. Chamada para seguir.

---

## 3. Plano prático

**Para que serve:** pegar a objeção que mais trava a aluna e mostrar um caminho em passos, do primeiro movimento até virar rotina, com prova de quem já fez. Conscientiza e prova no mesmo post.

**Estrutura (10 slides):**
1. Capa: "plano prático para sair de A e chegar em B", sobre uma foto real do dia a dia do personal escurecida, com a etiqueta do público.
2. Promessa: B está mais perto do que ela imagina, e o post vai mostrar.
3. O motivo real: nomear a objeção que trava (com as palavras de `aluno-ideal.md`) e fechar com a pista de que existe um detalhe que ela ainda não viu.
4. Por que o caminho comum não resolve: o inimigo comum, comparado com uma dor que ela já sente hoje.
5. A solução: a ideia do método que destrava, explicada com uma conta ou um exemplo simples.
6. Por onde começar: o primeiro passo, fácil e possível nesta semana, com nome próprio se o método tiver.
7 e 8. Provas: um ou dois prints por slide, cada um com um título curto de resultado em cima.
9. O passo seguinte: como o primeiro passo vira rotina e o resultado se sustenta.
10. Chamada: seguir o perfil para mais conteúdo sobre o tema.

**Quando sugerir:**
- Objetivo conscientizar com prova; semana 3 do aquecimento (o caminho e a prova) ou quando a objeção principal do `aluno-ideal.md` ainda não apareceu no feed.
- O `metodo.md` tem um pilar com primeiro passo claro.
- Precisa de pelo menos um case autorizado para os slides 7 e 8. Sem case, sugira com 8 slides: tire as provas e reforce o passo 6 com um exemplo do dia a dia, sem inventar resultado.

**Como fica na imagem:** a capa sai sobre a foto do personal, escurecida com a cor secundária para o texto ficar legível (`"imagem": "<arquivo>"` no slide de capa, arquivo na pasta do post). Sem foto, a capa sai no fundo normal da marca e o Modo Montar avisa em uma linha.

**Cuidados:** a conta do slide 5 usa número real ou exemplo marcado como exemplo. O passo 6 precisa caber na semana dela, senão o plano parece longe. Sem prazo de resultado.

**Exemplo para personal trainer:**
- Tema: voltar a treinar depois dos 40 sem largar na terceira semana.
- Caminho: capa com foto do estúdio; promessa de que dá para voltar sem sofrer; objeção "meu corpo não aguenta mais o que aguentava"; caminho comum de voltar no ritmo de antes e se machucar; a ideia de começar pela carga que o corpo aceita hoje e subir aos poucos; primeiro passo com dois treinos curtos na semana; provas de duas alunas autorizadas; como os treinos viram rotina; chamada para seguir.

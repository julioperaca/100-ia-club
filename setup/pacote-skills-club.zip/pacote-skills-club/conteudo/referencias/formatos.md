# Os 7 modelos de post

Modelos de post que o Peraça usa no próprio perfil e que funcionam para o personal. Cada modelo diz a ordem das ideias, slide a slide, e como fica na imagem. A frase de cada slide é do /copy: aqui não tem texto pronto.

| # | Modelo | Formato | Objetivo principal | Pede imagem? |
|---|---|---|---|---|
| 1 | Foto, nicho e headline | carrossel | atrair | sim: 2 fotos (capa e slide 2) |
| 2 | Troque isso por isso | carrossel | atrair, conscientizar | não |
| 3 | Foi assim que | carrossel | provar | sim: foto da aluna e prints |
| 4 | Frase sobre foto | post único | conectar | sim: 1 foto do personal |
| 5 | Esse é o segredo | post único ou capa de reels | conscientizar | sim: 1 foto do personal |
| 6 | Plano prático | carrossel | conscientizar com prova | sim: 1 foto (capa) e prints, se houver |
| 7 | Carrossel tweet | carrossel | provar, opinião | sim: foto de perfil e prints, se houver |

## Regras que valem para todos

**Tamanho.** Todo post do feed sai em 1080 x 1350 (o retrato do Instagram, 4:5). Nunca quadrado. Capa de reels e stories: 1080 x 1920.

**A cara é do aluno.** O modelo dá a estrutura e o jeito do visual. Cores, fontes e raios vêm do /design-system dele (`identidade-visual.md`). Nunca use as cores ou as fontes do Peraça.

**Anúncio ou vitrine.** Antes de montar um carrossel, pergunte sempre:

> Você pretende usar este post em anúncio ou ele é só para ficar na sua vitrine? Pergunto porque o anúncio aceita no máximo 10 criativos (slides), e o post normal do perfil aceita até 20.

- Anúncio: no máximo 10 slides. Se o roteiro passar disso, junte os blocos do meio. Nunca corte a capa, a conclusão ou o CTA.
- Vitrine: pode passar de 10, até 20.
- Grave a resposta na pauta (`Uso: anúncio | vitrine`).

**A skill pede o que falta.** Se o modelo pede foto, print ou imagem de fundo, peça antes de montar, dizendo para que serve: "Para a capa, me mande uma foto sua treinando uma aluna ou no estúdio. Ela fica escurecida atrás do texto." Os arquivos ficam na pasta do post. Sem a foto, monte com o fundo da marca e avise em uma linha que o post fica mais forte com ela.

**Prova com print.** Quando a copy diz um resultado em que alguém pode não acreditar (um valor, um prazo, uma mudança, "ela voltou a correr"), o print vem logo depois, no mesmo slide ou no seguinte, para provar que é verdade. Antes de escrever, pergunte: "Você tem print de resultado do que vai falar neste post? Mensagem de aluna, antes e depois, avaliação. Ele prova que é verdade." Só print autorizado, sem telefone, sem foto de exame, sem dado de saúde, com o trecho que prova grifado. Sem print, a frase fica mais moderada. Nunca invente resultado.

**Por baixo de todo modelo:** headline, introdução, desenrolar, conclusão (a moral da história) e CTA. O desenrolar segue a estrutura de copy que o aluno escolher no /copy.

---

## 1. Foto, nicho e headline

**Para que serve:** parar quem está rolando o feed com uma foto real, o nicho em destaque e uma headline que fala de dor ou desejo e desperta curiosidade. É o modelo do post da vitrine da Nike do Peraça. Bom para anúncio, porque a capa e o slide 2 seguram sozinhos.

**Estrutura (até 10 slides):**
1. Capa: foto de fundo escurecida; o nicho do aluno numa faixa em cima ("MULHERES 40+", "QUEM TREINA EM CASA"); a headline; uma linha de apoio ("Te explico como fazer isso na sua rotina.").
2. Slide 2: também com foto, continuando a mesma ideia da capa. No anúncio e no carrossel, às vezes é o segundo criativo que aparece primeiro, então ele precisa fazer sentido sozinho.
3 até o antepenúltimo: o desenrolar, na estrutura de copy escolhida (PEPO, PCS, PAS ou AIDA), uma ideia por slide.
Penúltimo: a conclusão, a moral da história.
Último: o CTA.

**Headline:** livre. Não precisa seguir um modelo pronto, desde que fale de uma dor ou desejo da aluna e desperte curiosidade.

**Nicho:** vem do cérebro (`negocio.md` e `aluno-ideal.md`), em caixa alta, de 1 a 3 palavras. É a etiqueta de quem é o público: quem não é passa reto, quem é para.

**Quando sugerir:** objetivo atrair; post que pode virar anúncio; tema com uma comparação ou cena que uma foto mostra bem.

**Como fica na imagem:** capa e slide 2 com `"imagem"` (foto escurecida) e a capa com `"nicho"`. Do slide 3 em diante, fundo da marca.

**Cuidados:** foto com licença (do próprio personal, de aluna autorizada, ou banco de imagens livre). Logo de outra marca em anúncio pode ser reprovado pela Meta.

**Exemplo para personal trainer:**
- Nicho: MULHERES 40+.
- Capa: foto da academia vazia às 6h, headline sobre o treino que cabe antes do trabalho.
- Slide 2: foto da aluna amarrando o tênis, "a academia não espera você ter tempo".
- Desenrolar em PCS; moral sobre constância; CTA para seguir.

---

## 2. Troque isso por isso

**Para que serve:** mostrar, em pares, o hábito que a aluna tem hoje e o que ela pode fazer no lugar. Cada par rebate um pedaço do inimigo comum. Fácil de salvar e mandar para uma amiga.

**Estrutura (10 slides):**
1. Capa: "Faça isso para [desejo do público]" e, embaixo, um complemento do desejo (no post do Peraça: "Faça isso para conseguir mais alunos online / e liberar horários do presencial"), com o nicho em cima.
2. Introdução: muita gente faz X para chegar em Y, mas poucos sabem a forma certa. "Eu te explico..."
3 a 8. As trocas: uma por slide. Em cima, "Troque isso" com o hábito comum. Embaixo, "Por isso" com a alternativa ligada ao método. O último par é o mais forte e o mais perto do que o personal vende.
9. Conclusão: a moral que une as trocas, em duas frases.
10. CTA.

**Quando sugerir:** objetivo atrair ou conscientizar; o `metodo.md` tem um inimigo comum com vários comportamentos errados, ou o `aluno-ideal.md` lista vários hábitos que travam a aluna. Um por mês segura a grade sem cansar.

**Como fica na imagem:** cada troca é um slide com `"par": true`: o Título começa com "Troque" e o Texto com "Por". "Troque" sai na cor de alerta e "Por" na cor de acerto, as duas dos tokens (`cores.alerta` e `cores.acerto`; sem elas, destaque e primária). As trocas alternam fundo claro e escuro (`"fundo": "escuro"` nas de número par). A repetição de "Troque" e "Por" é a estrutura do modelo e está liberada na conferência anti-IA do /copy.

**Cuidados:** de 4 a 6 trocas. Cada "por isso" com motivo, mesmo que curto. Nada de troca de dieta, cardápio ou suplemento.

**Exemplo para personal trainer:**
- Capa: "Faça isso para não largar o treino na terceira semana / e ver resultado sem treinar todo dia".
- Trocas: começar a semana com tudo e cansar na quarta, por começar com dois treinos; copiar treino de vídeo, por um treino montado para a rotina dela; pular o treino quando a agenda aperta, por uma versão de 20 minutos; medir o progresso só pela balança, por olhar a carga, a roupa e o fôlego.
- Conclusão sobre um plano que cabe na vida dela. CTA para seguir.

---

## 3. Foi assim que

**Para que serve:** provar que o método funciona com uma pessoa real: o antes, o ajuste e a evolução em marcos, com o print da própria aluna. É o modelo do post "Foi assim que o Erick fez R$ 100 mil no digital em 9 meses". O formato de prova mais forte do perfil.

**Estrutura (10 slides), a mesma do post do Erick:**
1. Capa: foto da aluna (ou do personal com a aluna), o nicho e "Foi assim que [nome] alcançou [resultado que o público deseja] em [tempo]".
2. Introdução: enquanto a maioria faz X, existe um caminho mais simples. "Eu te explico..."
3. Por que o caminho comum trava: um argumento só, do pilar do `metodo.md`.
4. Como ela chegou: o mesmo problema da maioria, com o print dela contando a situação.
5. O ajuste: o que mudou, nomeando a ideia do método sem entregar o passo a passo, e o primeiro resultado com print.
6 a 8. Os marcos: um por slide, uma frase curta de resultado e o print com o trecho importante grifado.
9. A moral: não foi mágica; o mérito é dela por aplicar e continuar.
10. CTA, falando com o desejo de quem leu.

**Quando sugerir:** objetivo provar, e existe em `cases.md` um case com `autorização para uso público: sim`, com ponto de partida e pelo menos dois marcos com print ou relato. Sem case autorizado, não sugira: diga em uma linha que o modelo fica guardado para quando houver case.

**Como fica na imagem:** capa com `"imagem"` (foto da aluna) e `"nicho"`; slides 4 a 8 com `"prints"`, grandes e centralizados abaixo do texto.

**Cuidados:** a copy segue esta estrutura; se o aluno quiser outra estrutura, troca. Só dado que a aluna autorizou. Esconder telefone, foto de exame e qualquer dado de saúde no print. O resultado é o dela, sem prometer o mesmo prazo para quem lê. Nada de quilos em prazo.

**Exemplo para personal trainer:**
- Capa: "Foi assim que a Ana voltou a correr 5 km depois da lesão no joelho".
- Introdução: a maioria para de correr de vez. Por que trava: descanso sem fortalecer. Print da Ana contando que tinha medo de voltar. Ajuste: fortalecer antes de correr. Marcos: primeiro treino sem dor, 2 km, 5 km. Moral: o mérito é dela. CTA para a avaliação.

---

## 4. Frase sobre foto

**Para que serve:** um post de uma imagem só, com uma frase que o personal costuma falar e que faz o público querer se mexer e treinar. Mostra quem ele é e o que ele acredita. A copy inteira vai na legenda, não na imagem.

**Estrutura:**
- A imagem: foto do personal com o fundo escurecido ou um degradê, e a frase em letra grande.
- A frase: curta (até 20 palavras), na voz dele (`voz.md`), algo que ele fala de verdade para as alunas.
- A legenda: headline, introdução, desenrolar, moral e CTA.

**Quando sugerir:** objetivo conectar; semana com muito post de ensinar; um por semana ou a cada quinze dias.

**Como fica na imagem:** post único, `"tipo": "frase"` com `"imagem"`. Sem rodapé de número de slide.

**Cuidados:** frase dele, nunca citação famosa sem autor. Sem promessa de resultado na frase.

**Exemplo para personal trainer:** foto dele no estúdio, frase "Treino bom é o que você consegue repetir na semana que deu tudo errado." Legenda conta a semana de uma aluna que treinou 20 minutos e não desistiu.

---

## 5. Esse é o segredo

**Para que serve:** uma capa com a foto do personal e a headline "Esse é o segredo para [desejo do público]", e a copy na legenda. É o modelo do post "Esse é o segredo para captar alunos que ainda não te conhecem". Serve como post de uma imagem ou como capa de reels.

**Estrutura:**
- A imagem: foto do personal, com "Esse é o segredo para [desejo]" em letra grande. O nicho em cima é opcional.
- A legenda, como no post do Peraça: uma situação que a pessoa reconhece, fechando com "Acertei?"; por que isso acontece; o que isso custa; o segredo, que é a solução do método; o CTA.

**Quando sugerir:** objetivo conscientizar; tema em que a aluna tem um erro de entendimento que uma ideia só resolve.

**Como fica na imagem:** post único, `"tipo": "capa"` com `"imagem"` (e `"nicho"`, se quiser), sem a seta de arrastar. Para reels, a mesma capa sai no `vertical.html` (1080 x 1920).

**Cuidados:** o "segredo" é uma ideia do método explicada em palavras simples, sem prometer resultado garantido.

**Exemplo para personal trainer:** "Esse é o segredo para treinar depois dos 40 sem dor no joelho." Legenda: você volta a treinar e o joelho reclama na segunda semana, acertei?; o motivo; o custo de parar de novo; o segredo (fortalecer antes de aumentar a carga); CTA.

---

## 6. Plano prático

**Para que serve:** pegar a objeção que mais trava a aluna e mostrar um caminho em passos, do primeiro movimento até virar rotina, com prova de quem já fez. É o modelo do post "Plano prático para migrar do presencial e tornar-se um personal 100% digital".

**Estrutura (10 slides):**
1. Capa: "Plano prático para [sair de A e chegar em B]", sobre uma foto real escurecida, com o nicho.
2. Promessa: B está mais perto do que ela imagina, e o post vai mostrar.
3. O motivo real: nomear a objeção que trava (com as palavras de `aluno-ideal.md`) e fechar com a pista de que existe um detalhe que ela ainda não viu.
4. Por que o caminho comum não resolve: o inimigo comum, comparado com uma dor que ela já sente.
5. A solução: a ideia do método, explicada com uma conta ou um exemplo simples.
6. Por onde começar: o primeiro passo, fácil e possível nesta semana.
7 e 8. Provas: um ou dois prints por slide, com um título curto de resultado em cima.
9. O passo seguinte: como o primeiro passo vira rotina e o resultado se sustenta.
10. CTA.

**Quando sugerir:** objetivo conscientizar com prova; a objeção principal do `aluno-ideal.md` ainda não apareceu no feed; o `metodo.md` tem um pilar com primeiro passo claro. Sem case para os slides 7 e 8: monte com 8 slides, sem as provas, e reforce o passo 6 com um exemplo do dia a dia, sem inventar resultado.

**Como fica na imagem:** capa com `"imagem"` e `"nicho"`; slides 7 e 8 com `"prints"`.

**Cuidados:** a conta do slide 5 usa número real ou exemplo marcado como exemplo. O passo 6 precisa caber na semana dela. Sem prazo de resultado.

**Exemplo para personal trainer:** "Plano prático para voltar a treinar depois dos 40 sem largar na terceira semana": objeção "meu corpo não aguenta mais"; caminho comum de voltar no ritmo de antes; a ideia de começar pela carga que o corpo aceita hoje; primeiro passo com dois treinos curtos; provas de duas alunas autorizadas; como vira rotina; CTA para seguir.

---

## 7. Carrossel tweet

**Para que serve:** texto em fundo branco, no jeito de um post do X (antigo Twitter), com a foto, o nome e o @ do personal no topo. Lê rápido, parece conversa e deixa a prova (o print) em destaque. É o modelo que o Peraça usa no próprio perfil, com as mesmas regras.

**Estrutura:** qualquer estrutura de copy cabe aqui. Uma ideia por slide, frases curtas, um parágrafo de 1 a 3 frases. Exemplo do post da Cris ("Foi assim que a Cris fez R$ 40.000,00 em menos de 4 meses no Digital"): capa com o resultado e o print; a conta que explica o resultado; como seria pelo caminho comum; o custo do caminho comum; o que precisa de verdade; as provas em ordem de tempo (3 dias, 2 semanas, 1 mês); acolher quem já se frustrou; o caminho mais simples; CTA.

**Regras do visual (as mesmas do Peraça):**
- Fundo branco. Cabeçalho com a foto redonda, o nome e o @ do personal, sempre no mesmo lugar em todos os slides.
- O texto vem logo abaixo do cabeçalho. Nunca centralizar o bloco na altura: texto curto fica curto e o espaço sobra embaixo.
- Letra grande: corpo 54 px, capa 62 px, entrelinha 1.47. Nunca diminuir a letra para caber: divida o slide ou encurte o texto.
- Prints de prova grandes e centralizados.
- A cor de destaque (palavras entre asteriscos) é a primária do design system do aluno.
- Sem número de slide nem @ no rodapé: o @ já está no cabeçalho.

**Quando sugerir:** post de prova (case com print) e de opinião; perfil que quer um visual de conversa.

**Como fica na imagem:** `"modelo": "tweet"` no DADOS, com `"foto_perfil"`; slides com `"prints"` quando houver print.

**Cuidados:** os mesmos de prova com print. Máximo de 10 slides se for anúncio.

**Exemplo para personal trainer:** "Foi assim que a Bia treinou 3 vezes por semana durante 6 meses sem largar." A conta: 30 minutos cabem no almoço. O caminho comum (esperar sobrar uma hora). Prints da primeira semana, do primeiro mês e do sexto. CTA para seguir.

# Método de análise de perfil

Guia de leitura para a etapa 2. Diz o que olhar, como medir e como concluir. Vale para Instagram de personal trainer e de qualquer profissional que vende acompanhamento online.

## 1. Regras de ouro

1. **Repetição vira padrão, post solto vira pista.** Algo só é padrão quando aparece em 3 posts ou mais. Com 1 ou 2, chame de pista.
2. **Compare o perfil com ele mesmo.** Não existe número mágico de engajamento que sirva para todo mundo. O post que "foi bem" é o que ficou bem acima da média dos outros posts do mesmo perfil.
3. **Número sem fonte não entra.** Cada número da análise diz de qual print ou texto veio.
4. **Toda observação termina em ação.** "Ela usa muito carrossel" não serve. "Ela usa carrossel para ensinar e reels para mostrar resultado; você pode testar o mesmo par" serve.
5. **Pergunta central de cada post que foi bem:** qual problema da aluna ele toca, qual promessa faz, e por que alguém pararia de rolar o feed nele.

## 2. Como medir o que performa

Com os números que estiverem nos prints:

- **Engajamento de um post** = (curtidas + comentários) dividido pelos seguidores, vezes 100. Ex.: 900 curtidas + 100 comentários, 20.000 seguidores = 5%.
- **Média do perfil** = a média do engajamento dos posts que você tem.
- **Post acima da curva** = engajamento pelo menos 1,5 vez a média do perfil. Esses são os "que mais performam".
- **Reels:** compare as views de cada reels com a mediana das views dos reels do mesmo perfil (o valor do meio quando você coloca em ordem). Views de 3 vezes a mediana ou mais = reels que estourou.
- **Comentário pesa mais que curtida.** Post com muito comentário em relação às curtidas costuma ser pergunta, polêmica ou chamada para comentar uma palavra. Diga qual dos três.
- **Sem números:** use os sinais que o próprio perfil dá. Post fixado no topo, tema que vira destaque e assunto que ela repete muito são o que ela sabe que funciona.

Sempre diga quantos posts entraram na conta ("média de 7 posts com número").

## 3. O que olhar em cada parte

### Bio e topo do perfil
- Nome de exibição: tem palavra que alguém buscaria ("personal", "emagrecimento", "treino em casa")?
- Para quem fala: está escrito quem é a aluna (idade, momento de vida, profissão)?
- Promessa: qual resultado promete e em quanto tempo? Promete com número de quilos ou com algo que a aluna enxerga (roupa, energia, exame)?
- Prova: CREF, anos de profissão, número de alunas, antes e depois, mídia.
- Chamada e link: para onde o link leva (WhatsApp, página, formulário, lista de espera)? Tem chamada escrita ("chama no direct", "vagas abertas")?

### Destaques
- Quais existem e em que ordem. A ordem mostra o caminho de venda que ela quer (ex.: Quem sou, Resultados, Programa, Dúvidas).
- Tem destaque de depoimentos? De como funciona? De preço?

### Oferta e chamada para ação
- O que vende: programa ou acompanhamento online, plano de treino avulso, grupo, desafio, app próprio.
- Mostra preço ou esconde? Fala em vagas, turma, data?
- Como chama para comprar, post a post: "link na bio", "comenta a palavra X", "chama no direct", "manda QUERO". Conte quantos posts têm chamada para venda e quantos não têm nenhuma.

### Temas
Agrupe cada post em um destes baldes (e crie outro se precisar):
- Ensino: técnica, exercício, mito e verdade, erro comum.
- Dor e identificação: rotina, culpa, cansaço, falta de tempo.
- Prova: depoimento, antes e depois, print de mensagem de aluna.
- Bastidor e vida: rotina dela, família, opinião pessoal.
- Venda: abertura de vagas, como funciona, oferta.
Diga a proporção (ex.: "6 de 15 são prova") e qual balde concentra os posts acima da curva.

### Formatos
- Carrossel, reels, foto única. Qual é o mais usado e qual performa mais (não são sempre o mesmo).
- Reels: falando para a câmera, treino com texto na tela, antes e depois, trend com áudio.
- Duração dos reels se aparecer.

### Ganchos (a primeira frase, a capa, os primeiros 3 segundos)
Classifique cada gancho em um tipo:
- **Provocação:** contraria uma crença. "Você não precisa treinar todo dia pra emagrecer."
- **Erro comum:** aponta o que a aluna faz errado. "O erro que faz teu agachamento doer o joelho."
- **Resultado:** abre com o fim da história. "A calça de 2019 fechou depois de 4 meses."
- **Identificação:** descreve a aluna para ela se reconhecer. "Se você chega em casa às 19h sem energia, esse é pra você."
- **Número e prazo:** promete algo concreto e medido. "3 exercícios pra fazer em 10 minutos na sala."
- **Curiosidade:** deixa uma pergunta aberta. "O que acontece com teu corpo quando você para de compensar a pizza."
- **Autoridade:** abre com a experiência dela. "Em 8 anos atendendo mães, o que mais vi foi isso."
Diga qual tipo ela mais usa e qual tipo está nos posts acima da curva. Copie o gancho exato dela entre aspas, com a fonte, só como exemplo de estrutura.

### Estrutura do carrossel
Para os carrosséis que foram bem, anote:
- capa: frase, tamanho do texto, se tem foto dela;
- quantos slides;
- como desenvolve: lista (um item por slide), passo a passo, antes e depois, mito e verdade, história;
- último slide: chamada (salvar, comentar, direct, link) e se tem prova.

### Estrutura do reels
Para os reels que foram bem, monte a linha do tempo pelo que der para saber (texto colado, transcrição, texto na tela):
- 0 a 3 segundos: gancho (falado e escrito na tela?);
- meio: o que entrega (dica, demonstração, história);
- fim: chamada (comenta, salva, link, direct).
Sem transcrição, analise só o texto da capa e da legenda, e diga isso.

### Frequência
- Pelas datas dos posts (se aparecem) ou pela diferença entre posts na grade: quantos por semana.
- Proporção de reels e carrossel ao longo da grade.
- Se não dá para saber, escreva "não dá para saber pelos prints".

### Tom
- Próximo ou distante, leve ou duro, técnico ou simples, com humor ou sério.
- Como chama a seguidora ("amiga", "menina", "você").
- Expressões que repete (3 vezes ou mais).
- Usa emoji, gíria, palavrão, termo técnico.

## 4. Como concluir

Feche a análise do perfil com:
1. **Posicionamento em 2 linhas:** para quem ela fala e o que promete.
2. **Os 3 padrões mais fortes:** cada um com a prova (quantos posts, quais números).
3. **O que ela não faz:** temas, formatos ou dores que não aparecem na grade.
4. **Nota de 1 a 5 em cada ponto**, só se ajudar a comparar perfis: clareza da bio, força da oferta, consistência de tema, força dos ganchos, constância de postagem. Explique cada nota em uma frase.

## 5. Comparação de 2 ou 3 perfis

Monte uma tabela com uma coluna por perfil e estas linhas: para quem fala, promessa, prova principal, oferta e chamada, formato que mais performa, tema que mais performa, tipo de gancho preferido, frequência, tom. Depois diga em 3 frases o que cada um faz melhor que os outros e o espaço que nenhum deles ocupa.

## 6. Cuidados

- Antes e depois de corpo e promessa de quilos com prazo podem ferir as regras do conselho da profissão e do próprio Instagram. Se o concorrente faz isso e performa, anote, mas não sugira copiar: sugira a versão segura (roupa que voltou a servir, energia, exame, força).
- Sorteio, compra de seguidor e post patrocinado inflam número. Se perceber, desconte e avise.
- Trend de áudio ou meme performa rápido e morre rápido. Separe o que é moda do que é padrão do perfil.

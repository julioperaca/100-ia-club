# Formato combinado do texto.md

A skill copy grava `texto.md` na mesma pasta da `pauta.md` (`<pasta>/conteudo/AAAA-MM-DD-<slug>/texto.md`). O Modo Montar lê só este arquivo para montar as imagens. Este é o combinado entre as duas skills.

## Regras gerais

- Primeira linha: `# <tema>`.
- Logo abaixo, uma linha `Formato: carrossel | reels | stories | post único`.
- Cada parte começa com um título `## ...` exatamente como abaixo.
- Dentro de cada parte, linhas com rótulo: `Título:`, `Apoio:`, `Texto:`, `Botão:`, `Figurinha:`. Linha sem rótulo continua o rótulo de cima.
- Destaque na cor da marca: 1 a 3 palavras entre asteriscos (`*35 minutos*`), no máximo um destaque por slide ou story.
- Sempre termina com `## Legenda` (a legenda pronta para colar). O Modo Montar não usa a legenda nas imagens.

## Modelo, uso e imagens

Logo abaixo da linha `Formato:`, mais duas linhas:
- `Modelo: <nome exato de referencias/formatos.md>`: Foto, nicho e headline | Troque isso por isso | Foi assim que | Frase sobre foto | Esse é o segredo | Plano prático | Carrossel tweet | livre.
- `Uso: anúncio | vitrine` (só carrossel). Anúncio: no máximo 10 slides.

Rótulos novos, dentro de qualquer slide ou do `## Post`:
- `Nicho:` a faixa de 1 a 3 palavras em caixa alta acima do título (capa).
- `Imagem:` nome do arquivo da foto de fundo, na pasta do post (`foto-capa.jpg`). Se o aluno ainda não mandou, escreva `Imagem: pedir (o que a foto deve mostrar)`.
- `Print:` nome do arquivo do print de prova, um por linha (pode repetir). Se ainda não tem: `Print: pedir (o que o print prova)`.
- No Carrossel tweet, logo abaixo de `Uso:`, a linha `Foto de perfil: <arquivo>` (ou `pedir`).

Exemplo de capa do modelo 1:

```
## Slide 1
Nicho: MULHERES 40+
Título: O treino que cabe *antes do trabalho*
Apoio: Te explico como fazer isso na sua rotina.
Imagem: foto-capa.jpg
```

Exemplo de slide com prova:

```
## Slide 6
Título: Primeiro mês completo
Texto: Ela não faltou uma semana.
Print: print-ana-30dias.jpg
```

Frase sobre foto e Esse é o segredo são `Formato: post único`: o `## Post` leva `Título:` (a frase ou a headline), `Imagem:` e, no segredo, `Nicho:` opcional. A copy inteira vai em `## Legenda`.

## Carrossel

```
# Treino de 35 minutos
Formato: carrossel

## Slide 1
Título: Você não precisa de *uma hora* para treinar
Apoio: Arrasta que eu te mostro por quê.

## Slide 2
Título: O erro
Texto: Esperar sobrar uma hora livre na agenda.

## Slide 8
Título: Quer montar o seu?
Texto: Me chama no direct que eu te explico como funciona.
Botão: Me chama no direct

## Legenda
...
```

- `## Slide 1` é a capa (Título até 8 palavras, Apoio opcional).
- O último slide é o final (chamada; Botão opcional).
- Os do meio são miolo (Título opcional, Texto até 30 palavras). `Estilo: destaque` num slide do meio pinta o fundo alternativo (no máximo 2).

## Reels

```
## Gancho
Título: Treino curto conta sim
Apoio: (opcional, uma linha)

## Roteiro
(cenas, falas, texto na tela)

## CTA
(a chamada falada ou na tela)

## Legenda
```

O Modo Montar usa o `## Gancho` para a capa do reels (1080 x 1920). Título do gancho com até 8 palavras, o mesmo limite da capa do carrossel.

## Stories

```
## Story 1
Título: Bastidor de hoje
Texto: Montei o treino de uma aluna que só tem 30 minutos.
Figurinha: enquete "Você tem 30 minutos?"

## Story 2
...

## Legenda
(se não houver, escreva "sem legenda")
```

Cada `## Story N` vira um PNG 1080 x 1920. `Figurinha:` vira um espaço marcado na imagem para a pessoa colocar a figurinha no Instagram.

## Post único

```
## Post
Título: ...
Texto: ...

## Legenda
```

Vira um PNG 1080 x 1350.

## Se o texto.md vier diferente

O Modo Montar tenta entender: `## Slide N` sem rótulos = primeira linha é título e o resto é texto. Se não der para saber o que é slide, capa ou story, não adivinha: avisa qual parte não entendeu e pede para rodar o /copy de novo nessa pauta.

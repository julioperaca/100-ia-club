# O jeito do Peraça de pensar conteúdo

Régua do Modo Pauta. Tirado das aulas Action Day "Conteúdo 100%", "Plataforma, posicionamento e conteúdo" e "Instagram e análise de perfis" da mentoria Personal 100% Digital, com reforço do squad de conteúdo. Cada pauta cita a aula de onde veio a ideia no campo "Referência de aula" (use os nomes curtos: Conteúdo 100%, Posicionamento, Análise de perfis).

## 1. Posicionamento vem antes do post

Conteúdo só funciona depois de três respostas: quem você atende, qual problema resolve (ou para onde leva) e como resolve (o método). No cérebro isso está em `aluno-ideal.md` e `metodo.md`. Os temas saem da lista de dores e desejos da aluna, nunca da cabeça do personal. Posicionamento é como as pessoas lembram de você: quem fala de tudo (barriga, joelho, corrida, receita) não é lembrado por nada. (Conteúdo 100%; Posicionamento)

## 2. Os quatro tipos de conteúdo

| Tipo | O que é | Onde mora | Quanto |
|---|---|---|---|
| Inevitável | Os 3 a 5 temas da maior dor ou do maior desejo da aluna. Repetidos sempre, cada vez de um jeito. | Feed (vitrine), stories, aula, anúncio | A maioria dos posts |
| Complementar | Dores e desejos reais, mas menos urgentes. | Feed, em minoria; stories | Poucos |
| Interesse da audiência | O assunto do momento (novela, celebridade, polêmica da área, remédio da moda) usado como gancho e levado para a tese ou o método. Sem gancho mentiroso: o assunto precisa ter ligação real. | Stories; no feed, arquivar quando o assunto passar | De vez em quando |
| Identidade | Ideias, crenças, valores, bastidores, rotina, uma dificuldade que você viveu. Serve para gostarem de você: as pessoas compram primeiro a pessoa. Não serve para vender. | Stories e alguns posts da vitrine | Sempre presente nos stories |

(Conteúdo 100%; Posicionamento)

## 3. Objetivo de cada post

O caminho é atrair, conscientizar e converter: se não atrai, não consegue nem conscientizar. Na pauta, use estes objetivos:
- **Atrair:** gente nova que ainda não te conhece. Tema inevitável, capa de desejo forte e específico.
- **Conscientizar:** mostrar o erro do caminho comum (o inimigo comum) e por que o seu caminho funciona, com argumento.
- **Conectar:** conteúdo de identidade.
- **Provar:** resultado de aluna autorizada, print, relato. O resultado é soberano: perfil cheio de prova vende mesmo com capa fraca.
- **Converter:** oferta, convite para a avaliação, abertura de turma.

Sempre pergunte para cada pauta: o que eu quero que a aluna sinta? (Análise de perfis; Conteúdo 100%)

Chamada para ação que o Peraça recomenda: seguir (falando do que você faz por ela) ou conversar no direct. "Comenta tal palavra" só faz sentido quando o perfil já tem audiência. (Conteúdo 100%) A frase da chamada é do /copy; a pauta só diz qual das duas.

## 4. Como ligar o post ao método

- O tema é o desejo; a solução do post é o método, um mecanismo ou uma ideia fora do padrão. Não vale "disciplina, sono e água".
- Não precisa citar o nome do pilar. Diga o que a aluna fez, sem entregar o passo a passo inteiro: quem entrega tudo de graça vira só mais um perfil de dicas.
- O inimigo comum entra como o erro que a aluna comete. Sempre rebatido com argumento (use os argumentos do pilar no `metodo.md`), senão perde credibilidade.
- Todo conteúdo tem uma moral da história: a ideia central que ela leva embora.
- Tomar posição: uns vão discordar e outros vão se conectar. Ficar em cima do muro é ficar invisível.
- A pergunta que todo post de conversão responde: por que com você vai funcionar se ela já tentou dez vezes?
(Conteúdo 100%; Posicionamento)

## 5. Tema que funciona

- Desejo, não veículo: "treino em qualquer lugar", "meu método", "treino personalizado" são o como e não viram tema.
- Específico vence genérico, e curto prazo vence longo prazo: "resultados" < "emagrecer" < "parar de largar o treino na quarta".
- Teste: a aluna falaria isso para uma amiga no banheiro da festa? Se é termo técnico que ninguém fala em casa ("zona cardíaca", "periodização"), traduza para o desejo.
- O que é difícil de entender é difícil de vender. Explique com exemplo e analogia; a aluna está abaixo de você na linha do conhecimento.
(Conteúdo 100%; Posicionamento; Análise de perfis)

## 6. Formatos e quando usar

Não existe formato rei: o que funciona para um personal não funciona para outro e cansa com o tempo. Use como ponto de partida:

| Formato | Bom para | Estruturas que o Peraça usa |
|---|---|---|
| Carrossel | Inevitáveis, conscientizar, provar. É o que segura a vitrine. | Os 5 modelos de carrossel de `formatos.md`: Foto, nicho e headline; Troque isso por isso; Foi assim que; Plano prático; Carrossel tweet. Anúncio: até 10 slides. Vitrine: até 20. |
| Reels | Atrair gente nova. | Cena de 5 segundos com o texto na tela e "leia a legenda"; carrossel narrado sobre vídeo de aluna treinando; resposta de caixinha em vídeo; corte de aula. Vídeo com fala sempre com legenda. |
| Stories | Identidade, interesse da audiência, bastidores, nutrir quem ainda não comprou. A mesma ideia do feed por outro ângulo. | Sequência curta com moral; caixinha; enquete; bastidor do atendimento |
| Post único | Identidade, prova, aviso de turma. A copy vai na legenda. | Os modelos Frase sobre foto e Esse é o segredo (`formatos.md`); print de mensagem de aluna (contexto, tese, prova, chamada) |

Reels de brincadeira e trend podem ficar só na aba de reels, fora da grade principal. Post bom antigo pode voltar em outro formato. (Conteúdo 100%; Posicionamento; Análise de perfis)

## 7. Frequência possível

- Primeiro a vitrine: os 9 a 15 primeiros posts da grade precisam ser intencionais (maioria de inevitáveis, mais prova, quem você é e oferta). Quem ainda não tem vitrine começa por ela.
- Depois, a rotina mínima: 12 conteúdos em 30 dias, uns 3 por semana, e stories todos os dias (no mínimo um). Constância vale mais que volume; o erro comum é postar muito por duas semanas e sumir, ou desistir depois de um post fraco.
- Nada de três reels por dia: o método é para quem atende aluno e tem pouco tempo.
(Conteúdo 100%; Posicionamento; Análise de perfis)

## 8. Capa e visual (vale para o Modo Montar e para a ideia central da pauta)

- A capa decide se o post é aberto quando a pessoa entra no perfil. Muita gente só lê as capas.
- Capa boa toca dor ou desejo, é específica, fala direto com ela e não entrega a resposta.
- Legível no celular: letra grande, contraste forte, texto longe das margens, sem logo grande em todo post.
- Os posts conversam entre si: mesma fonte, mesma paleta. Visual caprichado passa preço mais alto.
(Análise de perfis)

## 9. Reforço do squad de conteúdo

- Perfil pequeno (menos de 2 mil seguidores) ou começando: mais posts de atrair, quase nada de oferta direta.
- Turma abrindo nas próximas 2 a 4 semanas: semanas 1 e 2 com mais conscientizar (inimigo comum), semana 3 com o caminho e a prova, semana 4 com prova e oferta.
- Sem campanha: equilíbrio entre conscientizar, conectar e provar, variando formato.
- Não repetir o mesmo formato em dias seguidos. Feed e stories se complementam: o story do dia amplia o post do dia.

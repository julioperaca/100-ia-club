# Pauta: [tema, em palavras que a aluna usaria]

> O que é: a pauta de um post, montada pela skill conteudo. O texto do post é da skill copy.
> Última atualização: [dd/mm/aaaa]
> Status: pauta pronta | texto pronto | imagens prontas
> Próximo passo: rodar /copy para escrever o texto desta pauta

- Data de postar: [dia da semana, dd/mm/aaaa]
- Formato: [carrossel de N slides | reels | stories (N) | post único]
- Tipo: [inevitável | complementar | interesse da audiência | identidade]
- Objetivo: [atrair | conscientizar | conectar | provar | converter]
- Pilar ou inimigo comum: [Pilar N: nome] ou [inimigo comum: frase do metodo.md]
- Chamada para ação: [seguir | conversar no direct | avaliação | comentar palavra]

## Ideia central

[Uma ou duas frases: o que a aluna entende e sente ao terminar. É a moral da história.]

## Caminho do post

[3 a 6 linhas com a ordem das ideias, sem a frase pronta. Ex.: abre na dor X; mostra o erro comum (inimigo); rebate com o argumento do pilar; mostra o que muda; chamada.]

## Por que esta pauta

[Uma linha: por que este tema, este formato e este objetivo agora.]

## De onde veio

- Dor ou desejo: [frase] ([arquivo, seção])
- Método: [pilar, conceito ou argumento] (metodo.md)
- Prova usada: [case autorizado | nenhuma]
- Referência de aula: [Conteúdo 100% | Posicionamento | Análise de perfis], [ideia usada, ex.: estrutura troque isso por isso]

## Para o /copy

- Estrutura sugerida: [nome do formato de referencias/formatos.md: História de aluna | Troque isso por isso | Plano prático; ou outra estrutura da régua, ex.: erro comum e o certo]
- Palavras da aluna para usar: ["frase literal de aluno-ideal.md"]
- Não pode: [ex.: prometer quilos; citar nome da aluna]

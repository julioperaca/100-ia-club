# Espião: @perfil

> O que é: análise do Instagram de @perfil (concorrente | referência), comparada com o seu segundo cérebro, com 5 ideias de post.
> Última atualização: DD/MM/AAAA
> Status: completo | em andamento
> O que falta: (ex.: prints com números; transcrição de reels; ou "nada")

Material analisado: (lista do que chegou, ex.: "print-topo.png, print-grade-1.png, print-grade-2.png, 4 legendas coladas; página pública não abriu")
Posts com tema identificado: N. Posts com número: N.
Só conteúdo público. O objetivo é aprender os padrões, não copiar.

## 1. Posicionamento

- para quem fala: ... (fonte)
- promessa: ... (fonte)
- prova: ... (fonte)
- chamada e link da bio: ... (fonte)
- destaques: ... (fonte)

Em 2 linhas: ...

## 2. Oferta e chamada para ação

- o que vende: ... (fonte)
- preço ou vagas: ... (fonte)
- chamadas usadas: ... (quantos posts com chamada de venda de quantos)

## 3. O que mais performa

Média de engajamento do perfil: N% (N posts com número) ou "sem números nos prints".

| Post | Formato | Tema | Gancho | Números | Acima da curva? |
|---|---|---|---|---|---|
| ... | ... | ... | "..." | ... (fonte) | sim / não |

## 4. Temas e formatos

- temas: (proporção por balde)
- formato mais usado: ...
- formato que mais performa: ...
- frequência: ...

## 5. Ganchos

- tipo mais usado: ...
- tipo nos posts acima da curva: ...
- exemplos (só a estrutura, não para copiar): "..." (fonte)

## 6. Estrutura

- carrossel: capa, número de slides, desenvolvimento, último slide
- reels: 0 a 3 s, meio, fim

## 7. Tom

- ...

## 8. Padrões e pistas

Padrões (3 posts ou mais):
1. ...
Pistas (1 ou 2 posts):
1. ...

O que ela não faz: ...

## 9. Comparação com você

Relação com a sua aluna: mesma aluna | parecida | outra aluna.

### O que você pode aproveitar

| O que ela faz | Como fica do seu jeito | Por quê (cérebro) |
|---|---|---|

### O que não combina com você

- ... (motivo, fonte)

### Lacunas que ela não ocupa

1. ... (o que você tem: fonte)

## 10. Cinco ideias de post

(Só a ideia e o gancho. Para virar pauta, rode /conteudo e peça a pauta com estas ideias. O texto do post é do /copy.)

### Ideia 1. ...
- formato:
- gancho: "..."
- tipo de gancho:
- de onde veio:
- ligado a:
- chamada no fim:

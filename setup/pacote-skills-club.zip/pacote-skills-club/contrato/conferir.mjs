// Conferência opcional. Só roda se o computador já tiver Node.
// Uso:
//   node conferir.mjs cpf 52998224725
//   node conferir.mjs cnpj 11222333000181
//   node conferir.mjs extenso 1200,00
//   node conferir.mjs nome-arquivo "Bruno Exemplo"

const [, , cmd, ...resto] = process.argv;
const arg = resto.join(' ');

function cpfValido(v) {
  const d = String(v).replace(/\D/g, '');
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return false;
  for (const t of [9, 10]) {
    let soma = 0;
    for (let i = 0; i < t; i++) soma += Number(d[i]) * (t + 1 - i);
    const dv = ((soma * 10) % 11) % 10;
    if (dv !== Number(d[t])) return false;
  }
  return true;
}

function cnpjValido(v) {
  const d = String(v).replace(/\D/g, '');
  if (d.length !== 14 || /^(\d)\1{13}$/.test(d)) return false;
  const calc = (n) => {
    const pesos = n === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const soma = pesos.reduce((s, p, i) => s + Number(d[i]) * p, 0);
    const r = soma % 11;
    return r < 2 ? 0 : 11 - r;
  };
  return calc(12) === Number(d[12]) && calc(13) === Number(d[13]);
}

const UN = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
const DEZ = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
const CEN = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];

function ate999(n) {
  if (n === 0) return '';
  if (n === 100) return 'cem';
  const c = Math.floor(n / 100), r = n % 100, partes = [];
  if (c) partes.push(CEN[c]);
  if (r) partes.push(r < 20 ? UN[r] : DEZ[Math.floor(r / 10)] + (r % 10 ? ' e ' + UN[r % 10] : ''));
  return partes.join(' e ');
}

function inteiroPorExtenso(n) {
  if (n === 0) return 'zero';
  const grupos = [];
  while (n > 0) { grupos.push(n % 1000); n = Math.floor(n / 1000); }
  const nomes = [['', ''], ['mil', 'mil'], ['milhão', 'milhões'], ['bilhão', 'bilhões']];
  const partes = [];
  for (let i = grupos.length - 1; i >= 0; i--) {
    const g = grupos[i];
    if (!g) continue;
    let txt = i === 1 && g === 1 ? 'mil' : ate999(g) + (i ? ' ' + nomes[i][g === 1 ? 0 : 1] : '');
    partes.push({ txt, g });
  }
  // "e" antes do último grupo quando ele é < 100 ou centena redonda
  let out = '';
  partes.forEach((p, idx) => {
    if (idx === 0) out = p.txt;
    else if (idx === partes.length - 1 && (p.g < 100 || p.g % 100 === 0)) out += ' e ' + p.txt;
    else out += ' ' + p.txt;
  });
  return out;
}

function reaisPorExtenso(valor) {
  const limpo = String(valor).trim().replace(/[R$\s]/g, '');
  const num = limpo.includes(',') ? Number(limpo.replace(/\./g, '').replace(',', '.')) : Number(limpo);
  if (!Number.isFinite(num) || num <= 0) throw new Error('valor inválido: ' + valor);
  const centavosTot = Math.round(num * 100);
  const reais = Math.floor(centavosTot / 100), cent = centavosTot % 100;
  const partes = [];
  if (reais) {
    let r = inteiroPorExtenso(reais);
    const redondoMilhao = reais >= 1e6 && reais % 1e6 === 0;
    r += redondoMilhao ? ' de reais' : reais === 1 ? ' real' : ' reais';
    partes.push(r);
  }
  if (cent) partes.push(inteiroPorExtenso(cent) + (cent === 1 ? ' centavo' : ' centavos'));
  return partes.join(' e ');
}

function nomeArquivo(nome) {
  return nome.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

switch (cmd) {
  case 'cpf': console.log(cpfValido(arg) ? 'CPF VÁLIDO' : 'CPF INVÁLIDO'); break;
  case 'cnpj': console.log(cnpjValido(arg) ? 'CNPJ VÁLIDO' : 'CNPJ INVÁLIDO'); break;
  case 'extenso': console.log(reaisPorExtenso(arg)); break;
  case 'nome-arquivo': console.log(nomeArquivo(arg)); break;
  default: console.log('Comandos: cpf, cnpj, extenso, nome-arquivo');
}

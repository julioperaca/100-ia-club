# Perfil profissional

Arquivo usado pela skill contrato. Copie para `~/brain/perfil-profissional.md` (ou `~/meu-negocio/perfil-profissional.md`) e troque os valores. Aqui ficam só dados seus, nunca dados de aluno.

- nome_ou_razao_social: Carla Teste, do Programa Leve e Forte
- cpf_ou_cnpj: 11.222.333/0001-81
- cref: 000000-G/SC
- cidade_uf: Florianópolis/SC
- canal_suporte: WhatsApp (48) 90000-0000
- dias_horarios_suporte: segunda a sexta, das 8h às 18h
- prazo_resposta: 24 horas úteis
- forma_entrega: aplicativo de treino
- periodicidade_ajustes: 30 dias
- prazo_primeiro_plano: 3
- planos_por_mes: 1
- dias_pausa: 30
- multa_percentual: 20%
- foro: cidade do aluno
- aviso_juridico_lido: sim

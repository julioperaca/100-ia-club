# Formulário de Cadastro do aluno

O aluno preenche este cadastro no Google Forms ou no Respondi, as respostas caem numa planilha e a skill puxa os dados dali para o contrato. Se preferir, o aluno manda as mesmas respostas por mensagem (ou respondendo com uma IA) e você cola na conversa. Use as perguntas exatamente como estão abaixo: assim a skill reconhece as colunas sozinha.

## Perguntas (todas obrigatórias)

Cada pergunta preenche um campo do contrato do Programa Personalizado. Sem ela, o contrato não sai.

| Pergunta | Tipo da pergunta | Vai para o contrato em |
|---|---|---|
| Qual o seu nome completo? | Resposta curta | Nome do CONTRATANTE e assinatura |
| CPF | Resposta curta | CPF do CONTRATANTE e assinatura |
| RG | Resposta curta | RG do CONTRATANTE |
| Qual o seu endereço completo (rua, complemento e número)? | Resposta curta | Endereço |
| Qual o seu bairro? | Resposta curta | Bairro |
| Qual cidade e estado você mora? | Resposta curta | Cidade/UF e foro (Cláusula 13.2) |
| Qual o seu CEP? | Resposta curta | CEP |
| Qual o seu e-mail? | Resposta curta | E-mail e assinatura |
| Qual o seu WhatsApp com DDD? | Resposta curta | Telefone |

A planilha cria sozinha a coluna "Carimbo de data/hora", com a data de cada resposta. A skill usa essa data para separar alunos com nome parecido.

Valor, forma de pagamento, datas, duração e uso de imagem não entram no formulário: são da venda, e a skill pergunta ao personal na hora de gerar.

## Como ajudar o personal

Use esta seção quando o personal disser que ainda não tem cadastro. Fale simples, um passo por vez, e espere ele dizer "feito" antes do próximo. Se ele travar, explique de novo com outras palavras ou peça um print da tela.

**Passo 1. Mostre os caminhos e ajude a escolher.**

> Você tem três jeitos de montar o seu Formulário de Cadastro do aluno:
> 1. Google Forms: grátis, só precisa de uma conta Google (a mesma do Gmail). É o mais simples e o que eu recomendo.
> 2. Respondi: aplicativo brasileiro de formulários, bonito no celular do aluno. Tem plano grátis.
> 3. Eu monto as perguntas aqui: te entrego uma mensagem pronta, você manda para o aluno no WhatsApp e ele responde ali mesmo. Não precisa criar nada.
> Qual você prefere? Se não souber, vamos de Google Forms.

**Passo 2. Conduza o caminho escolhido** (seções abaixo), um passo por vez.

**Passo 3. Teste.** Peça para ele mesmo responder o formulário uma vez, como se fosse aluno, e confira se a resposta apareceu (na planilha, no Respondi ou na mensagem).

**Passo 4. Ligue na skill.** Com o formulário pronto, siga para o Modo Integrar (`modo-integrar.md`, Pergunta 1) com a ferramenta escolhida.

## Caminho 1. Google Forms (uns 10 minutos, uma vez só)

1. No computador, abra o navegador e entre em forms.google.com com sua conta Google.
2. Clique em "Formulário em branco" (o quadrado com o sinal de mais).
3. Clique em "Formulário sem título" e escreva "Cadastro do aluno". Na descrição, logo abaixo, escreva: "Preciso destes dados para montar o seu contrato."
4. Na primeira pergunta, apague "Pergunta sem título" e cole "Qual o seu nome completo?". Do lado, onde aparece o tipo, escolha "Resposta curta". Embaixo, ligue a chave "Obrigatória".
5. Clique no sinal de mais da barra lateral para criar a próxima pergunta. Repita o passo 4 para as 9 perguntas da tabela, na mesma ordem, copiando o texto igual.
6. Lá em cima, clique na aba "Respostas" e depois em "Vincular ao Planilhas". Escolha "Criar uma nova planilha" e clique em "Criar". Pronto: cada resposta vira uma linha.
7. Clique em "Enviar" (canto superior direito), depois no ícone de link, marque "Encurtar URL" e clique em "Copiar".
8. Guarde esse link num lugar fácil (por exemplo, mande para você mesmo no WhatsApp). Ele é o mesmo para todos os alunos.

## Caminho 2. Respondi

1. Entre em respondi.app e crie sua conta (ou entre com a conta Google).
2. Clique para criar um formulário novo, começando do zero (sem modelo).
3. Dê o nome "Cadastro do aluno".
4. Crie as 9 perguntas da tabela, na mesma ordem, copiando o texto igual. Em cada uma, escolha o tipo de texto curto e marque como obrigatória.
5. Publique o formulário e copie o link de compartilhamento.
6. Decida como a skill vai ler as respostas: ligar o Respondi ao Google Planilhas (as respostas vão sozinhas para uma planilha) ou baixar as respostas pelo próprio Respondi em CSV. Na hora de integrar, a skill pergunta qual dos dois você usa.

Se algum botão estiver com outro nome, peça para o personal mandar um print da tela e guie pelo que aparece nela.

## Caminho 3. A IA monta as perguntas (sem criar formulário)

Entregue a mensagem da seção Sem formulário, abaixo, já pronta para copiar. Explique: "Quando o aluno responder, copie a resposta dele (ou tire um print) e cole aqui na conversa. Eu tiro os dados de lá e monto o contrato." Na integração, esse caminho grava `fonte: colar-na-hora`.

## Mensagem pronta para o WhatsApp

> Oi, [nome do aluno]! Que bom ter você comigo. Para eu preparar o seu contrato, preencha este cadastro rapidinho: [link do formulário]. Leva uns 2 minutos. Assim que você responder, eu te mando o contrato para assinar.

Troque o que está entre colchetes antes de enviar.

## Sem formulário: respostas por mensagem

Se o aluno não for preencher formulário, mande esta mensagem. Ele responde ali mesmo, ou com ajuda de uma IA, e você cola a resposta (ou o print) na conversa com a skill.

> Oi, [nome do aluno]! Para eu preparar o seu contrato, me responda aqui: 1. Nome completo. 2. CPF. 3. RG. 4. Endereço (rua, complemento e número). 5. Bairro. 6. Cidade e estado. 7. CEP. 8. E-mail. 9. WhatsApp com DDD.

## Depois

Com o formulário criado (Google Forms ou Respondi), diga "integrar" para a skill pedir acesso às respostas. A partir daí, quando o aluno responder, é só dizer "faz o contrato do fulano".

---
name: contrato
description: Gera o contrato do aluno do Programa Personalizado de Treinamento Online, em PDF. Use para gerar contrato, contrato do aluno, novo contrato, termo de adesão, fechei um aluno.
when-to-use: >
  Quando o personal disser "gerar contrato", "contrato do aluno", "novo contrato",
  "termo de adesão", "fechei um aluno", "faz o contrato da Maria", "preciso mandar
  o contrato", "integrar contrato", "conectar planilha dos alunos", "conectar o
  Respondi", "formulário de cadastro", "criar formulário do aluno" ou /contrato.
argument-hint: "[nome do aluno] ou [integrar]"
allowed-tools: "Read, Write, Edit, Glob, Grep, Bash, PowerShell"
user-invocable: true
---

# Contrato do Aluno

## Configuração

```
PERFIL_PATH: ""
```

Se o perfil estiver fora do lugar padrão, coloque acima o caminho completo da PASTA onde está o `perfil-profissional.md` (ex.: `C:\Users\ana\Drive\negocio`). Vazio = busca automática.

## Persona

Você é o assistente de escritório de um personal trainer que vende o Programa Personalizado (forma completa, quando precisar: Programa Personalizado de Treinamento Online). Fala simples e direto, uma pergunta por vez (ou um grupinho que anda junto), sempre com sugestão quando houver. Nunca usa termo técnico. Nunca inventa dado.

## Onde ficam os arquivos

- Pasta do negócio: `PERFIL_PATH`; se vazio, a primeira que tiver `perfil-profissional.md` (ou `.yaml`) entre `~/brain/` e `~/meu-negocio/` (Glob na home; no Windows a home é `C:\Users\<nome>`). Se nenhuma existir, a padrão é `~/brain/`.
- Nela ficam `perfil-profissional.md`, `config-contrato.md` e a pasta `contratos/`.
- Arquivos da skill: `${CLAUDE_SKILL_DIR}/template.md` (contrato base), `impressao.html` (molde A4), `conferir.mjs` (conferência opcional), `modo-integrar.md`, `formulario-modelo.md` (Formulário de Cadastro do aluno: perguntas, caminhos para criar e mensagem pronta), e os exemplos `perfil-profissional.exemplo.md` e `config-contrato.exemplo.md`.

## Qual modo

Leia `$ARGUMENTS` e a pasta do negócio:
- Pediu "integrar", "conectar planilha", "conectar o Respondi" ou "configurar": **Modo 1**.
- Pediu "formulário de cadastro", "criar formulário" ou "não tenho cadastro": leia e siga `${CLAUDE_SKILL_DIR}/formulario-modelo.md` (seção Como ajudar o personal) e, com o formulário pronto, siga para o **Modo 1**.
- Qualquer outro pedido (inclusive vazio): **Modo 2**. Se não existir `perfil-profissional.md`, diga "Primeiro vou pegar seus dados uma vez só" e rode a Etapa 1 do Modo 1 antes de seguir.

## Modo 1. Integrar (uma vez, no setup)

Leia e siga `${CLAUDE_SKILL_DIR}/modo-integrar.md`: dados do profissional, se ele já tem o Formulário de Cadastro do aluno (se não tiver, a skill sugere os caminhos e ajuda a criar), de onde vêm as respostas do aluno (Google Forms, Respondi, aplicativo de treino como o MFIT, ou respostas pela IA coladas na conversa) e o pedido de acesso a esse lugar (conector Google Drive, link da planilha, arquivo baixado ou texto e print colados), mapeamento de colunas, teste e gravação de `config-contrato.md`.

## Modo 2. Gerar (todo dia)

### Passo 1. Profissional

Leia `perfil-profissional.md` em silêncio. Só mostre se faltar algum campo (pergunte o que falta). Se não tiver `aviso_juridico_lido: sim`, mostre o aviso jurídico abaixo e espere o "ok".

### Passo 2. Aluno

Campos: nome completo, CPF, RG, endereço (rua, complemento e número), bairro, cidade/UF, CEP, e-mail, telefone.

Sem `config-contrato.md`, antes de pedir os dados pergunte uma vez: "Você já tem um Formulário de Cadastro do aluno, onde ele preenche os dados para o contrato?". Se não tiver, diga que dá para seguir agora colando as respostas e ofereça em uma linha: "Depois deste contrato eu te ajudo a criar o seu Formulário de Cadastro, passo a passo. Leva uns 10 minutos." Com o sim, ao terminar a entrega, siga `${CLAUDE_SKILL_DIR}/formulario-modelo.md` (seção Como ajudar o personal).

1. Com `config-contrato.md` e fonte de planilha: busque o nome pedido na fonte configurada (conector Google Drive baixando em CSV, `curl -sL` do link, ou Read do arquivo CSV, respeitando o `separador`). Se a fonte for `conector-drive` e o conector não estiver nesta conversa, avise em uma frase e siga pelo item 2. Compare sem acento e sem diferença de maiúscula. Uma pessoa: siga. Mais de uma parecida: liste nome completo e data da resposta e pergunte qual. Nenhuma: diga que não achou e ofereça o caminho manual.
2. Com `fonte: colar-na-hora`, sem `config-contrato.md` ou com a fonte fora do ar: peça "Cole aqui as respostas do aluno, ou mande o print ou o PDF." e extraia cada campo pelo sentido (vale resposta do Google Forms, do Respondi, de conversa com IA ou de mensagem de WhatsApp). Se não tiver, pergunte campo a campo. No fim, sugira em uma linha: "Quando quiser, diga integrar e eu ligo sua planilha do Google Forms ou do Respondi para não precisar colar." (Não sugira isso se a fonte for `colar-na-hora`.)
3. Mostre os dados achados e pergunte o que faltar. Nunca complete com palpite.

### Passo 3. Venda

Pergunte só o que é da venda:
- Valor pago.
- Forma de pagamento: Pix à vista, cartão em quantas vezes de quanto, ou boleto (à vista ou em quantas vezes de quanto).
- Data do pagamento (no parcelado, da primeira parcela) e data de início.
- Duração em meses.
- Número de planos: sugira meses x `planos_por_mes` do perfil e confirme.
- Uso de imagem: autoriza? Com rosto ou sem rosto?

### Passo 4. Validações

Se algo falhar, explique em uma frase e peça de novo:
- CPF: 11 dígitos e dígitos verificadores certos. CNPJ: 14 dígitos e verificadores certos.
- CREF com número e UF.
- E-mail com @ e domínio. CEP com 8 dígitos (formato 00000-000).
- Valor maior que zero. Parcelado: parcelas x valor da parcela = total exato.
- Meses, planos, pausa e prazo do primeiro plano são números inteiros. Datas existem no calendário.

Se `node --version` funcionar, confira com `node "${CLAUDE_SKILL_DIR}/conferir.mjs" cpf <número>` (também `cnpj` e `extenso <valor>`). Se não, calcule você mesmo pelo algoritmo oficial.

### Passo 5. Montagem dos campos

| Campo do modelo | Como preencher |
|---|---|
| `[NOME DO PROFISSIONAL OU RAZÃO SOCIAL]`, `[CPF OU CNPJ DO PROFISSIONAL]`, `[CREF DO PROFISSIONAL]`, `[CANAL DE SUPORTE]`, `[DIAS E HORÁRIOS DE SUPORTE]`, `[PRAZO DE RESPOSTA]`, `[FORMA DE ENTREGA]`, `[PERIODICIDADE DOS AJUSTES]`, `[PRAZO DO PRIMEIRO PLANO]`, `[DIAS DE PAUSA]`, `[PERCENTUAL DE MULTA]` | Perfil |
| `[CIDADE DO PROFISSIONAL]` | Cidade do perfil, sem UF |
| `[NOME COMPLETO DO CLIENTE]`, `[CPF DO CLIENTE]`, `[RG DO CLIENTE]`, `[ENDEREÇO DO CLIENTE]`, `[BAIRRO DO CLIENTE]`, `[CEP DO CLIENTE]`, `[E-MAIL DO CLIENTE]`, `[TELEFONE DO CLIENTE]` | Aluno. CPF como 000.000.000-00, CEP como 00000-000 |
| `[CIDADE/UF DO CLIENTE]` | Cidade/UF do aluno (ou a cidade fixa do campo foro do perfil) |
| `[NÚMERO DE MESES]`, `[NÚMERO DE PLANOS]` | Venda |
| `[VALOR TOTAL]` / `[VALOR TOTAL POR EXTENSO]` | 1.200,00 / mil e duzentos reais (centavos: "mil duzentos e trinta e quatro reais e cinquenta e seis centavos") |
| `[FORMA DE PAGAMENTO]` | "à vista, via Pix", "à vista, via boleto" ou "parcelado em 6 (seis) vezes de R$ 200,00 (duzentos reais) no cartão de crédito" (ou "no boleto") |
| `[DATA DO PAGAMENTO]`, `[DATA DE INÍCIO]` | Formato 21/10/2026 |
| `[AUTORIZAÇÃO DE IMAGEM]` | Autorizou: `( X ) Autorizo o uso do meu depoimento e de fotos de evolução nas redes da CONTRATADA, COM ROSTO. Posso retirar esta autorização a qualquer momento, por escrito.` (ou SEM ROSTO). Não autorizou: `( X ) Não autorizo o uso do meu depoimento nem de fotos de evolução.` |
| `[DIA]`, `[MÊS]`, `[ANO]` | Data de hoje, mês por extenso em minúsculo |

### Passo 6. Resumo e confirmação

Mostre todos os campos em três blocos (Profissional, Aluno, Venda) e pergunte "Está tudo certo? Posso gerar?". Só gere com o "sim". Campo vazio bloqueia.

### Passo 7. Gerar

1. Pasta: `<pasta do negócio>/contratos/`; se não houver pasta do negócio, `~/Documentos/contratos/` (se `~/Documentos` existir) ou `~/Documents/contratos/`. Crie se faltar.
2. Nome: `contrato-<nome-do-aluno>-<AAAA-MM-DD>`, minúsculo, sem acento, espaço vira hífen (ex.: `contrato-joao-da-silva-2026-10-21`). Se já existir, acrescente `-2`.
3. `.md`: leia `template.md`, troque cada campo, grave com Write.
4. `.html`: leia `impressao.html`; troque `{{TITULO}}` por "Contrato <nome do aluno>" e `{{CONTEUDO}}` pelo contrato em HTML até o item 13.2 inclusive (`#` vira `<h1>`, `##` vira `<h2>`, lista vira `<ul><li>`, `**x**` vira `<strong>x</strong>`, parágrafo vira `<p>`). Não converta a parte de cidade, data e assinaturas: o molde já traz esse bloco pronto, com área grande para assinatura eletrônica (gov.br e similares carimbam um selo ali). Só preencha os campos entre colchetes dele. Grave com Write.
5. Confira que não sobrou `[` no `.md` nem no `.html`. Sobrou: pare e pergunte o campo.
6. `.pdf`: você mesmo monta e roda o comando do navegador, que já vem instalado (não precisa instalar nada). Use caminhos absolutos.
   - **Mac** (Bash): se existir `/Applications/Google Chrome.app`, rode
     `"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --user-data-dir=/tmp/contrato-navegador --no-pdf-header-footer --print-to-pdf="<arquivo.pdf>" "file://<arquivo.html>"`.
     Sem Chrome, tente `/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge` com os mesmos parâmetros.
   - **Linux** (Bash, quando `uname` responde Linux): ache o navegador com `C=$(command -v google-chrome google-chrome-stable chromium chromium-browser microsoft-edge | head -n 1)` e rode
     `"$C" --headless=new --user-data-dir=/tmp/contrato-navegador --no-pdf-header-footer --print-to-pdf="<arquivo.pdf>" "file://<arquivo.html>"`.
     Se `$C` sair vazio, não há navegador: vá para o plano B do Passo 8.
   - **Windows** (PowerShell): procure o primeiro que existir (`Test-Path`), nesta ordem:
     `"${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"`, `"$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"`, `"$env:ProgramFiles\Google\Chrome\Application\chrome.exe"`, `"$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"`. Rode
     `& "<exe>" --headless=new --user-data-dir="$env:TEMP\contrato-navegador" --no-pdf-header-footer --print-to-pdf="<arquivo.pdf>" "file:///<arquivo.html com barras normais, ex.: C:/Users/ana/brain/contratos/contrato.html>"`.
   - Confira se o PDF existe e tem tamanho maior que zero (Mac e Linux `ls -l`; Windows `Get-Item`).

### Passo 8. Entrega

1. PDF gerado: abra o PDF (Mac `open "<arquivo.pdf>"`; Linux `xdg-open "<arquivo.pdf>"`; Windows `Start-Process "<arquivo.pdf>"`).
2. Sem navegador ou PDF vazio: abra o HTML do mesmo jeito e diga: "Aperte Ctrl+P (Cmd+P no Mac) e escolha Salvar como PDF." No Linux sem navegador achado, acrescente: "Para gerar o PDF direto, instale o Google Chrome: baixe o arquivo .deb em google.com/chrome e dê dois cliques nele."
3. Diga onde salvou e feche assim:

```
Contrato do Bruno Exemplo pronto.
Salvei em ~/brain/contratos/:
  contrato-bruno-exemplo-2026-10-21.pdf (já abri para você)
  contrato-bruno-exemplo-2026-10-21.html e .md (cópias editáveis)
Agora é só mandar o PDF para o aluno assinar na ferramenta de assinatura eletrônica que você preferir, como gov.br, ZapSign ou Clicksign.
```

## Aviso jurídico (mostrar uma vez)

> Antes de usar: este modelo foi revisado tecnicamente, mas não substitui advogado. Duas partes pedem atenção de um advogado antes de você usar com muitos alunos: a Cláusula 5 (cancelamento depois de 7 dias e multa) e o item 7.4 (limite de responsabilidade). Leve o contrato para um advogado conferir uma vez.

## Regras

1. Nunca invente dado. Campo vazio bloqueia a geração.
2. Dados do aluno ficam só no contrato gerado (LGPD). Nunca grave dado de aluno no perfil, na config, em memória ou em qualquer outro arquivo. Leia a planilha só na hora e não salve cópia.
3. Não altere cláusulas. Só preencha campos. Se o personal pedir mudança, faça só neste contrato e lembre que mudança jurídica pede advogado.
4. Nada para instalar: sem Python, sem pandoc. `conferir.mjs` só se o Node já existir.
5. Sem travessão e sem emoji nos arquivos gerados. Português com acentuação completa.
6. Escreva sempre Programa Personalizado, com iniciais maiúsculas. A forma completa, Programa Personalizado de Treinamento Online, só onde precisar (título e Cláusula 1 do contrato).

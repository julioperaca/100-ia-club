# Modo 1. Integrar (roda uma vez)

Objetivo: deixar salvos os dados do profissional e o lugar de onde saem as respostas dos alunos (Google Forms, Respondi ou respostas coladas na conversa). Depois disso, gerar contrato vira uma frase.

## Etapa 1. Dados do profissional

1. Procure o perfil (ordem do SKILL.md, seção Onde ficam os arquivos). Se achar, mostre e pergunte "Esses dados continuam certos?".
2. Se não achar, pergunte em conversa, nesta ordem e com estas sugestões:
   - Nome completo ou razão social, e CPF ou CNPJ.
   - CREF com número e UF (ex.: 012345-G/SP). Obrigatório por lei, sem CREF não gera contrato.
   - Cidade/UF onde você atende.
   - Canal de suporte (ex.: WhatsApp com número), dias e horários (sugestão: segunda a sexta, das 8h às 18h) e prazo de resposta (sugestão: 24 horas úteis).
   - Como entrega o treino: aplicativo (qual), plataforma ou PDF.
   - De quanto em quanto tempo ajusta o plano (sugestão: 30 dias).
   - Em quantos dias úteis entrega o primeiro plano (sugestão: 3).
   - Quantos planos de treino costuma entregar por mês de contrato (sugestão: 1). Vira o padrão; muda na venda se precisar.
   - Quantos dias de pausa permite (sugestão: 30).
   - Multa de cancelamento sobre os meses restantes (sugestão: 20%).
   - Foro: sugestão "cidade do aluno". Se ele quiser outra cidade, avise que o Código de Defesa do Consumidor garante ao aluno processar na cidade dele, então a cidade do aluno é o mais seguro.
3. Valide CPF/CNPJ e CREF (regras do Passo de validações no SKILL.md).
4. Mostre o aviso jurídico (texto no SKILL.md) e espere o "ok".
5. Ofereça salvar: "Posso salvar esses dados para não perguntar de novo?". Com o sim, grave `perfil-profissional.md` no formato de `${CLAUDE_SKILL_DIR}/perfil-profissional.exemplo.md`, com `aviso_juridico_lido: sim`.

## Etapa 2. De onde vêm as respostas do aluno

O aluno responde o cadastro de um destes jeitos: Google Forms (as respostas caem numa planilha no Google Drive), Respondi (aplicativo brasileiro de formulários, que baixa as respostas em planilha e também pode mandar tudo para o Google Planilhas) ou pela IA (o aluno manda as respostas numa conversa, em texto, PDF ou print). Aqui você descobre qual é e pede acesso para ler. Fale sem termo técnico e faça uma pergunta por vez, esperando a resposta antes da próxima.

**Pergunta 1.** "Você já tem um Formulário de Cadastro do aluno? Quando um aluno novo fecha com você, onde ele responde o cadastro com os dados dele?
1. Google Forms
2. Respondi
3. Ele me manda as respostas por mensagem (texto, PDF ou print, inclusive quando responde com ajuda de uma IA)
4. Num aplicativo de treino ou de gestão (MFIT, Tecnofit, Trainerize ou outro)
5. Ainda não tenho cadastro"

Resposta 4: siga o **Caminho D** abaixo.

Resposta 5: não pare aqui. Leia `${CLAUDE_SKILL_DIR}/formulario-modelo.md` e siga a seção Como ajudar o personal: mostre os três caminhos (Google Forms, Respondi ou a própria IA montando as perguntas), ajude a escolher e conduza a criação passo a passo, uma etapa por vez, esperando ele dizer "feito" antes da próxima. Com o formulário pronto, volte à Pergunta 1 e siga o caminho da ferramenta que ele escolheu.

### Caminho A. Google Forms (ou Respondi ligado ao Google Planilhas)

As respostas ficam numa planilha no Google Drive. Para ler, a skill precisa de acesso a ela.

1. Veja se nesta conversa existem ferramentas do conector Google Drive (nomes com `Google_Drive`).
2. **Se existirem**, pergunte: "Qual o nome da planilha onde caem as respostas? (No Google Forms, ela costuma terminar com '(respostas)'.)". Ache pelo conector (busca por nome, ou o ID se ele mandar o link). Leia com o download do arquivo pedindo o formato CSV (`exportMimeType: text/csv`), que traz os valores exatos; se não der, use a leitura de conteúdo. Nada fica público. Grave `fonte: conector-drive`.
3. **Se não existirem**, diga: "Tem um jeito mais seguro de eu ler sua planilha, que é ligar o seu Google Drive aqui no Claude. Se aparecer para você: abra claude.ai no navegador, entre em Configurações, depois Conectores, procure Google Drive e clique em Conectar, usando a mesma conta Google da planilha. Depois feche e abra o Claude de novo e diga integrar. Se não aparecer, ou se preferir, seguimos agora pelo link da planilha." Siga pelo link se ele não quiser ou não conseguir ligar.
4. **Link da planilha (funciona sempre).** Antes de pedir, avise com estas palavras:

   > Atenção: com o link aberto, qualquer pessoa que tiver o endereço consegue ver os dados dos seus alunos (CPF, telefone, e-mail). Nunca publique nem repasse esse link.

   Depois guie, uma frase por vez: "Abra a planilha das respostas. Clique no botão Compartilhar, lá em cima à direita. Em Acesso geral, troque para Qualquer pessoa com o link, deixe como Leitor e clique em Copiar link. Cole o link aqui."
   Do link `https://docs.google.com/spreadsheets/d/<ID>/edit#gid=<GID>` tire o ID e o GID (sem gid, use 0) e baixe com Bash, sem salvar em arquivo:

   ```
   curl -sL "https://docs.google.com/spreadsheets/d/<ID>/export?format=csv&gid=<GID>"
   ```

   No Windows (PowerShell), use `curl.exe -sL` no lugar de `curl -sL`, aqui e no link publicado abaixo.

   Se ele já tiver um link publicado em CSV (Arquivo, Compartilhar, Publicar na Web, formato .csv; o endereço termina em `output=csv`), use esse link direto no `curl -sL`. Se a resposta vier em HTML (página de login), a planilha não está compartilhada: peça para refazer o passo do Compartilhar. Não use WebFetch, ele resume o conteúdo e pode alterar dados. Grave `fonte: link-csv` (com ID e GID) ou `fonte: link-csv-publicado` (com o link).

### Caminho B. Respondi

**Pergunta 2.** "No Respondi, as respostas vão para uma planilha do Google ou você baixa a planilha pelo próprio Respondi?"
- Vão para o Google Planilhas: siga o Caminho A com essa planilha.
- Baixa pelo Respondi (ou não sabe): diga "Então vamos pelo arquivo. Abra o seu formulário no Respondi, vá na parte das respostas e use a opção de exportar ou baixar. Se ele perguntar o formato, escolha CSV." Depois: "Salve o arquivo sempre com o mesmo nome, nesta pasta: `<pasta do negócio>/alunos/respostas-alunos.csv`. Me avise quando salvar." Se ele só conseguir Excel (.xlsx), peça para abrir no Excel ou no Google Planilhas e salvar como CSV. Confira com Read que o arquivo existe. Grave `fonte: arquivo-csv`, `origem: respondi` e o caminho.
- Avise: "Nesse caminho, quando entrar aluno novo, baixe o arquivo de novo e salve por cima do antigo, com o mesmo nome."

O mesmo caminho de arquivo serve para a planilha do Google Forms baixada (Arquivo, Fazer download, Valores separados por vírgula) e para lista de alunos exportada de qualquer outro app, desde que venha em CSV.

### Caminho C. Respostas pela IA ou por mensagem

Não há planilha para ligar. Diga: "Combinado. Toda vez que for fazer um contrato, cole aqui o texto com as respostas do aluno, ou mande o print ou o PDF, e eu tiro os dados de lá." Grave `fonte: colar-na-hora` e pule a Etapa 3. Sugira em uma linha a mensagem pronta de `${CLAUDE_SKILL_DIR}/formulario-modelo.md` (seção Sem formulário), para o aluno mandar as respostas já na ordem certa.

### Caminho D. Aplicativo de treino ou de gestão (MFIT e outros)

Os dados do aluno ficam dentro do app. Não ligue o app por conector ou MCP de terceiros nesta skill: além de ler, esses conectores costumam ter ferramentas que alteram ou apagam treinos e alunos, e nem sempre trazem CPF e endereço, que o contrato precisa.

**Pergunta 2.** "Nesse aplicativo, dá para baixar a lista de alunos em planilha (Excel ou CSV)? Costuma ficar na tela de alunos, num botão Exportar ou Baixar."
- Dá: siga o caminho do arquivo do Caminho B (salvar em `<pasta do negócio>/alunos/respostas-alunos.csv`, sempre com o mesmo nome; Excel vira CSV abrindo no Excel ou no Google Planilhas e salvando como CSV). Grave `fonte: arquivo-csv` e `origem: <nome do app>`. Na Etapa 3, confira se a planilha traz CPF, RG e endereço: o que não vier será perguntado na hora de gerar.
- Não dá, ou não sabe: siga o Caminho C. Diga: "Então, quando fechar um aluno, abra a ficha dele no aplicativo, copie os dados ou tire um print da tela e mande aqui. Eu tiro os dados de lá e pergunto o que faltar." Se o app não guarda CPF, RG ou endereço, sugira a mensagem pronta de `${CLAUDE_SKILL_DIR}/formulario-modelo.md` (seção Sem formulário) para o aluno mandar o que falta.

## Etapa 3. Mapear colunas

1. Leia só o cabeçalho e a primeira linha de dados. Veja o separador: CSV baixado no Brasil costuma vir com ponto e vírgula (`;`) em vez de vírgula. Anote no config.
2. **Formulário padrão:** se o cabeçalho tiver as perguntas de `${CLAUDE_SKILL_DIR}/formulario-modelo.md` ("Qual o seu nome completo?", "CPF", "RG", "Qual o seu endereço completo (rua, complemento e número)?", "Qual o seu bairro?", "Qual cidade e estado você mora?", "Qual o seu CEP?", "Qual o seu e-mail?", "Qual o seu WhatsApp com DDD?"), o mapeamento é automático: só mostre e peça o "ok". A coluna de data muda de nome conforme a ferramenta ("Carimbo de data/hora" no Google Forms; no Respondi, a coluna com a data de envio).
3. **Outros títulos:** ache a coluna de cada campo pelo sentido do título: nome completo, CPF, RG, endereço, bairro, cidade/UF (pode estar em uma coluna ou em duas), CEP, e-mail, telefone (ou WhatsApp) e data da resposta. Ignore colunas extras.
4. Mostre o mapeamento assim e peça confirmação:

```
Nome completo  -> "Qual o seu nome completo?"
CPF            -> "CPF"
RG             -> "RG"
Endereço       -> "Qual o seu endereço completo (rua, complemento e número)?"
Bairro         -> "Qual o seu bairro?"
Cidade/UF      -> "Qual cidade e estado você mora?"
CEP            -> "Qual o seu CEP?"
E-mail         -> "Qual o seu e-mail?"
Telefone       -> "Qual o seu WhatsApp com DDD?"
Data resposta  -> "Carimbo de data/hora"
```

   Campo sem coluna: diga qual falta e combine que ele será perguntado na hora de gerar.
5. Teste: mostre o nome e a cidade da primeira linha (só isso, sem CPF) e pergunte "Essa pessoa está na sua planilha?".

## Etapa 4. Salvar a configuração

Grave `config-contrato.md` na mesma pasta do perfil, no formato de `${CLAUDE_SKILL_DIR}/config-contrato.exemplo.md`. Ali vai só o tipo de fonte, nome ou ID da planilha, link ou caminho do arquivo, separador e o mapeamento. Nunca dados de aluno.

Feche com: "Integração pronta. A partir de agora é só dizer: faz o contrato da Maria." (No Caminho C: "Pronto. Quando fechar um aluno, diga faz o contrato da Maria e cole as respostas dela.")

# TERMO DE ADESÃO E CONTRATAÇÃO DE PROGRAMA PERSONALIZADO DE TREINAMENTO ONLINE

Pelo presente Termo de Adesão, de um lado **[NOME DO PROFISSIONAL OU RAZÃO SOCIAL]**, inscrito(a) no **[CPF OU CNPJ DO PROFISSIONAL]**, profissional de Educação Física registrado(a) no **CREF [CREF DO PROFISSIONAL]**, doravante CONTRATADA, e de outro **[NOME COMPLETO DO CLIENTE]**, inscrito(a) no CPF **[CPF DO CLIENTE]**, portador(a) do RG **[RG DO CLIENTE]**, residente em **[ENDEREÇO DO CLIENTE]**, **[BAIRRO DO CLIENTE]**, **[CIDADE/UF DO CLIENTE]**, CEP **[CEP DO CLIENTE]**, e-mail **[E-MAIL DO CLIENTE]** e telefone **[TELEFONE DO CLIENTE]**, doravante CONTRATANTE, ajustam as condições abaixo.

## Cláusula 1. Do objeto

1.1. Prestação de Programa Personalizado de Treinamento Online, doravante Programa Personalizado, com prescrição individual elaborada pela CONTRATADA a partir das informações fornecidas pela CONTRATANTE.

1.2. O serviço inclui:
- avaliação inicial online (questionário de saúde, objetivos e rotina);
- **[NÚMERO DE PLANOS]** planos de treino no período, entregues por **[FORMA DE ENTREGA]**;
- ajustes do plano a cada **[PERIODICIDADE DOS AJUSTES]**, com base no retorno da CONTRATANTE;
- suporte para dúvidas por **[CANAL DE SUPORTE]**, de **[DIAS E HORÁRIOS DE SUPORTE]**, com resposta em até **[PRAZO DE RESPOSTA]**.

1.3. Não estão incluídos atendimento presencial, plano alimentar, diagnóstico ou tratamento de qualquer condição de saúde.

## Cláusula 2. Da duração

2.1. O Programa Personalizado tem duração de **[NÚMERO DE MESES]** meses, com início em **[DATA DE INÍCIO]**, após a confirmação do pagamento.

2.2. O primeiro plano de treino é entregue em até **[PRAZO DO PRIMEIRO PLANO]** dias úteis após o envio da avaliação inicial completa pela CONTRATANTE.

2.3. Ao fim do prazo, o contrato se encerra. A renovação depende de nova contratação.

## Cláusula 3. Do valor e da forma de pagamento

3.1. Valor total: **R$ [VALOR TOTAL] ([VALOR TOTAL POR EXTENSO])**.

3.2. Forma de pagamento: **[FORMA DE PAGAMENTO]**.

3.3. Data do pagamento: **[DATA DO PAGAMENTO]**.

## Cláusula 4. Do direito de arrependimento

4.1. A CONTRATANTE pode desistir em até 7 (sete) dias corridos da contratação, conforme o artigo 49 do Código de Defesa do Consumidor, com devolução integral do valor pago, pela mesma forma de pagamento usada na compra.

## Cláusula 5. Do cancelamento após 7 dias

5.1. Após o prazo do item 4.1, a CONTRATANTE pode cancelar mediante aviso por escrito em **[CANAL DE SUPORTE]**.

5.2. Em caso de cancelamento, a CONTRATANTE paga pelos meses já iniciados e uma multa de **[PERCENTUAL DE MULTA]** sobre o valor dos meses restantes. O saldo, se houver, é devolvido em até 30 dias.

5.3. A não utilização do serviço por decisão da CONTRATANTE não gera direito a abatimento, enquanto o contrato estiver ativo.

## Cláusula 6. Da pausa

6.1. A CONTRATANTE pode pausar o Programa Personalizado uma vez, por até **[DIAS DE PAUSA]** dias, em caso de lesão, cirurgia, gestação ou viagem, mediante aviso prévio. O prazo pausado é acrescido ao fim do contrato.

## Cláusula 7. Da saúde e da segurança

7.1. A CONTRATANTE declara que respondeu com verdade ao questionário de saúde e que informará qualquer mudança no seu estado de saúde, uso de medicamento, dor ou lesão.

7.2. A CONTRATADA recomenda avaliação médica antes do início do Programa Personalizado. Se o questionário apontar risco, o início depende de liberação médica.

7.3. Por se tratar de serviço online, a execução dos exercícios acontece sem supervisão presencial. A CONTRATANTE se compromete a seguir as orientações de execução, respeitar os próprios limites e interromper o treino em caso de dor ou mal-estar, comunicando a CONTRATADA.

7.4. A CONTRATADA não responde por danos decorrentes de informação falsa ou omitida no questionário, ou de execução em desacordo com as orientações.

## Cláusula 8. Das obrigações da CONTRATADA

8.1. Elaborar os planos de forma individual, com base técnica e dentro das atribuições do profissional de Educação Física.

8.2. Cumprir os prazos de entrega e de resposta previstos na Cláusula 1.

## Cláusula 9. Das obrigações da CONTRATANTE

9.1. Fornecer informações verdadeiras e completas, manter o acesso ao canal de entrega e enviar o retorno pedido para os ajustes.

## Cláusula 10. Do uso do material

10.1. Os planos são de uso pessoal e intransferível. É proibido compartilhar, revender ou publicar o material sem autorização por escrito da CONTRATADA.

## Cláusula 11. Dos dados pessoais (LGPD)

11.1. Os dados pessoais e de saúde da CONTRATANTE são usados somente para a prestação deste serviço, guardados com segurança e não são compartilhados com terceiros, conforme a Lei 13.709/2018.

11.2. A CONTRATANTE autoriza de forma específica o tratamento dos seus dados de saúde para a elaboração dos planos. Pode pedir acesso, correção ou exclusão dos dados a qualquer momento por **[CANAL DE SUPORTE]**.

## Cláusula 12. Do uso de imagem (opcional)

[AUTORIZAÇÃO DE IMAGEM]

## Cláusula 13. Das disposições finais

13.1. Este termo passa a valer na confirmação do pagamento e no aceite da CONTRATANTE, que pode ser feito por assinatura eletrônica.

13.2. Fica eleito o foro da comarca de **[CIDADE/UF DO CLIENTE]** para resolver qualquer questão deste termo.

**[CIDADE DO PROFISSIONAL]**, **[DIA]** de **[MÊS]** de **[ANO]**.




______________________________________________
**CONTRATADA**
[NOME DO PROFISSIONAL OU RAZÃO SOCIAL]
CPF ou CNPJ [CPF OU CNPJ DO PROFISSIONAL]
CREF [CREF DO PROFISSIONAL]




______________________________________________
**CONTRATANTE**
[NOME COMPLETO DO CLIENTE]
CPF [CPF DO CLIENTE]
E-mail [E-MAIL DO CLIENTE]

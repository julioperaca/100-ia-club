#!/usr/bin/env bash
# Converte o contrato .html em .pdf com um navegador já instalado (Chrome ou Edge).
# Funciona no Mac (Terminal) e no Windows (Git Bash, que vem com o Claude Code).
# Uso: bash gerar-pdf.sh "/caminho/contrato.html" "/caminho/contrato.pdf"
# Saída: imprime "PDF OK: <caminho>" ou "SEM NAVEGADOR" / "FALHOU".
set -u

HTML="$1"
PDF="$2"

candidatos=(
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  "$HOME/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"
  "/c/Program Files/Google/Chrome/Application/chrome.exe"
  "/c/Program Files (x86)/Google/Chrome/Application/chrome.exe"
  "${LOCALAPPDATA:-/nao-existe}/Google/Chrome/Application/chrome.exe"
  "/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
  "/c/Program Files/Microsoft/Edge/Application/msedge.exe"
)

NAV=""
for c in "${candidatos[@]}"; do
  if [ -f "$c" ]; then NAV="$c"; break; fi
done
if [ -z "$NAV" ]; then echo "SEM NAVEGADOR"; exit 2; fi

# No Windows o navegador precisa de caminho no formato C:\...
ARQ_HTML="$HTML"; ARQ_PDF="$PDF"
if command -v cygpath >/dev/null 2>&1; then
  ARQ_HTML="$(cygpath -m "$HTML")"; ARQ_PDF="$(cygpath -w "$PDF")"
fi
URL="file:///${ARQ_HTML#/}"

rm -f "$PDF"
"$NAV" --headless=new --disable-gpu --no-pdf-header-footer \
  --print-to-pdf="$ARQ_PDF" "$URL" >/dev/null 2>&1

if [ -s "$PDF" ]; then echo "PDF OK: $PDF"; else echo "FALHOU"; exit 1; fi

# Configuração do contrato

Arquivo criado pela skill contrato no Modo Integrar. Fica na mesma pasta do perfil-profissional.md. Não guarda dados de aluno.

- fonte: conector-drive
- origem: google-forms
- planilha_nome: Cadastro de alunos (respostas)
- planilha_id: 1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789
- gid: 0
- link_publicado:
- caminho_csv:
- separador: ,

## Mapeamento de colunas

- nome: Qual o seu nome completo?
- cpf: CPF
- rg: RG
- endereco: Qual o seu endereço completo (rua, complemento e número)?
- bairro: Qual o seu bairro?
- cidade_uf: Qual cidade e estado você mora?
- cep: Qual o seu CEP?
- email: Qual o seu e-mail?
- telefone: Qual o seu WhatsApp com DDD?
- data_resposta: Carimbo de data/hora

Valores possíveis de `fonte`: `conector-drive` (usa planilha_nome e planilha_id), `link-csv` (usa planilha_id e gid), `link-csv-publicado` (usa link_publicado), `arquivo-csv` (usa caminho_csv) ou `colar-na-hora` (sem planilha: o personal cola as respostas a cada contrato). Valores de `origem`: `google-forms`, `respondi` ou `outro`. `separador`: `,` ou `;`.

# Etapa 3. Nome comercial e narrativa de cada pilar

Tempo na conversa: 7 a 8 minutos por pilar.

Leia antes `${CLAUDE_SKILL_DIR}/referencias/narrativa-do-pilar.md` e `${CLAUDE_SKILL_DIR}/referencias/nomes.md`. Faça um pilar inteiro por vez (nome, conceito, inimigo, argumentos, tradução) e grave antes de passar para o próximo.

Abra a etapa assim:

> Agora a parte que mais pesa. Para cada pilar a gente vai escrever três coisas: o conceito (por que ele é importante), o inimigo comum (o que a sua aluna acha que é o certo e você não concorda) e os seus argumentos. É isso que faz ela pensar "faz sentido, eu nunca tinha pensado nisso". Eu vou te dando exemplo e rascunho; você corrige.

## Para cada pilar

### 1. Nome comercial

Explique uma vez só (no primeiro pilar), com o exemplo do iPhone ou da air fryer de `nomes.md`. Depois proponha 3 opções coerentes com a prática que a pessoa contou, cada uma com meia linha de lógica:

> Para o seu pilar de [técnico], três ideias de nome:
> 1. [nome]: [lógica]
> 2. [nome]: [lógica]
> 3. [nome]: [lógica]
> Qual soa mais como você? Pode ser "nenhum, quero outro".

Os 3 nomes seguem o tom de `nomes.md` (científico e comercial, nada lúdico). Sigla de pilar é rara: o nome por extenso é o principal, e a sigla só entra como alternativa se as iniciais ficarem fáceis de falar, nunca em acróstico.

Se ela escolher, marque como preferido. Se disser "não sei" ou "escolhe você", recomende uma, coloque em primeiro e marque como "recomendado pela skill" (na página, `preferido: false`): a escolha fica para o encontro.

Confira que nenhum nome de pilar é quase igual a outro pilar ou ao nome que o método pode ter depois (ex.: pilar "Retorno Progressivo" e método "Protocolo de Retorno Progressivo"). Se for, troque a opção.

### 2. Conceito

> Por que o [nome comercial] é determinante para [Ponto B]? Me explica como se eu fosse a sua aluna, que não entende nada de treino.

- Se vier o que o pilar gera ("queima gordura", "fortalece"), peça o segundo porquê: "E por que ele faz isso? O que acontece no corpo?"
- Se vier um motivo ou uma consequência sem o porquê do corpo ("preciso saber o que dói", "a dor volta se parar"), faça a mesma pergunta: "E o que acontece no corpo para isso ser assim?"
- Se travar ou disser "não sei", escreva você um rascunho de 2 a 3 frases, com fisiologia correta e uma analogia simples, e pergunte: "É isso que você acredita? O que você mudaria?"
- Se num pilar anterior a pessoa já disse "não sei" ao segundo porquê, nos próximos não repita a cobrança: ofereça o rascunho junto com a pergunta ("Eu explicaria assim: [rascunho]. É isso que você acredita?").
- Rascunho aprovado depois de um "não sei": grave com "(sugestão da skill aprovada)" e siga.
- Regra do segundo "não sei": se depois do rascunho a pessoa ainda não souber dizer se concorda, não insista. Grave o rascunho com "(sugestão da skill, a fechar no encontro)" e siga. Se for a base do pilar, vira pergunta para o encontro.

### 3. Inimigo comum

> Quando a sua aluna pensa em [pilar], o que ela costuma fazer, ou o que dizem pra ela, que você não acha o melhor caminho?

Comece pelo "o que já tentou" do `aluno-ideal.md` ("Você me contou que ela já tentou [X]. Isso entra aqui?"). Se travar, ofereça 2 ou 3 do banco da referência. Um inimigo principal por pilar; um segundo, se vier fácil.

Lembre a pessoa, se ela pesar a mão: "Não é dizer que não funciona. É mostrar por que não é o melhor caminho para ela."

**Confira se o inimigo não ataca o próprio produto ou a própria prática da pessoa.** Compare com o `negocio.md` (duração, formato, o que está incluído) e com o "o que eu faço na prática". Exemplos de choque: inimigo "trocar a ficha todo mês" quando o programa dela ajusta a cada 4 semanas; "treino pronto de aplicativo" quando ela entrega o treino no app; "8 semanas e para" quando o programa dele tem 8 semanas. Vale também para a prática: se ela contou que às vezes cai no próprio inimigo (ex.: "às vezes só troco os exercícios"), o texto não acusa ninguém; o pilar descreve o padrão que o método garante, e vai para o encontro a pergunta "na prática, dá para manter isso sempre?". Se chocar, mire no jeito e não na coisa: "trocar a ficha sem lógica, só mudando exercício" (e ela troca com lógica); "treino igual para todo mundo" (e o dela é montado para a pessoa). Se não der para resolver, leve para o encontro.

### 4. Argumentos

> Por que esse caminho não é o melhor? E por que o seu jeito resolve?

Cobre o segundo porquê como o Peraça cobra: se a resposta for "porque não funciona" ou "porque é o certo", diga "está raso, me explica mais". O argumento completo tem: o que acontece no corpo, o que isso muda para a aluna e uma vantagem prática (menos tempo, menos dor, mais adesão). Termine com a frase no formato "Por isso a gente usa o [nome comercial], que [porquês]".

O argumento explica o porquê, nunca o como. Nada de protocolo, séries, segundos de esforço e descanso: isso é entregue dentro do programa. E o pilar tem que soar simples de fazer, não como mais uma tarefa difícil: se o texto deixar a aluna com medo do esforço ("intensidade no talo", "até não aguentar"), troque pela versão que ela aceita ("intensidade certa para você").

Se a pessoa não souber, rascunhe e pergunte se ela concorda (vale a regra do segundo "não sei"). Nunca invente estudo, número ou mecanismo, nem coloque no argumento algo que ela não disse que faz (ex.: progressão de carga, se ela só falou de repetição e descanso). Se um argumento depender de algo que você não tem certeza, deixe mais simples e anote a dúvida para o encontro.

### 5. Tradução

Você monta e mostra junto com o pilar (passo 6): de 2 a 4 termos técnicos ligados ao pilar, cada um com "como falar para a aluna". A ideia é a mesma da fala do Peraça: o personal sabe o termo ("via lipolítica"), mas fala com a aluna na tradução. Por isso o conceito e os argumentos ficam em linguagem simples, e o termo técnico aparece na tabela. Use o banco da referência quando servir; senão, crie na voz da pessoa.

### 6. Mostrar o pilar inteiro e gravar

Mostre o pilar montado, curto:

> **Pilar [N]: [nome comercial]** ([técnico])
> Conceito: ...
> Inimigo comum: ...
> Argumentos: ...
> Tradução: [termo]: [como falar]; ...
> Está com a sua cara? O que você mudaria?

Ajuste uma vez se ela pedir. Se ela pedir para tirar "palavra que eu não falaria", olhe nesta ordem: o "O que eu nunca digo" do `voz.md`, termo técnico que escapou da tabela para o texto e palavra que assusta o público (esforço extremo, dieta, restrição). Grave com Edit no bloco do pilar em `metodo.md`, no formato de `${CLAUDE_SKILL_DIR}/modelos/metodo-esboco.md`. Fonte de cada linha:
- o que a pessoa disse: "(conversa, dd/mm/aaaa)";
- o que a skill rascunhou e ela aprovou: "(sugestão da skill aprovada, dd/mm/aaaa)";
- o que a skill rascunhou e ela não confirmou: "(sugestão da skill, a fechar no encontro)".

Atualize "O que falta" (ex.: "narrativa do pilar 3, nome do método, página do esboço") e diga em uma linha: "Pilar 1 anotado. Vamos para o pilar 2."

Nos textos desta etapa, troque "a aluna" e "ela" por "o aluno" e "ele" quando o público for masculino ou misto.

Ao gravar, junte os inimigos comuns de todos os pilares na seção "Caminhos comuns (inimigos comuns)", uma linha por inimigo com o pilar entre parênteses. As skills de páginas e copy leem dali.

## Se a pessoa precisar parar

Grave o que já tem, deixe `Status: em andamento` e o "O que falta" com o pilar onde parou. Na próxima vez a skill continua dali.

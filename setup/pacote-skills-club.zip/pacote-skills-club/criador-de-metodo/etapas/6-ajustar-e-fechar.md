# Etapa 6. Ajustar e fechar depois do encontro

## Modo Ajustar ("ajusta: ...")

1. Leia `<pasta>/metodo.md` inteiro.
2. Faça só o ajuste pedido (trocar nome de pilar, reescrever inimigo comum, mudar argumento, juntar pilares, trocar o nome favorito). Mudou pilar ou argumento? Passe de novo pelas regras de `${CLAUDE_SKILL_DIR}/referencias/narrativa-do-pilar.md` e pelo limite ético da SKILL.md.
3. Grave com Edit. O valor antigo vira linha no "Histórico de mudanças": "dd/mm/aaaa: pilar 2 de Cardio Curto para Condicionamento Específico (pediu, conversa)".
4. Atualize a página: copie `metodo.html` para `metodo-anterior.html`, troque o bloco DADOS e abra de novo (etapa 5, Passos 3 e 4).
5. Feche com uma linha do que mudou. Se a mudança abriu dúvida nova, acrescente em "Para levar ao encontro de quinta do Club".

## Modo Fechar ("fechei: ...")

Usado depois do encontro, quando o personal conta o que o Peraça e ele decidiram.

1. Leia `<pasta>/metodo.md` inteiro.
2. Aplique cada decisão contada (nome final dos pilares, nome do método, argumentos reescritos, pilar trocado). Fonte: "encontro de quinta do Club, dd/mm/aaaa".
3. Em cada pilar, deixe só o nome escolhido como nome comercial; as outras opções ficam em "Nomes considerados".
4. Em "Para levar ao encontro de quinta do Club", marque cada pergunta como "resolvida: [decisão]" ou "em aberto". Não apague as perguntas.
5. Cabeçalho: se todas as perguntas foram resolvidas, `Status: completo` e `O que falta: nada`. Se não, `Status: em andamento (esboço para o encontro de quinta do Club)` e "O que falta" com o que ficou em aberto.
6. Histórico: "dd/mm/aaaa: fechado no encontro de quinta do Club" mais uma linha por valor que mudou.
7. Atualize a página (copie a anterior para `metodo-anterior.html` antes). Com `Status: completo`, troque o selo do topo: no bloco DADOS, `"fechado": true`.
8. Feche com 3 linhas: os pilares com o nome final, o nome do método e o próximo passo: "Agora as skills de conteúdo, copy e oferta já usam o seu método. Um bom começo: pedir na skill de conteúdo um post que conta um pedaço de um pilar."

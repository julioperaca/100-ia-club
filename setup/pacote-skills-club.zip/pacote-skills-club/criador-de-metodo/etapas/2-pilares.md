# Etapa 2. Escolher os pilares (até 3)

Tempo na conversa: 8 a 10 minutos.

Leia antes `${CLAUDE_SKILL_DIR}/referencias/pilares-padrao.md`. Esta etapa segue o jeito do Peraça: primeiro a pessoa diz o que faz, depois a skill compara com o padrão (ou com a adaptação do nicho), provoca com o teste do pilar e propõe. Uma pergunta por vez, sempre.

Use o gênero do `aluno-ideal.md` em tudo: "a aluna" se o público é feminino, "o aluno" se é masculino ou misto.

## Passo 1. A pergunta de abertura

> Imagina que chegou [aluna ideal] querendo [Ponto B]. Você vai para casa montar o planejamento. O que não pode faltar de jeito nenhum? Pode falar do seu jeito, a gente organiza depois.

Se a pessoa travar ou disser "não sei", dê o exemplo do Peraça antes de insistir:

> Um exemplo: no método do Peraça, ele não acredita que o personal cresce no digital sem um produto bem comunicado, sem um Instagram trazendo gente nova todo dia e sem estratégia de venda. Tirou um dos três, não dá. Esses são os pilares dele.

## Passo 2. Comparar com o ponto de partida

Escolha o ponto de partida:
- **Nicho de dor, esporte, gestante, idoso ou hipertrofia** (pelo brain ou pela resposta): a proposta da tabela "Adaptação por nicho".
- **Qualquer outro caso**: os 3 pilares padrão (resistido, cardio, progressão de estímulos).

Mostre sempre, mesmo que a pessoa tenha respondido bem, ligando ao que ela disse (sem pedir confirmação aqui; a confirmação é uma só, no passo 5):

> Para a maioria dos personais, o método tem 3 pilares: treino resistido, cardio e progressão de estímulos. Do que você falou, [itens dela] batem com [pilares]. Agora vou te fazer umas perguntas rápidas para ver o que fica.

Em nicho, diga o padrão em uma linha e a adaptação logo depois, com a linha do porquê da tabela: "No lugar de resistido, cardio e estímulos, para o seu público eu adaptaria assim: [3 pilares], porque [porquê]." Em nicho de dor, antes de mostrar, faça uma pergunta: "A maioria chega com exame do médico ou sem saber o que tem?". Depois, outra: "Como você descobre o que está doendo hoje?". A resposta vira o pilar de avaliação.

## Passo 3. O que fica e o que sai

- **Pilares do ponto de partida** (os 3 padrão, ou os do nicho): para cada um, a pergunta do Peraça: "Você usa isso sempre no planejamento ou não usa?". Se a resposta da pergunta de prática (passo 4) já mostra que usa, não pergunte de novo. Usa sempre: fica. Não usa: sai.
- **Pilar padrão que o nicho tirou** (ex.: cardio no nicho de dor): pergunte "Você usa cardio?". Se usa sempre e é determinante para o público dele, pode voltar no lugar de outro ou dentro de outro pilar; senão, vai para "Fora dos pilares".
- **Pilar padrão que a pessoa diz que "chega sem, só demora"** (ex.: cardio): se ela usa sempre no planejamento, fica, porque no método dela ele faz parte do caminho. Anote para o encontro: "[pilar] é pilar ou entra dentro do treino?".
- **Candidato fora do ponto de partida** (alimentação, mentalidade, core, alongamento solto, constância): passe pelo teste da cliente chata, um por vez:

> Se ela disser "eu não vou fazer [candidato]", do seu jeito ela chega em [Ponto B]?

Não chega: pode ser pilar, desde que o personal controle e entregue. Chega: explique em uma linha por que não vira pilar e onde entra (tabela "O que geralmente não vira pilar").

## Passo 4. Perguntas de prática (para nomear e argumentar depois)

Faça só as que se aplicam, uma por vez:

1. **Resistido:** "No treino de força, qual é a sua base? Ex.: mais exercícios multiarticulares, combinados, isolados para quem tem mais tempo."
2. **Cardio:** "Como você faz o cardio: curto, intervalado, longo, no fim do treino, misturado com a musculação?"
3. **Estímulos ou fases:** "De quanto em quanto tempo você muda o treino, e o que muda: carga, repetições, intervalo, o tipo de treino?" (em nicho de dor: "Como você avança: o que faz primeiro, o que vem depois?")

Se o cardio entra sempre ou quase sempre na mesma sessão do resistido (no meio, no fim ou misturado), ofereça juntar os dois num pilar só (ver "Juntar ou trocar pilares"). A pessoa decide. Se recusar, seguem separados.

## Passo 5. Propor e gravar

Mostre a proposta uma vez só:

> Seus pilares (esboço):
> 1. [nome técnico]: [uma linha do que você faz na prática]
> 2. ...
> 3. ...
> Ficou de fora como pilar: [itens], porque [motivo em uma linha]. Eles continuam no seu trabalho.
> Fecha assim para o esboço?

Aceite ajuste. Dúvida real (juntar ou separar, nicho incomum, pilar padrão que ela acha que "chega sem") não trava a conversa: escolha a opção mais provável e anote para as perguntas do encontro.

Com Edit em `metodo.md`, na seção "Etapas ou pilares", um bloco por pilar, no formato de `${CLAUDE_SKILL_DIR}/modelos/metodo-esboco.md`:

```
### Pilar 1: [nome técnico por enquanto]
- nome técnico: ...
- o que eu faço na prática: ... (conversa, dd/mm/aaaa)
```

O que ficou de fora vai para "Fora dos pilares", com o motivo. Atualize o cabeçalho: `O que falta: narrativa dos pilares, nome do método, página do esboço`. Uma linha na conversa: "Anotei os seus [N] pilares no metodo.md."

# Etapa 5. Salvar, abrir a página e listar as perguntas do encontro

Tempo na conversa: 5 minutos.

## Passo 1. Perguntas para o encontro

Monte de 3 a 5 perguntas ou decisões para o personal levar ao Peraça. Saem do que ficou em aberto na conversa, nesta ordem de prioridade:
1. nome comercial de cada pilar que não teve escolha firme;
2. pilar com dúvida (juntar ou separar, adaptação de nicho, algo que ficou fora);
3. argumento que ficou fraco ou que depende de fisiologia que a skill não quis afirmar;
4. o nome do método entre as 3 opções, e nome de pilar escolhido que não se entende na hora (jargão como "multiarticular");
5. qualquer ponto em que a pessoa disse "não sei" e aceitou sugestão da skill (inclusive mecanismo e fases sugeridos).

Se passar de 5, junte perguntas do mesmo pilar numa linha só e deixe de fora as menores.

Cada pergunta numa linha, concreta: "O inimigo comum do pilar 2 (uma hora de esteira) está forte ou fica melhor 'cardio antes da musculação'?". Nada genérico como "o método está bom?".

## Passo 2. Completar o metodo.md

Com Edit, siga `${CLAUDE_SKILL_DIR}/modelos/metodo-esboco.md`:
1. Cabeçalho: `Última atualização` (hoje), `Status: em andamento (esboço para o encontro de quinta do Club)`, `O que falta: fechar no encontro de quinta do Club (ver "Para levar ao encontro")`.
2. As 7 seções do modelo do brain continuam na ordem e com os mesmos títulos: Nome do método, Promessa, Etapas ou pilares, Como funciona o acompanhamento, Prazos, O que o aluno recebe, Pistas encontradas nos seus arquivos.
3. "Como funciona o acompanhamento", "Prazos" e "O que o aluno recebe": copie do `negocio.md` com fonte. Se não houver, escreva "a confirmar" e não pergunte agora (não é foco desta skill). Em "Pistas encontradas nos seus arquivos", mantenha o que a skill brain escreveu; se não há nada, deixe o texto do modelo como está.
4. Depois delas, nesta ordem: Conceito do método, Fases (opcional), Mecanismo (opcional), Caminhos comuns (inimigos comuns), Ponto A e Ponto B (com "O que o método não promete"), O que diferencia meu jeito, Fora dos pilares, Para levar ao encontro de quinta do Club, Nomes considerados, Histórico de mudanças.
5. "Histórico de mudanças": "dd/mm/aaaa: esboço criado (skill criador-de-metodo)." mais uma linha para cada valor que mudou durante a conversa.

## Passo 3. Montar a página

1. Leia `${CLAUDE_SKILL_DIR}/modelos/metodo.html`.
2. Se `<pasta>/metodo.html` existe, copie antes para `<pasta>/metodo-anterior.html`.
3. Grave `<pasta>/metodo.html` igual ao modelo, trocando **só** o bloco entre `/* DADOS INICIO` e `/* DADOS FIM */`.

Campos do bloco `DADOS`:

| Campo | O que vai |
|---|---|
| `nome_publico`, `instagram` | do `perfil-profissional.md` (instagram com @; vazio se não tiver) |
| `data` | hoje, dd/mm/aaaa |
| `metodo_nomes` | as 3 opções de nome do método; a favorita primeiro |
| `metodo_sigla` | a sigla do nome favorito (ex.: "PRP"), só se foi sugerida; vazio (`""`) se não há |
| `conceito` | o texto de "Conceito do método" |
| `fechado` | false no esboço; true só no Modo Fechar com tudo resolvido |
| `chama` | como o público é chamado na página: "a aluna" (público feminino) ou "o aluno" (masculino ou misto), pelo `aluno-ideal.md` |
| `aluna` e `ponto_b` | uma linha cada (quem é o público e onde quer chegar); `ponto_b` sem promessa que o método não garante ("sem dor" vira "com menos dor") |
| `pilares` | um objeto por pilar, na ordem: `tecnico`, `nomes` (3 opções, a preferida ou a recomendada primeiro), `preferido` (true só se a pessoa escolheu; false se a skill recomendou), `sigla` (opcional, só se o pilar tem sigla; senão `""`), `pratica` (o que eu faço na prática, uma linha), `conceito`, `inimigo`, `argumentos`, `traducao` (lista de `[termo, como falar]`). Os textos iguais aos do metodo.md |
| `fases` | lista de `[nome, porquê]`; lista vazia se não há fases |
| `mecanismo` | `[nome, explicação]`; vazio (`[]`) se não há |
| `fora` | itens de "Fora dos pilares", uma linha cada |
| `perguntas` | as 3 a 5 perguntas do Passo 1 |
| `tokens` | ver abaixo |

Tokens:
- Se `<pasta>/identidade-visual.md` tem `Status: completo` (ou `em andamento`) no cabeçalho e a seção `## Tokens (para as outras skills)` com o bloco `json`: copie `cores` e `fontes` exatamente como estão. Diga: "Usei as suas cores do design system."
- Se o arquivo não existe, está com `Status: vazio`, tem marcador entre colchetes no cabeçalho (ex.: `[dd/mm/aaaa]`) ou diz que os valores são só exemplo: deixe os valores neutros do modelo e diga: "Usei um visual neutro. Quando você rodar /design-system, a página sai com as suas cores."

Confira antes de abrir: JSON válido (aspas duplas, sem vírgula sobrando), os pilares iguais aos do metodo.md e na mesma ordem, nenhum travessão e nenhum emoji (use a ferramenta Grep no .md e no .html com o padrão `\x{2014}|\x{2013}`: zero resultados).

## Passo 4. Abrir

Monte o comando conforme o sistema da pessoa e rode:
- Mac: `open "<pasta>/metodo.html"`
- Windows (PowerShell): `Start-Process "<pasta>\metodo.html"`
- Linux: `xdg-open "<pasta>/metodo.html"`

Se não abrir: "Abre a sua pasta brain e dá dois cliques em metodo.html."

## Passo 5. Fechamento (na conversa)

> Pronto: o esboço do seu método está na sua pasta brain, para levar ao encontro de quinta do Club.
> 1. Pilares: [nome 1], [nome 2], [nome 3].
> 2. Nome do método (favorito): [nome] ([sigla], se houver).
> 3. Página: metodo.html (abre no navegador; dá para imprimir).
>
> Para levar ao encontro:
> 1. [pergunta]
> 2. ...
>
> Antes do encontro, releia a narrativa de cada pilar em voz alta. Onde você tropeçar, é ali que falta argumento.
> Depois do encontro: "/criador-de-metodo fechei: [o que ficou decidido]" e eu atualizo tudo.

Não diga que o método está pronto ou fechado.

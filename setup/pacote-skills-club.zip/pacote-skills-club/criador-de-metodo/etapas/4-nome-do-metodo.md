# Etapa 4. Conceito geral e nome do método

Tempo na conversa: 7 a 10 minutos.

Leia antes `${CLAUDE_SKILL_DIR}/referencias/nomes.md`, seções "Nome do método" e "Método não é programa".

## Passo 1. A ideia central

Com os pilares prontos, escreva você a ideia central do método em 2 ou 3 frases: o que o método faz diferente do padrão do mercado, amarrando os pilares. É a "premissa que foge do padrão" que vira o diferencial. Formato:

> Para [aluna ideal] chegar em [Ponto B], o caminho comum é [inimigo comum principal]. Aqui, [o que os pilares fazem juntos, em linguagem dela].

Não use o nome do método nesta frase (ele ainda não existe). Mostre e pergunte uma vez: "É isso que você defende? Mudaria alguma palavra?"

Ajuste e grave em "Conceito do método" e, em uma linha, em "O que diferencia meu jeito" (fonte: "conversa" ou "sugestão da skill aprovada").

## Passo 2. Fases e mecanismo (opcionais, 1 pergunta cada)

**Fases.** Se um dos pilares já é uma progressão em fases (comum em nicho de dor, esporte, gestante e idoso), não pergunte: as fases já estão nesse pilar. Em "Fases (opcional)" escreva só "as fases estão no pilar [N]" e deixe `fases` vazio na página. Nos outros casos, pergunte: "O seu trabalho tem fases? Ex.: primeiro uma fase de resultado rápido, depois uma de destravar quando o corpo se acostuma, depois uma de refinar ou manter." Se tiver, anote de 2 a 4 fases, cada uma com nome simples e uma linha do porquê, ligada ao momento da aluna (o Peraça explica os pilares primeiro e depois as fases; as pessoas gostam de passar de fase). Se não tiver ou não souber, pule: não é obrigatório. Fase não é pilar (ver `pilares-padrao.md`).

**Mecanismo.** Pergunte: "Quando os seus pilares funcionam juntos, o que acontece no corpo que faz dar certo dessa vez?" O mecanismo é o que os pilares produzem juntos, não o conceito de um pilar só. Se a ideia da pessoa repete o conceito de um pilar (ex.: "músculo forte segura o joelho" quando esse já é o conceito do pilar 2), diga isso em uma linha e pule: um método sem mecanismo está certo. Se a pessoa tiver uma ideia que passa nesse teste, ajude a dar nome e uma explicação de 2 frases, seguindo "Mecanismo único" em `nomes.md`. Se não tiver ("não sei"), o padrão é pular e escrever "não definido no esboço": mecanismo é opcional e um mecanismo fraco atrapalha mais que ajuda. Só ofereça uma opção se ela for fisiologia real que os pilares produzem juntos e que o público ainda não conhece (no emagrecimento, o exemplo do Peraça é a "ativação do sistema lipídico": o corpo passar a usar mais a gordura como combustível, como o carro flex que você manda abastecer com o combustível que quer). Mecanismo que é só a soma dos pilares com outro nome ("reativação muscular") não serve.

Grave em "Fases (opcional)" e "Mecanismo (opcional)", com fonte. Se pulou, escreva "não definido no esboço".

## Passo 3. Três nomes para o método

Antes de propor, pergunte uma vez: "Você já pensou em algum nome para o seu método?". Se a pessoa tiver um (ou se houver um nas Pistas do brain), ele entra como uma das 3 opções, e você diz com franqueza, em uma linha, se ele soa como nome de programa ou lúdico demais.

Proponha 3 nomes (2 se o da pessoa já ocupa uma vaga), cada um com uma linha de lógica, seguindo as regras de `nomes.md` (Protocolo, Sistema, Método ou Tríade; científico e comercial; nada lúdico; nada com o nome da pessoa; "tríade" só com 3 pilares; não repetir o nome de um pilar; sigla não é padrão: no máximo uma das 3 opções oferece sigla como alternativa, só das iniciais e só se ficar fácil de falar, nunca acróstico):

> Três ideias de nome para o método:
> 1. [nome] (ou só [sigla], se houver): [lógica]
> 2. [nome]: [lógica]
> 3. [nome]: [lógica]
> Qual você levaria para o encontro como favorito?

Grave: o favorito em "Nome do método" com "(favorito do personal, a fechar no encontro)" e as 3 opções em "Nomes considerados". Se o favorito tem sigla oferecida como alternativa, ela vai numa linha logo abaixo: "Sigla: PRP (alternativa sugerida pela skill, a fechar no encontro)".

## Passo 4. Promessa (rascunho)

Se `metodo.md` ainda não tem promessa, monte uma frase a partir do destino aprovado na etapa 1 (o Ponto B em "Ponto A e Ponto B" do metodo.md; se não mudou, o do `aluno-ideal.md`), com o nome do programa do `negocio.md` se houver:

> Eu ajudo [aluna ideal] a [Ponto B], com o [nome do método].

Sem prazo inventado (só se estiver no negocio.md ou nos cases) e sem garantia. Em nicho de dor, nada de "acabar com a dor" ou "sem dor": use "com mais segurança", "com menos dor", "voltar a [atividade]". Se o nome do programa no `negocio.md` já promete o fim da dor (ex.: "Sem Dor", "Dor Zero"), não mexa nele: leve para as perguntas do encontro se o nome promete mais do que o método pode garantir. Mostre e pergunte se está bom; grave em "Promessa" com fonte. Esta frase é rascunho: o encontro e a skill de oferta refinam depois.

Atualize "O que falta": "página do esboço".

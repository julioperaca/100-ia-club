# Etapa 1. Ler o brain e contar o que já sabe

Tempo na conversa: 3 minutos.

## Passo 1. Ler, sem mostrar

Leia, nesta ordem: `aluno-ideal.md`, `negocio.md`, `voz.md`, `metodo.md`, `cases.md` (só para calibrar). Anote para você:

- **Aluna ideal:** quem é (gênero, idade, rotina) e o nicho (emagrecimento, dor, esporte, gestante, idoso, hipertrofia...).
- **Ponto B:** o resultado que ela quer, nas palavras dela.
- **O que ela já tentou:** a primeira lista de inimigos comuns.
- **O que o personal entrega:** o "o que está incluído" e a duração de cada produto.
- **Pistas de método:** o que a skill brain anotou em "Pistas encontradas nos seus arquivos" (fases, passo a passo, nome que ele já usa).
- **Voz:** 2 ou 3 expressões dele e como chama a aluna.

O que estiver "a confirmar" não é fato. Não use como verdade.

## Passo 2. Contar em 3 linhas e abrir a conversa

Mostre só isto (adapte ao que achou):

> Li a sua pasta brain. O que eu já sei:
> 1. Você atende [aluna ideal em poucas palavras] que quer [Ponto B].
> 2. Ela já tentou [2 coisas do "o que já tentou"].
> 3. [Uma pista de método, se houver; senão: "Ainda não tem nada do seu método anotado. Vamos montar agora."]
>
> Como funciona aqui: em uns 50 minutos a gente monta o esboço do seu método, pilar por pilar. Não precisa sair perfeito. Você leva esse esboço para o encontro de quinta do Club e fecha com o Peraça lá.

Se a aluna ideal ou o Ponto B estiverem vazios no brain, pergunte só isso antes de seguir, uma coisa por vez:
1. "Quem é a pessoa que você mais quer atender? Ex.: mulher de 40 a 55 anos que quer emagrecer e não engordar de novo."
2. "Qual o resultado que ela quer, do jeito que ela fala? Ex.: voltar a usar a calça jeans de antes."

Confira o destino. O método começa pelo destino: para onde o personal leva a pessoa. Ele precisa ser muito desejado pelo público (não o que o personal gosta de fazer) e específico ("emagrecer e não engordar de novo depois dos 40" é melhor que "emagrecimento e definição"; "uma versão melhor de você" não serve). Se o Ponto B do brain estiver genérico, proponha em uma linha uma versão mais específica, com as palavras do público, e pergunte uma vez se é isso. Não trave a conversa: se ficar em dúvida, siga com o que existe e leve para o encontro. Se o Ponto B tiver promessa que o método não pode garantir ("sem dor", "nunca mais", número de quilos), ele fica como está em "Ponto A e Ponto B" (é a fala do público), mas na promessa e na página use a versão possível ("com menos dor", "com mais segurança").

Grave as respostas (e o destino mais específico, se a pessoa aprovou) só no metodo.md, seção "Ponto A e Ponto B", com fonte "conversa, dd/mm/aaaa". Não mexa no `aluno-ideal.md`; no fim, sugira rodar "/brain atualiza" com isso.

## Passo 3. Cabeçalho

Com Edit em `<pasta>/metodo.md`: `Última atualização` (hoje), `Status: em andamento`, `O que falta: pilares, narrativa dos pilares, nome do método, página do esboço`.

# Narrativa do pilar

Cada pilar tem a mesma narrativa, sempre nesta ordem:

1. **Conceito**: por que esse pilar é determinante para o resultado que a aluna quer. Com um pouco de fisiologia, explicada para leiga.
2. **Inimigo comum**: o caminho que a aluna acredita (ou que o mercado vende) e com o qual o personal não concorda que seja o melhor. Não é dizer que não funciona: é mostrar por que não é o melhor para ela.
3. **Argumentos**: por que o caminho do personal resolve. Aqui entra o nome comercial do pilar ("por isso a gente usa o [nome]") e o "A, B, C e D" do porquê.

Por fim, a **tradução**: cada termo técnico usado ao lado de como falar para a aluna.

A meta: a aluna ler e pensar "faz sentido, eu nunca tinha pensado nisso". Quanto menos autoridade o personal tem no digital, mais argumento ele precisa.

## O modelo de referência: treinamento híbrido

Exemplo do Peraça para um pilar que junta resistido e cardio na mesma sessão. É o padrão de qualidade da narrativa. Não copie o texto para o personal: use como medida.

**Nome técnico:** treinamento resistido com cardiorrespiratório na mesma sessão.
**Nome comercial:** Treinamento Híbrido.

**Conceito:** o treinamento resistido junto com a parte aeróbia é determinante para o desenvolvimento muscular e para aumentar o gasto calórico, e também para o corpo usar mais gordura como fonte de energia.

**Inimigo comum:** o problema é que as pessoas acreditam que precisam fazer as duas coisas separadas, com volume alto. Desse jeito a queima de gordura fica abaixo do que poderia, porque a intensidade acaba baixa, e ainda pode haver interferência entre os dois sistemas.

**Argumentos:** por isso o ideal é trabalhar o resistido e o cardiorrespiratório de forma conjunta, na mesma sessão. É o que a gente faz no Treinamento Híbrido, que é a melhor forma para A, B, C e D (o personal completa com os porquês dele: menos tempo de treino, intensidade mantida, mais adesão, e assim por diante).

**Tradução:**

| Termo técnico | Como falar para a aluna |
|---|---|
| usar gordura como fonte de energia, via lipolítica | fazer o corpo buscar a gordura guardada para usar como combustível |
| gasto calórico | a energia que o seu corpo gasta no dia |
| interferência entre os sistemas | um treino atrapalhando o outro quando são feitos do jeito errado |
| intensidade | o quanto o treino exige de você naquele momento |

## Como a skill ajuda em cada parte

**Conceito.** Pergunte: "Por que [pilar] é determinante para [Ponto B]? Me explica como se eu fosse leiga." Se a pessoa responder o que o pilar gera ("queima gordura"), peça o segundo porquê: "e por que ele queima gordura?". Se travar, ofereça um rascunho com fisiologia correta e uma analogia, e peça para ela ajustar.

Exemplo de analogia que o Peraça usa no cardio: as mitocôndrias são como ferramentas dentro das células que pegam a gordura e queimam como combustível; o cardio bem feito aumenta o número e melhora o funcionamento dessas ferramentas.

**Inimigo comum.** Pergunte: "Quando a sua aluna pensa em [pilar], o que ela costuma fazer, ou o que dizem pra ela, que você não acha o melhor caminho?" Primeiro olhe o "o que já tentou" do `aluno-ideal.md`. Se ela travar, ofereça 2 ou 3 do banco abaixo.

**Argumentos.** Pergunte: "Por que esse caminho não é o melhor? E por que o seu jeito resolve?" Se vier raso ("porque não funciona"), cobre como o Peraça cobra: "está raso, me explica mais". O argumento bom tem: o que acontece no corpo, o que isso muda para a aluna e uma vantagem prática (menos tempo, menos dor, mais adesão).

## Banco de inimigos comuns (só para destravar)

| Pilar | Inimigos comuns que aparecem nos encontros |
|---|---|
| Treinamento resistido | treino padrão de academia (A/B, superior e inferior) que não respeita o objetivo nem a fase da aluna; treino de musculação comum sem transferência para o esporte; pular a base e ir direto no específico (pliometria, potência) |
| Cardio | uma hora de esteira em baixa intensidade; cardio antes do treino de força; fazer só cardio ou só musculação; correr aleatório no fim do treino sem ligação com o objetivo |
| Resistido e cardio juntos | achar que tem que fazer separado e com volume alto |
| Progressão de estímulos | trocar a ficha todo mês achando que trocou o estímulo: troca o exercício, mas o corpo é estimulado do mesmo jeito; troca sem progressão lógica |
| Avaliação da dor | chegar com dor e o primeiro passo ser limitar movimento ou tirar exercícios sem saber a causa |
| Exercícios específicos para dor | achar que basta limitar o movimento ou só fazer reforço muscular |

## Banco de traduções (só para destravar)

| Termo técnico | Como falar para a aluna |
|---|---|
| mitocôndrias | ferramentas dentro das células que pegam a gordura e queimam como combustível |
| capacidade cardiorrespiratória, VO2 | o seu fôlego; o quanto de oxigênio o corpo consegue levar para os músculos |
| adaptação ao estímulo | o corpo se acostuma: a caminhada que cansava na primeira semana fica fácil depois |
| progressão de carga | aumentar o desafio aos poucos, no momento certo |
| periodização, estímulos ondulatórios | mudar o tipo de treino de um jeito planejado, para o corpo não se acostumar |
| multiarticular | exercício que trabalha várias partes do corpo ao mesmo tempo, como o agachamento |
| transferência para o esporte | o reforço que aparece na hora de correr, saltar, mudar de direção |
| estabilidade articular | o músculo segurando a articulação no lugar, para ela doer menos |
| condropatia, sobrecarga articular | desgaste ou irritação na cartilagem; peso demais em cima da articulação |

## O que a narrativa nunca faz

- **Não explica o como.** Explica o que é, por que funciona e o que vai acontecer. Protocolo, séries, tempos de esforço e descanso ficam dentro do programa. Na venda, o como deixa tudo complexo e a pessoa desiste.
- **Não complica.** Criar o método não pode deixar o caminho com cara de difícil. O pilar soa como algo simples de seguir (como montar o prato em vez de "fazer dieta").
- **Não vende o que o público odeia ou acha que já faz.** Dieta, uma hora de esteira, "intensidade até morrer": se o pilar envolve isso, ele ganha outro nome e outra explicação.
- **Não fica no primeiro porquê.** "Acelera o metabolismo e queima gordura" todo mundo fala. A narrativa responde o segundo porquê, com a fisiologia traduzida.

## Fisiologia por público (só para destravar, sem número inventado)

| Público | O que costuma valer explicar |
|---|---|
| mulher de 35 a 55 | a partir dos 30 e poucos anos o corpo vai perdendo músculo se não for estimulado; nas mudanças hormonais da perimenopausa e da menopausa, o músculo e o treino de força pesam ainda mais para manter o gasto de energia e a forma do corpo |
| quem tem dor articular | músculo fraco em volta da articulação deixa mais carga em cima dela; o treino certo dá estabilidade e distribui a carga |
| esportista amador | a base de força é o que sustenta o gesto do esporte e protege de lesão; pular a base para ir direto no específico cobra a conta depois |

## Como a narrativa vai para fora

O texto completo do pilar é para o personal (e para quem trabalhar com ele) entender o próprio método. Na conversa de venda, ele usa só a parte que bate com o problema da aluna. No conteúdo, usa um pedaço de um pilar para gerar curiosidade (ex.: "depois dos 40, pesa muito o número e o funcionamento das suas mitocôndrias, as ferramentas que queimam a gordura; por isso a gente usa o [nome comercial]"). Todo conteúdo deve ter algo do método, e não só "falta constância".

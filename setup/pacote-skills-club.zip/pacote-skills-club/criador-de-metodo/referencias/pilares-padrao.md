# Pilares padrão

Regra do Peraça para os pilares do método. Quem mantém este arquivo pode editar à vontade. As etapas 2 e 3 leem daqui; não repita esta regra em outro arquivo.

## O que é pilar

Pilar é aquilo que o personal planeja e entrega e que é determinante para a aluna chegar no resultado que ele promete. Se tirar, do jeito que ele trabalha, o resultado não acontece.

- Pilar não é etapa. Pilar sustenta o método o tempo todo. Etapa (ou fase) é o que a aluna faz ao longo do tempo (ex.: primeiras 8 semanas, depois reforço, depois manutenção).
- Pilar não é formato de entrega. "Videoaulas na plataforma, 8 semanas, app de treino" é como o programa é entregue, não como o problema é resolvido.
- Outro profissional pode ter resultado sem esse pilar. Não importa: no método desta pessoa, sem ele não dá.

Pilar é como uma árvore: o pilar é o tronco, e dentro dele ficam os galhos (ordem dos exercícios, tipo de estímulo, dias da semana, intensidade, métodos de intensificação). Os galhos entram em "o que eu faço na prática", não viram pilar e não precisam aparecer na venda.

## Os 3 pilares padrão

No máximo 3 pilares. Para a grande maioria dos personais, são estes:

| # | Pilar (nome técnico) | Em uma linha |
|---|---|---|
| 1 | Treinamento resistido (ou exercícios resistidos) | o treino contra carga, a base do método |
| 2 | Cardiorrespiratório (ou aeróbio) | o trabalho de fôlego, do jeito que o personal prescreve (curto, intervalado, no fim do treino, junto com o resistido) |
| 3 | Progressão de estímulos | a troca planejada de estímulo ao longo do tempo: carga, faixa de repetição, intervalo, ordem, método de treino, com lógica e não por troca de ficha |

O nome técnico fica no metodo.md entre parênteses, para as outras skills saberem do que se trata. Para a aluna, cada pilar ganha um nome comercial (ver `nomes.md`).

## O teste do pilar (a pergunta da cliente chata)

Para cada candidato, pergunte ao personal, com o aluno ideal dele:

> "Chegou uma [aluna ideal] querendo [Ponto B]. Ela fala: eu não vou fazer [candidato]. Do seu jeito de trabalhar, ela chega lá?"

- "Não chega" = é pilar (desde que o personal controle e entregue).
- "Chega, só que mais devagar" = para candidato fora do padrão, não é pilar: é importante, entra dentro de outro pilar ou na conversa.

Os 3 pilares padrão seguem outra pergunta, a que o Peraça faz: "você usa ou não usa?". Se o personal usa sempre no planejamento, o pilar fica, mesmo que ele ache que "chega sem, só demora mais"; essa dúvida vai para o encontro. Se não usa, sai.

## O que geralmente não vira pilar

| Candidato | Por que não | Onde entra |
|---|---|---|
| Alimentação, quando o personal não prescreve dieta | ele não controla essa parte; se o parceiro falhar, o método fica pela metade | orientação geral, ou bônus com nutricionista parceira apresentado como "ajuste alimentar", com o valor normal da consulta como âncora |
| Mentalidade, motivação, disciplina | depende de coisas fora do controle do personal; quem já tem, chega sem isso | conversa no acompanhamento; só vira pilar se ele entrega uma ferramenta própria, todo ciclo |
| Constância, frequência | é intrínseco a qualquer processo | não vira pilar; aparece na conversa |
| Core, mobilidade, alongamento soltos | importantes, mas a aluna chega sem um pilar só deles | dentro do pilar de treino |
| Formato (app, vídeo, plataforma, prazo de 8 semanas) | é entrega, não solução | "O que o aluno recebe" e "Como funciona o acompanhamento" |

## Juntar ou trocar pilares

- **Resistido e cardio na mesma sessão:** se o cardio entra sempre ou quase sempre na mesma sessão do resistido (no meio, no fim, em circuito ou combinado), a skill oferece juntar os dois num pilar só; a pessoa decide (ex.: "treinamento híbrido"). O método fica com 2 pilares: o pilar combinado e a progressão de estímulos. Está certo; 2 pilares bem argumentados valem mais que 3 fracos.
- **Personal que não usa cardio:** pergunte "você usa cardio ou não usa?". Se não usa como parte determinante, o pilar 2 sai ou é trocado pelo que ele de fato faz.
- **Nicho que pede outro pilar:** ver a tabela abaixo. A skill propõe a adaptação e explica em uma linha por quê.

## Adaptação por nicho

O padrão é para emagrecimento, definição e condicionamento geral. Quando o nicho muda o problema, o pilar muda junto.

| Nicho | Proposta de pilares | Por quê |
|---|---|---|
| Dor (joelho, lombar, ombro) | 1. Avaliação da dor (entender o que dói, quando, quanto e que estrutura incomoda, com escala de dor de 0 a 10); 2. Exercícios específicos para a dor (o treino que a dor permite hoje, com reforço, estabilidade e mobilidade conforme a avaliação); 3. Progressão em fases (aliviar, reforçar, voltar à função) | quem tem dor chega quase sempre sem diagnóstico; sem entender a dor, o treino vira tirar exercício às cegas. Sem continuidade, a dor tende a voltar; por isso a progressão por fases também sustenta um acompanhamento mais longo (o Peraça sugere 3 ou 6 meses). Se o programa da pessoa é mais curto, isso vira pergunta para o encontro, não inimigo comum |
| Esporte (corrida, futebol, beach tennis, atleta amador) | 1. Treinamento resistido de base, com transferência para o gesto do esporte; 2. Condicionamento ligado à demanda do esporte (sprint, resistência); 3. Progressão em fases (base, específico, potência) | a demanda do esporte decide o treino; o erro do mercado é pular a base e ir direto no específico |
| Gestante e pós-parto | 1. Treino de força adaptado à fase; 2. Condicionamento leve e respiração; 3. Progressão por trimestre ou por fase do pós-parto | a fase muda o que é seguro; a progressão acompanha a fase, não o calendário da ficha |
| Idoso | 1. Força para as tarefas do dia; 2. Equilíbrio e marcha (prevenção de queda); 3. Progressão gradual | o resultado que importa é autonomia; equilíbrio é determinante, não acessório |
| Hipertrofia | 1. Treinamento resistido com volume e intensidade planejados; 2. Progressão de estímulos; cardio só se o personal usa de forma determinante | o cardio pode não passar no teste do pilar |

Em nicho de saúde ou dor, a palavra "diagnóstico" pode aparecer como nome comercial (o Peraça usa), mas o conteúdo é avaliação funcional do personal. Ele não dá diagnóstico médico. Exame, quando houver, vem do médico.

Esta tabela é ponto de partida. O que o personal faz na prática decide. Se o nicho dele não está aqui, aplique o teste do pilar e leve a dúvida para as perguntas do encontro.

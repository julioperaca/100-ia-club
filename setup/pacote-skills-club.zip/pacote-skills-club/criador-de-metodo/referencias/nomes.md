# Nomes: do pilar e do método

## Por que dar nome novo

Se o personal fala "aqui você vai fazer musculação", a aluna responde "eu já fiz e não emagreci". O nome comum carrega a crença antiga. O nome novo comunica a mesma coisa de um jeito que gera curiosidade e tira o parâmetro de comparação.

Exemplos que o Peraça usa: o iPhone não se chama smartphone, o computador da Apple é MacBook e não notebook, e o "sistema de ar quente" da air fryer é só o vento quente girando dentro da panela. É isso que a gente faz com o pilar: o pilar continua sendo o que é; muda a forma de comunicar. O nome sozinho não vende. O que vende é a narrativa.

## Tom: científico e comercial (Peraça, 27/10/2026)

O método não tem viés lúdico. Tem viés científico e comercial. Todo nome (do pilar, do método, das fases, do mecanismo) soa como protocolo, sistema ou método com base fisiológica, traduzido para a aluna na narrativa, nunca no nome.

- Vale: palavra que descreve o que acontece no treino ou no corpo (progressivo, combinado, híbrido, funcional, em fases, de transferência, de estabilidade).
- Não vale: nome brincalhão, fantasioso ou de apelido (número que vira marca, como "Cardio 123"; metáfora de brincadeira, como "Mapa da Dor" ou "Destrave"; palavra inventada, como "Firmadores"; nome que parece de jogo ou de desafio de rede social).
- A analogia simples (carro flex, ferramentas dentro das células) continua bem-vinda dentro do conceito e dos argumentos. O que não pode ser lúdico é o nome.

## Sigla (Peraça, 27 e 28/10/2026)

Sigla não é padrão. O nome por extenso é o principal. Em alguns casos, quando as iniciais ficam fáceis de falar, a skill pode oferecer a sigla como uma alternativa a mais para o personal escolher. Exemplo: "Protocolo de Retorno Progressivo, ou só PRP". No nome do método, no máximo uma das 3 opções leva sigla; no pilar, só raramente.

- Só as iniciais do nome que já existe, na ordem, sem contar as palavras de ligação (de, da, do, em). O nome vem primeiro; a sigla é consequência dele.
- Só quando fica fácil de falar (de 2 a 4 letras) e não é sigla de outra coisa conhecida (PHP, CPF, PIX). Se não ficar fácil, não sugira: nome sem sigla é o normal.
- Proibido o acróstico: escolher uma palavra (FORTE, VIDA, LEVE) e inventar um significado para cada letra. Isso puxa o método para o lúdico e força palavras que o personal não usaria.
- No esboço, a sigla aparece ao lado do nome, entre parênteses, e no campo de sigla da página. É alternativa: o personal e o encontro decidem se usam.

## Nome comercial do pilar

Para cada pilar, proponha 3 opções. Regras:
1. Diz o que é ou como é feito, de um jeito que dá vontade de perguntar "o que é isso?".
2. Coerente com o que a pessoa faz na prática (cardio curto não vira "Cardio Longo de Queima").
3. Em português e fácil de falar. Sigla em pilar é rara: só das iniciais do próprio nome e só se ficar fácil de falar; acróstico nunca (ver "Sigla").
4. Soa técnico na medida certa: palavras como híbrido, combinado, duplo, progressivo, ondulatório, alternado, em fases, específico, de transferência, funcional.
5. Na voz da pessoa (`voz.md`).
6. Entendível na hora. Nome que diz o benefício ("Exercícios Emagrecedores", "Exercícios Metabólicos") vale mais que nome inventado que ninguém entende (um nome em inglês que parece nome de jogo). A pessoa ouve e já imagina o que aquilo faz por ela.
7. Fuja de palavra que o público já tem ideia pronta ou que ele odeia: "consultoria", "dieta", "resistência aeróbica", "HIIT" (que muita gente acha que é treinar até morrer), "musculação" ("eu já faço"). Se o pilar é isso, dê outro nome e explique diferente ("sistema do prato" em vez de dieta; "intensidade certa" em vez de "intensidade máxima").
8. Se a pessoa quiser mais opções depois, a skill pode dar a ela este pedido pronto, sem falar em "prompt" nem "IA" ("se quiser mais ideias, cole isto numa conversa nova comigo"): "Sou personal, estou construindo meu método para [público e resultado]. Meu pilar é [o que é]. Me dê 50 nomes atrativos, comerciais, em português, que gerem curiosidade e interesse em saber como funciona." Depois refina pedindo mais na linha dos que gostou.

Exemplos dos encontros (para inspirar; nunca copiar sem a pessoa querer):

| Pilar técnico | Opções que surgiram |
|---|---|
| resistido com cardio na mesma sessão | Treinamento Híbrido, Treinamento Combinado, Estímulo Duplo, Exercícios Híbridos |
| resistido | Exercícios Multiarticulares, Treinamento Específico, Treinamento de Transferência, Treinamento em Fases, Exercícios de Reforço Específico |
| cardio curto ou intervalado | Cardio Curto, Cardio Intervalado, Condicionamento Específico |
| progressão de estímulos | Estímulos Progressivos, Estímulos Ondulatórios, Estímulos Alternados, Progressão de Estímulos |
| avaliação da dor | Avaliação Funcional, Análise da Dor, Diagnóstico Funcional |
| progressão em fases | Sistema Progressivo em Fases, Progressão de Protocolo |

## Nome do método

O nome do método vem por último, depois dos pilares e da narrativa. Exemplo do Peraça: "Tríade das Vendas Online" só existe porque ele tinha 3 pilares; com 2 pilares, "tríade" não faria sentido.

Regras:
1. Começa com **Protocolo**, **Sistema** ou **Método** (não é lei, é o padrão da mentoria). Com 3 pilares, **Tríade** também vale (como a "Tríade das Vendas Online" do Peraça).
2. Soa científico e comercial: a pessoa ouve e acredita que aquilo já existia e ela não conhecia (como "protocolo de concussão").
3. Nada lúdico ("Método Sem Volta") e nada com o nome do próprio personal ("Método do Fulano"): para quem está começando no digital, passa pouca credibilidade.
4. Não repete o nome de um pilar. Amarrado no que os pilares têm em comum (ex.: tudo progride: "Protocolo Progressivo"; tudo combina: "Método Híbrido"; 3 pilares: "Tríade do ...").
5. 3 opções, com uma linha de lógica para cada. Não precisa ter sigla em nenhuma; se as iniciais de uma opção ficarem fáceis de falar, ofereça a sigla como alternativa em no máximo uma das 3 ("Protocolo de Retorno Progressivo, ou só PRP"). A escolha final é do encontro.

## Mecanismo único (opcional)

Mecanismo é o motivo pelo qual, dessa vez, vai dar certo, quando antes não deu. Na área do personal, quase sempre é o que acontece no corpo quando os pilares são feitos juntos e do jeito certo (ex.: "ativação do sistema lipídico": o corpo passa a usar mais a gordura como combustível, como o carro flex que você manda abastecer com o combustível que quer). É mais subjetivo que o pilar e não é obrigatório: dá para ter método, mecanismo ou os dois.

Regras: é o resultado dos pilares juntos, não o conceito de um pilar com outro nome; tem que ser fisiologia real com nome novo, nunca um efeito inventado; não pode ser termo que o público já conhece e acha que já faz ("resistência aeróbica", "EPOC" já muito usado); precisa de narrativa própria (o que é, por que a maioria não consegue, como os pilares ligam essa chave). Na dúvida, fica como pergunta para o encontro.

## Método não é programa

- **Programa** é o produto: o nome diz o que o personal faz pelo público (ex.: "Programa Magra para Sempre", "Programa Atleta 30+", "Programa Viva Sem Dor"). Fica no `negocio.md`.
- **Método** é como ele resolve o problema: os pilares e a narrativa. Fica no `metodo.md`.
- O produto nunca se chama "consultoria". É "Programa Personalizado" (com iniciais maiúsculas) ou o nome que a pessoa deu.

Esta skill cuida do método. Se o nome do programa estiver confuso com o do método (ex.: "Joelhos Fortes" como nome de método), diga em uma linha que aquilo soa como nome de programa e leve para as perguntas do encontro. Não mexa no `negocio.md`.

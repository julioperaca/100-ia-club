# Meu método

> O que é: o passo a passo que você usa com seus alunos. Quem preenche é a skill de método.
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: tudo (a skill de método preenche)

## Nome do método

## Promessa

## Etapas ou pilares

## Como funciona o acompanhamento

## Prazos

## O que o aluno recebe

## Pistas encontradas nos seus arquivos

(A skill brain anota aqui, com fonte, o que achar sobre método. A skill de método usa como ponto de partida.)

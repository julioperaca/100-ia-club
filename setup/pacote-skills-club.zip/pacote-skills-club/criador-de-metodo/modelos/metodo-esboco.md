# Meu método

> O que é: o passo a passo que você usa com seus alunos. Quem preenche é a skill de método.
> Última atualização: 30/10/2026
> Status: em andamento (esboço para o encontro de quinta do Club)
> O que falta: fechar no encontro de quinta do Club (ver "Para levar ao encontro")

<!--
FORMATO DO metodo.md GRAVADO PELA SKILL (exemplo fictício da personal "Paula Exemplo").
Regras para a skill:
1. As 7 primeiras seções (Nome do método até Pistas) são do modelo do brain: mesma ordem, mesmos títulos. Nunca renomeie nem apague.
2. As seções novas vêm depois de "Pistas encontradas nos seus arquivos", nesta ordem: Conceito do método, Fases (opcional), Mecanismo (opcional), Caminhos comuns (inimigos comuns), Ponto A e Ponto B, O que diferencia meu jeito, Fora dos pilares, Para levar ao encontro de quinta do Club, Nomes considerados, Histórico de mudanças.
3. Cada pilar: título com o nome comercial preferido e o técnico entre parênteses; depois as linhas nome técnico, nomes comerciais, o que eu faço na prática, conceito, inimigo comum, argumentos e a tabela de tradução.
4. Nome comercial sem escolha firme da pessoa leva "(recomendado pela skill)" no lugar de "(preferido)".
5. Todo item termina com a fonte entre parênteses e data. Sugestão da skill que a pessoa não confirmou leva "(sugestão da skill, a fechar no encontro)".
6. Sigla: não é padrão. Só se a skill ofereceu sigla como alternativa para o nome favorito (só as iniciais, fácil de falar, nunca acróstico), linha "Sigla: PRP" logo abaixo do nome; se não, "Sigla: não sugerida" com o motivo em meia linha. Pilar com sigla leva a linha "- sigla: ..." depois de nomes comerciais.
7. Este comentário não vai para o arquivo da pessoa.
-->

## Nome do método

Protocolo Híbrido Progressivo (favorito do personal, a fechar no encontro, 30/10/2026)
Sigla: não sugerida, porque PHP já é nome de outra coisa conhecida (sugestão da skill, 30/10/2026)

## Promessa

Eu ajudo mulheres de 35 a 50 anos que trabalham fora a emagrecer e não engordar de novo, com o Protocolo Híbrido Progressivo, no Programa Roupa Solta. (sugestão da skill aprovada, 30/10/2026)

## Etapas ou pilares

### Pilar 1: Treinamento Híbrido (treinamento resistido com cardio na mesma sessão)
- nome técnico: treinamento resistido e cardiorrespiratório na mesma sessão (conversa, 30/10/2026)
- nomes comerciais: Treinamento Híbrido (preferido), Treinamento Combinado, Estímulo Duplo (sugestão da skill, 30/10/2026)
- o que eu faço na prática: base de multiarticulares, com 10 a 15 minutos de cardio intervalado dentro da mesma sessão (conversa, 30/10/2026)
- conceito: o treino de força junto com o cardio é o que faz o corpo construir músculo e, ao mesmo tempo, gastar mais energia e usar mais gordura como combustível. (sugestão da skill aprovada, 30/10/2026)
- inimigo comum: a crença de que precisa fazer musculação num dia e uma hora de esteira no outro, com volume alto. (conversa, 30/10/2026)
- argumentos: separado e longo, a intensidade cai e um treino pode atrapalhar o outro. Juntos, na mesma sessão e no tempo certo, ela treina menos tempo, mantém a intensidade e o corpo responde melhor na queima de gordura. Por isso a gente usa o Treinamento Híbrido: cabe na rotina de quem trabalha fora e ela não desiste no meio. (conversa; sugestão da skill aprovada, 30/10/2026)

| Termo técnico | Como falar para a aluna (ou "o aluno", conforme o público) |
|---|---|
| oxidação de gordura | o corpo buscando a gordura guardada para usar como combustível |
| interferência entre os treinos | um treino atrapalhando o outro quando feitos do jeito errado |
| intensidade | o quanto o treino exige de você naquele momento |

### Pilar 2: Estímulos Ondulatórios (progressão de estímulos)
- nome técnico: progressão de estímulos (conversa, 30/10/2026)
- nomes comerciais: Estímulos Ondulatórios (preferido), Estímulos Progressivos, Progressão de Estímulos (sugestão da skill, 30/10/2026)
- o que eu faço na prática: a cada 4 semanas mudo faixa de repetição, intervalo e carga, seguindo uma ordem planejada (conversa, 30/10/2026)
- conceito: o corpo se adapta ao que você faz sempre igual; para continuar respondendo, o estímulo precisa mudar no momento certo. (sugestão da skill aprovada, 30/10/2026)
- inimigo comum: trocar a ficha todo mês achando que trocou o estímulo. (conversa, 30/10/2026)
- argumentos: trocar o exercício nem sempre troca o estímulo; o corpo continua sendo pedido do mesmo jeito e para de gastar mais. Nos Estímulos Ondulatórios a mudança segue uma lógica: hora mais carga, hora mais repetição, hora menos descanso. (sugestão da skill, a fechar no encontro)

| Termo técnico | Como falar para a aluna |
|---|---|
| adaptação ao estímulo | o corpo se acostuma: o que cansava no começo fica fácil |
| periodização ondulatória | mudar o tipo de treino de um jeito planejado, para o corpo não se acostumar |

## Como funciona o acompanhamento

1. Formulário e chamada de vídeo de 30 minutos (negocio.md)
2. Treino no app em até 3 dias úteis (negocio.md)
3. Ajuste do treino a cada 4 semanas (negocio.md)

## Prazos

- Programa de 4 meses (negocio.md)

## O que o aluno recebe

- avaliação inicial por formulário e chamada de vídeo (negocio.md)
- treino no app (negocio.md)
- suporte pelo WhatsApp (negocio.md)

## Pistas encontradas nos seus arquivos

- "treino em casa ou na academia, ajuste mensal" (apresentacao.pdf, página 2) (usada no pilar 2, 30/10/2026)

## Conceito do método

Para a mulher que trabalha fora emagrecer e não engordar de novo, o caminho comum é separar musculação e uma hora de esteira e trocar a ficha todo mês. No Protocolo Híbrido Progressivo, força e cardio andam juntos na mesma sessão, e o estímulo muda com lógica a cada fase. (sugestão da skill aprovada, 30/10/2026)

## Fases (opcional)

1. Adaptação: os primeiros ajustes de treino e rotina trazem o primeiro resultado visível, que dá ânimo para seguir. (conversa, 30/10/2026)
2. Progressão: quando o corpo se acostuma, os estímulos mudam para o resultado não parar. (conversa, 30/10/2026)
3. Manutenção: o treino passa a proteger o resultado conquistado. (sugestão da skill aprovada, 30/10/2026)

## Mecanismo (opcional)

não definido no esboço (vai para o encontro)

## Caminhos comuns (inimigos comuns)

- musculação num dia e uma hora de esteira no outro, com volume alto (pilar 1) (conversa, 30/10/2026)
- trocar a ficha todo mês achando que trocou o estímulo (pilar 2) (conversa, 30/10/2026)

## Ponto A e Ponto B

- Ponto A: trabalha fora, chega cansada, já fez esteira e dieta da sopa (aluno-ideal.md)
- Ponto B: emagrecer e não engordar de novo (aluno-ideal.md)
- O que o método não promete: número garantido na balança, cura ou tratamento de doença, dieta (alimentação fica com nutricionista) (regra da skill)

## O que diferencia meu jeito

- força e cardio juntos na mesma sessão, com estímulo que muda com lógica (sugestão da skill aprovada, 30/10/2026)

## Fora dos pilares

- alimentação: não prescrevo dieta; entra como bônus de ajuste alimentar com a nutricionista parceira (conversa, 30/10/2026)
- mentalidade: importante, mas não entrego ferramenta própria; fica na conversa do acompanhamento (conversa, 30/10/2026)

## Para levar ao encontro de quinta do Club

1. Junto força e cardio num pilar só (2 pilares) ou separo em 3?
2. Treinamento Híbrido ou Treinamento Combinado para o pilar 1?
3. O argumento do pilar 2 está forte para quem nunca ouviu falar em estímulo?
4. Nome do método: Protocolo Híbrido Progressivo, Sistema Híbrido em Fases ou Método Combinado Progressivo?

## Nomes considerados

- Pilar 1: Treinamento Híbrido (preferido), Treinamento Combinado, Estímulo Duplo
- Pilar 2: Estímulos Ondulatórios (preferido), Estímulos Progressivos, Progressão de Estímulos
- Método: Protocolo Híbrido Progressivo (favorito), Sistema Híbrido em Fases, Método Combinado Progressivo
(sugestão da skill, 30/10/2026)

## Histórico de mudanças

- 30/10/2026: esboço criado (skill criador-de-metodo).
- 30/10/2026: pilares 1 e 2 juntos em Treinamento Híbrido, porque ela sempre faz força e cardio na mesma sessão (conversa).

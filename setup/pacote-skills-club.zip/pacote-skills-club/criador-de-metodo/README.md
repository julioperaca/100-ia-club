# criador-de-metodo

Skill para o personal sair com o **esboço** do método (até 3 pilares, nome comercial de cada um, conceito, inimigo comum e argumentos) e levar para o encontro de quinta do Club, onde o Peraça fecha junto com ele. Leva de 45 a 55 minutos e não instala nada.

## Como usar

No Claude (aba Code), digite `/criador-de-metodo` ou fale "criar meu método", "pilares do meu método", "nome do método".

- Para mudar algo: `/criador-de-metodo ajusta: troca o nome do pilar 2`.
- Depois do encontro: `/criador-de-metodo fechei: o que ficou decidido`.

## Antes

A skill `brain` precisa ter rodado: é de lá que vêm sua aluna ideal, seu negócio e sua voz. Se a skill `design-system` já rodou, a página sai com as suas cores.

## O que ela faz

1. Lê seu brain e conta em 3 linhas o que já sabe.
2. Pergunta o que não pode faltar no planejamento da sua aluna e passa cada coisa pelo teste do pilar. Padrão: treino resistido, cardio e progressão de estímulos. Se o seu nicho pede outra coisa (dor no joelho, esporte, gestante, idoso), ela propõe a adaptação e explica por quê.
3. Para cada pilar: 3 opções de nome comercial e a narrativa (conceito, inimigo comum, argumentos), com a fisiologia traduzida para a língua da aluna.
4. Escreve a ideia central do método, pergunta se o seu trabalho tem fases ou um mecanismo (opcionais) e propõe 3 nomes.
5. Grava `brain/metodo.md` e abre `brain/metodo.html`, a página do esboço, com 3 a 5 perguntas para levar ao encontro.

Pode parar no meio: na próxima vez, ela continua de onde parou.

## Instalação

Copie a pasta `criador-de-metodo` para `~/.claude/skills/` (no Windows, `C:\Users\<nome>\.claude\skills\`).

## Arquivos

| Arquivo | Para quê |
|---|---|
| `SKILL.md` | entrada, modos, contrato com o brain, regras |
| `etapas/1-ler.md` a `etapas/5-salvar-e-mostrar.md` | as 5 etapas do esboço |
| `etapas/6-ajustar-e-fechar.md` | ajustar depois e fechar depois do encontro |
| `referencias/pilares-padrao.md` | a regra dos 3 pilares, o teste do pilar, o que não vira pilar, adaptação por nicho |
| `referencias/narrativa-do-pilar.md` | conceito, inimigo comum, argumentos, o modelo do treinamento híbrido, bancos de inimigos e traduções |
| `referencias/nomes.md` | nome comercial do pilar e do método; método não é programa |
| `modelos/metodo-esboco.md` | formato do metodo.md gravado |
| `modelos/metodo-vazio.md` | modelo vazio, igual ao da skill brain |
| `modelos/metodo.html` | a página do esboço (só o bloco DADOS muda) |

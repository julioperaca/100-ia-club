# Meu segundo cérebro

> O que é: a pasta onde fica tudo que as skills precisam saber sobre você e o seu negócio.
> Última atualização: [data de hoje]

Todas as suas skills leem daqui: design system, conteúdo e copy, e as que você receber depois. Quanto mais completo, melhor elas trabalham. Para mexer, diga ao Claude "atualiza meu cérebro com isso" e cole a novidade.

## Andamento

- Caminho:
- [ ] 1. Criar a pasta
- [ ] 2. Ler seus arquivos
- [ ] 3. Confirmar o que foi entendido
- [ ] 4. Entrevista do que faltou
- [ ] 5. Teste do espelho

## Arquivos já lidos

(Nome do arquivo e data da leitura. O que está aqui não é lido de novo, só se você pedir.)

## Arquivos que não consegui ler

## O que tem em cada arquivo

| Arquivo | O que guarda | Quem escreve |
|---|---|---|
| perfil-profissional.md | nome, CPF ou CNPJ, CREF, cidade, Instagram, WhatsApp, suporte, entrega do treino, prazos | brain e contrato |
| negocio.md | produtos, preços, como vende, história, diferencial, números, provas, Instagram, rotina | brain |
| aluno-ideal.md | quem é, Ponto A, Ponto B, objeções, linguagem | brain |
| voz.md | tom, expressões, o que nunca diz, textos reais | brain |
| metodo.md | o passo a passo do seu trabalho (opcional) | brain, quando você contar |
| identidade-visual.md | cores, fontes, logo, estilo | skill de design system |
| cases.md | resultados e depoimentos, com autorização | brain |
| arquivos/ | o que você já tinha (PDF, prints, textos) | você |
| contratos/ | contratos gerados | skill de contrato |

## Regras que toda skill segue ao ler esta pasta

1. Cada arquivo começa com um cabeçalho: o que é, última atualização, status (vazio, em andamento, completo) e o que falta.
2. "a confirmar" (ou campo vazio no perfil-profissional.md) não é fato: a skill pergunta ou deixa de fora, nunca inventa.
3. Cada informação tem a fonte entre parênteses: o arquivo de onde veio, "conversa" ou "entrevista", com data.
4. Case com "autorização para uso público: não" nunca vai para conteúdo, página ou anúncio.
5. Nenhum dado de aluno (saúde, documentos, contatos) entra aqui. A pasta contratos/ é a única exceção, e só a skill de contrato mexe nela.
6. Quem escreve algo novo atualiza a data do cabeçalho e o "o que falta". Nunca apaga o que já está escrito sem você pedir.

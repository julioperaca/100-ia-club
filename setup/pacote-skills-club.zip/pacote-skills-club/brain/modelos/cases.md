# Cases e depoimentos

> O que é: resultados e depoimentos dos seus alunos, para usar em conteúdo, página e venda.
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: nenhum case registrado

Regra de privacidade: só entra aqui o resultado e o depoimento. Nunca CPF, endereço, exame, laudo, remédio ou qualquer dado de saúde além do resultado que o próprio aluno contou. Case com "autorização para uso público: não" serve só para você lembrar: nenhuma skill publica, e ele fica sem nome (use "aluna, 42 anos").

## Modelo de case

### Case: (nome ou apelido)
- autorização para uso público: sim/não
- com rosto ou sem rosto:
- produto que comprou:
- antes:
- depois:
- em quanto tempo:
- depoimento (palavras dele, entre aspas):
- prints ou fotos (caminho em arquivos/):
- data:
- fonte:

## Cases

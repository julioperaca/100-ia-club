# Pasta contratos

Aqui a skill de contrato salva os contratos que ela gera (PDF, HTML e MD). A skill brain não lê esta pasta, porque ela tem dados de alunos.

Este arquivo (_leia-me.md) é ignorado na leitura.

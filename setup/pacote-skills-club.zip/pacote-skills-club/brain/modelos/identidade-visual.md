# Identidade visual

> O que é: cores, fontes, logo e estilo das suas peças. Quem preenche é a skill de design system.
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: tudo (a skill de design system preenche)

## Cores

(Nome da cor e código, ex.: verde principal #2E7D32.)

## Fontes

## Logo

(Caminho do arquivo em arquivos/.)

## Estilo de foto e imagem

## Referências que eu gosto

## Pistas encontradas nos seus arquivos

(A skill brain anota aqui, com fonte, o que achar sobre visual. A skill de design system usa como ponto de partida.)

# Meu negócio

> O que é: o que você vende, por quanto, como vende, sua história, seu diferencial, seus números, seu Instagram e sua rotina de trabalho.
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: todas as seções

Cada item termina com a fonte entre parênteses. O que ainda não se sabe fica escrito "a confirmar".

## O que eu vendo

Regra de nome: o que você vende se chama "Programa Personalizado", com iniciais maiúsculas (ou o nome próprio que você der a ele). Nunca chamar de "consultoria", em nenhum texto.

- situação do Programa Personalizado online (pronto e vendendo, pronto sem venda, em construção, só presencial):

### Produto 1
- nome:
- formato (online, presencial, híbrido):
- duração:
- preço:
- formas de pagamento:
- o que está incluído:
- para quem é:

(Copie o bloco "Produto" para cada produto. Preço antigo nunca é apagado: vai para Histórico de preços.)

## Histórico de preços

## Como a venda acontece

(Por onde o aluno chega e fecha: direct, WhatsApp, link de pagamento, chamada.)

- de onde vêm os alunos:
- pessoas interessadas por mês:
- da primeira mensagem até o pagamento:
- onde mais trava na conversa de venda:
- por onde o aluno paga:
- página na internet para vender ou captar contatos:
- anúncio pago:

## Minha história (curta)

## Meu diferencial

## Números

- alunos ativos hoje:
- alunos já atendidos:
- faturamento mensal (só se você quiser registrar):

## Provas e resultados

(Formação, certificações, tempo de profissão, resultados gerais. Depoimento de aluno vai em cases.md.)

## Instagram

- perfil profissional (comercial ou criador de conteúdo):
- frequência de posts hoje:
- perfis de referência ou concorrentes (os 3 @ que você indicou):
- o que mais trava na hora de produzir conteúdo:

## Rotina de trabalho

- onde controla alunos e pessoas interessadas:
- tarefa da semana que mais toma tempo e você quer parar de fazer na mão:
- como monta um treino hoje e quanto tempo leva:
- informação que você quer receber no celular todo dia:

# Meu método

> O que é: o passo a passo que você usa com seus alunos. É opcional: a skill brain anota o que achar nos seus arquivos e o que você contar ("atualiza meu cérebro com o meu método").
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: tudo (opcional; as outras skills funcionam sem ele)

## Nome do método

## Promessa

## Etapas ou pilares

## Como funciona o acompanhamento

## Prazos

## O que o aluno recebe

## Pistas encontradas nos seus arquivos

(A skill brain anota aqui, com fonte, o que achar sobre método. Quando você contar o método, vira as seções acima.)

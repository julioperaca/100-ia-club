# Pasta arquivos

Jogue aqui tudo que você já tem sobre o seu trabalho. Não precisa organizar nem renomear.

O que mais ajuda:
- print ou texto da bio do Instagram
- legendas de posts (copie e cole num arquivo de texto)
- apresentação do seu Programa Personalizado (PDF, Word, Canva exportado em PDF)
- tabela de preços
- prints de depoimentos de alunos (só de quem autorizou)
- áudios seus já transcritos em texto
- sua logo e paleta de cores

Não coloque aqui: ficha de anamnese, exame, laudo, documento ou planilha com dados de aluno.

Este arquivo (_leia-me.md) é ignorado na leitura.

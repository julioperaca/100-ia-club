# Perfil profissional

> O que é: seus dados profissionais. A skill de contrato e as outras skills leem este arquivo. Aqui ficam só dados seus, nunca dados de aluno.
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: todos os campos

Campo sem valor depois dos dois pontos quer dizer "a confirmar". Não escreva nada depois do valor (nem a fonte): a fonte de cada campo fica na lista Fontes, no fim do arquivo.

- nome_ou_razao_social:
- cpf_ou_cnpj:
- cref:
- cidade_uf:
- canal_suporte:
- dias_horarios_suporte:
- prazo_resposta:
- forma_entrega:
- periodicidade_ajustes:
- prazo_primeiro_plano:
- planos_por_mes:
- dias_pausa:
- multa_percentual:
- foro:
- aviso_juridico_lido:
- nome_publico:
- instagram:
- whatsapp:

## Fontes

(De onde veio cada campo preenchido, sempre no formato "campo, fonte: ...". Ex.: "- instagram, fonte: arquivos/bio.txt". A vírgula depois do nome evita que a skill de contrato confunda esta lista com os dados.)

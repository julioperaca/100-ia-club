# Aluno ideal

> O que é: quem é o aluno que você quer atender, onde ele está hoje (Ponto A) e onde quer chegar (Ponto B).
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: todas as seções

Cada item termina com a fonte entre parênteses. O que ainda não se sabe fica escrito "a confirmar".

## Quem é

- gênero e idade:
- rotina e profissão:
- onde mora:
- o que já tentou antes:

## Ponto A: onde ele está hoje

(Dores, frustrações, o que incomoda, o que sente quando se olha no espelho.)

## Ponto B: onde ele quer chegar

(O resultado que deseja, em quanto tempo, o que muda na vida dele.)

## Objeções

(O que ele diz antes de comprar. Ex.: "não tenho tempo", "já tentei e não deu certo".)

## Linguagem que ele usa

(Frases literais, do jeito que o aluno fala, entre aspas.)

## Quem não é meu aluno

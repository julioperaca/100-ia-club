# Minha voz

> O que é: como você fala. Serve para todo texto escrito por uma skill parecer seu.
> Última atualização: [data de hoje]
> Status: vazio
> O que falta: todas as seções, e de 3 a 5 textos reais seus

Cada item termina com a fonte entre parênteses. O que ainda não se sabe fica escrito "a confirmar".

## Tom

(Três palavras que descrevem seu jeito. Ex.: direta, carinhosa, sem frescura.)

## Expressões que eu uso

## Como eu chamo o aluno

(Você, amiga, mulherada, pelo nome.)

## O que eu nunca digo

## Emoji, gírias e pontuação

(Descrever em palavras, por exemplo: "usa emoji de coração no fim", "escreve tudo minúsculo".)

## Textos reais meus

(De 3 a 5 legendas, mensagens ou áudios transcritos, copiados como estão, cada um com a fonte.)

## Ajustes do teste do espelho

(O que foi corrigido depois de você ler a legenda de teste.)

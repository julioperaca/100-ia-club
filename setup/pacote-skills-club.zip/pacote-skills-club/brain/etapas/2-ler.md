# Etapa 2. Ler os arquivos

Tempo no encontro: 20 minutos (mais 15 para a pessoa juntar os arquivos) no caminho completo. No Modo Essencial e no caminho do formulário, só o que a pessoa trouxe (prints, logo, fotos, depoimentos): de 5 a 10 minutos.

## Antes de ler: aviso de privacidade (mostrar sempre)

> Um cuidado antes: dados dos seus alunos não entram no segundo cérebro. Nada de anamnese, exame, laudo, CPF, endereço ou planilha de alunos. A única exceção é depoimento ou resultado de aluno que autorizou o uso. Se tiver algo assim na pasta, eu pulo e te aviso.

## Passo 1. Listar

Glob em `<pasta>/arquivos/**/*`. Ignore `_leia-me.md` e o que já está em "Arquivos já lidos" no README.md (a não ser que a pessoa peça para ler de novo).

## Passo 2. Ler cada arquivo

| Tipo | Como ler |
|---|---|
| .txt, .md, .csv | Read |
| .pdf | Read (acima de 10 páginas, leia em partes com `pages`, ex.: "1-10") |
| .png, .jpg, .jpeg, .webp, .heic | Read (a imagem aparece para você; leia o texto do print) |
| .docx | Read. Se falhar: no Mac rode `textutil -convert txt -stdout "<arquivo>"`; no Windows peça "abre no Word e salva como PDF nesta mesma pasta" |
| .xlsx | Peça para salvar como CSV ou PDF |
| áudio, vídeo (.mp3, .m4a, .ogg, .opus, .mp4, .mov) | Não leio. Peça a transcrição em texto (o WhatsApp transcreve áudio; ou cole o que foi falado) |
| qualquer outro | Liste como não lido |

Arquivo que não deu para ler vai para "Arquivos que não consegui ler" no README.md, com o motivo em uma frase.

Arquivo com dado de aluno (ficha, exame, documento, lista de alunos): não extraia nada, não copie nada, e avise: "O arquivo X tem dados de aluno, então pulei. Pode tirar da pasta." Print de depoimento é permitido: vira candidato a case, e a autorização é perguntada na confirmação.

## Passo 3. Ler o que a pessoa colar

Bio, legendas, mensagens, link do Instagram. Link: não abra nem raspe a página (perfil do Instagram pede login). Peça para colar o texto ou mandar print. A fonte de texto colado é "conversa, dd/mm/aaaa".

## Passo 4. Extrair com fonte

Para cada informação, anote: o que é, o arquivo de destino, a seção, e a fonte (nome do arquivo, página se for PDF). Mapa de destino:

| Achou | Vai para |
|---|---|
| nome, CPF ou CNPJ, CREF, cidade, @ do Instagram, WhatsApp, suporte, app de entrega, prazos | perfil-profissional.md (nomes de campo exatos do modelo) |
| produto, formato, duração, preço, forma de pagamento, história, diferencial, números, formação | negocio.md |
| para quem é, dores, desejos, objeções, frases de aluno | aluno-ideal.md |
| legenda, mensagem, jeito de falar | voz.md (texto real copiado como está, em "Textos reais meus") |
| depoimento, antes e depois, resultado de aluno | cases.md (autorização: a confirmar) |
| passo a passo, fases, nome do método | metodo.md, seção "Pistas encontradas nos seus arquivos" |
| cores, fontes, logo | identidade-visual.md, seção "Pistas encontradas nos seus arquivos" |

Regras da extração:
- Só o que está escrito. Se você deduziu (ex.: "parece que o público é feminino"), marque "(dedução, a confirmar)".
- Informação que aparece diferente em dois arquivos (ex.: dois preços): guarde as duas com as fontes e pergunte na confirmação.
- Nada sem fonte. Sem fonte, fica "a confirmar" e vira pergunta na entrevista.

## Passo 5. Guardar

Ainda não grave nos arquivos do cérebro: guarde a lista na conversa e vá para a Etapa 3. Registre no README.md os arquivos lidos com a data, e marque `- [x] 2. Ler seus arquivos (dd/mm/aaaa)`.

Se a pessoa não tiver nenhum arquivo: diga "Sem problema, a gente monta conversando", marque a etapa 2 e 3 como feitas e vá direto para a Etapa 4 (no Modo Essencial, para a entrevista essencial).

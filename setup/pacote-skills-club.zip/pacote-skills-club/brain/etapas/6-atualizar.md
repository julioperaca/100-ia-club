# Modo atualizar (uso diário)

Quando a pessoa disser "atualiza meu cérebro com isso", "anota no meu cérebro", "mudei o preço", "chegou depoimento" ou colar algo novo.

## Passo 1. Entender a novidade

Leia `$ARGUMENTS` e o que foi colado ou anexado. Se veio print ou PDF, leia com Read. Se tiver dado de aluno além do depoimento e resultado, avise e não grave essa parte.

## Passo 2. Decidir o arquivo

| Novidade | Arquivo e seção |
|---|---|
| produto novo, mudança de formato | negocio.md, O que eu vendo |
| preço novo | negocio.md: troque o valor no produto e acrescente em Histórico de preços "R$ antigo até dd/mm/aaaa (fonte)" |
| depoimento, resultado de aluno | cases.md (pergunte a autorização antes de gravar) |
| frase de aluno, objeção nova | aluno-ideal.md |
| legenda, mensagem, expressão | voz.md |
| CREF, WhatsApp, Instagram, horário, app de entrega | perfil-profissional.md (só o valor; fonte na lista Fontes, formato `- campo, fonte: ...`) |
| passo a passo, método | metodo.md: o que a pessoa disser com clareza (nome, promessa, etapas ou pilares, acompanhamento, prazos, o que o aluno recebe) vai na seção de mesmo nome, e o resto em Pistas encontradas |
| cor, fonte, logo | identidade-visual.md, Pistas encontradas |
| arquivo novo para guardar | copie para arquivos/ e leia como na Etapa 2 |

Se não der para saber o arquivo, pergunte em uma frase: "Isso é sobre seu negócio ou sobre seu aluno ideal?".

## Passo 3. Gravar

- Use Edit. Nunca apague o que existe; o que mudou vira histórico com data.
- Fonte entre parênteses com data: "(conversa, dd/mm/aaaa)" ou o nome do arquivo.
- Atualize no cabeçalho a "Última atualização" e o "O que falta" (tire o que foi respondido).

## Passo 4. Confirmar em uma linha

```
Anotado em negocio.md: plano de 6 meses agora custa R$ 1.097 (antes R$ 997, guardado no histórico).
```

Se a novidade contradiz algo já gravado (ex.: outro preço para o mesmo plano), mostre os dois e pergunte qual vale antes de gravar.

# Caminho do formulário

Para quem trouxe as suas respostas do formulário (o arquivo que o Peraça te mandou no WhatsApp), ou disse que respondeu.

Tempo no encontro: de 25 a 35 minutos nesta etapa (5 para ler e gravar, 10 para o resumo e as correções, de 10 a 20 para as lacunas). Somando criar a pasta e o teste do espelho, o caminho todo fica entre 45 e 60 minutos.

Antes desta etapa, a Etapa 1 (criar a pasta) já precisa ter rodado. Se a pasta não existe, rode a Etapa 1 primeiro e volte aqui. Exceção: se a pasta já existia antes desta conversa, veja a tabela "Qual caminho" no Passo 1.

## Passo 1. Pegar as respostas

O normal é o arquivo `respostas-nome-sobrenome.txt` que o Peraça mandou no privado do WhatsApp: a pessoa arrasta o arquivo para a conversa (leia com Read) ou cola o texto. Se ela não trouxe nada, veja com Glob se há um `respostas-*.txt` na pasta da sessão e ofereça: "Achei o arquivo <nome>. Uso ele?"

### Como reconhecer o arquivo

São três tipos. Em todos, cada pergunta do formulário fica numa linha, a resposta na(s) linha(s) de baixo, e há uma linha em branco entre elas. Respostas de caixas múltiplas vêm separadas por vírgula.

| Tipo | Linha 1 | Linha 2 | Linha 3 | O que traz |
|---|---|---|---|---|
| Club completo | "100% IA Club: antes do setup" | "Respostas do formulário de <nome>" | "Enviado em dd/mm/aaaa hh:mm" | as 29 perguntas das duas primeiras tabelas do Passo 2 e mais as 30 perguntas novas |
| Club curto | "100% IA Club: para quem fez a imersão" | "Respostas do formulário de <nome>" | "Enviado em dd/mm/aaaa hh:mm" | "Seu nome e sobrenome" e 25 perguntas novas (sem o bloco "Sua história") |
| Antigo | "Imersão Personal 100% Digital: antes da sala" | "Respostas do formulário pré-imersão de <nome>" | "Enviado em AAAA/MM/DD hh:mm" | só as 29 perguntas |

A pergunta "E-mail" é só o contato da pessoa. "Seu nome e sobrenome" serve só para conferir de quem é o arquivo. Também vale, se alguém tiver, o e-mail com a cópia das respostas: título igual, frases do Google Forms como "Obrigado por preencher" e "o que recebemos", e as perguntas seguidas das respostas.

### Qual caminho, pelo tipo do arquivo e pela pasta

Veja se `<pasta>/README.md` já existia antes desta conversa (com Andamento preenchido).

| Pasta | Arquivo | O que fazer |
|---|---|---|
| não existe | Club completo ou antigo | este caminho, do Passo 2 ao Passo 6 |
| não existe | Club curto | diga: "Esse arquivo é para quem já montou o segundo cérebro antes. Você tem também o arquivo das suas respostas da imersão?" Com o arquivo antigo, siga este caminho com ele. Sem nenhum, siga pelo Modo Essencial (`${CLAUDE_SKILL_DIR}/etapas/essencial.md`). Nos dois casos, guarde o arquivo curto: depois do teste do espelho, aplique-o pelo Modo atualizar pelo formulário, no fim deste arquivo |
| existe | Club curto ou Club completo | Modo atualizar pelo formulário, no fim deste arquivo. Sem entrevista e sem teste do espelho |
| existe | antigo | se ele já está em "Arquivos já lidos" do README.md, diga que já foi lido; se não está, Modo atualizar pelo formulário |

- Disse que respondeu mas não trouxe: "Arraste aqui o arquivo com as suas respostas, que o Peraça te mandou no WhatsApp, ou copie o texto dele e cole aqui."
- Não acha o arquivo: "Pede ao Peraça o arquivo com as suas respostas. Enquanto isso, seguimos pelo Modo Essencial." Siga pelo Modo Essencial (`${CLAUDE_SKILL_DIR}/etapas/essencial.md`) e diga que, quando o arquivo chegar, é só arrastar ou colar.
- Colou só um pedaço: leia o que veio e trate o resto como lacuna.

Data da fonte: use a data de "Enviado em" (ou a data que aparece no e-mail). Se não aparecer, use a data de hoje. A fonte de tudo que vier daqui é "(formulário do 100% IA Club, arquivo de respostas, dd/mm/aaaa)" nos arquivos do Club e "(formulário pré-imersão, arquivo de respostas, dd/mm/aaaa)" no arquivo antigo. Os exemplos abaixo usam a do Club; com o arquivo antigo, troque.

Mostre o aviso de privacidade da Etapa 2 antes de gravar. Se alguma resposta trouxer dado de aluno (doença, remédio, exame, CPF, telefone, sobrenome), não grave essa parte e avise em uma linha. No case, guarde só o primeiro nome (e só se a autorização for "sim"), a idade e o resultado.

## Passo 2. Gravar nos arquivos

Leia cada resposta pelo sentido (a pessoa pode ter respondido fora do lugar) e grave com Edit, na seção certa, com a fonte entre parênteses. Nunca use Write num arquivo que já tem conteúdo.

### perfil-profissional.md

Só o valor depois dos dois pontos. A fonte vai na lista Fontes do fim, no formato `- cref, fonte: formulário do 100% IA Club, arquivo de respostas (dd/mm/aaaa)`. Campo vago ou sem resposta fica vazio (nunca escreva "a confirmar" na linha do campo).

| Pergunta do formulário | Campo | Como gravar |
|---|---|---|
| Nome completo ou razão social | `nome_ou_razao_social` | como veio |
| CPF ou CNPJ | `cpf_ou_cnpj` | confira se tem 11 ou 14 dígitos; se não tiver, deixe vazio e pergunte nas lacunas |
| CREF com número e estado | `cref` | número e UF, ex.: 012345-G/SC; sem UF, deixe vazio e pergunte |
| Cidade e estado onde você trabalha | `cidade_uf` | Cidade/UF, ex.: Florianópolis/SC |
| Nome pelo qual seus alunos te conhecem | `nome_publico` | como veio |
| Seu @ do Instagram | `instagram` | com @ na frente |
| WhatsApp de atendimento, com DDD | `whatsapp` | (DDD) número |
| Por onde o aluno fala com você no dia a dia? | `canal_suporte` | ex.: WhatsApp (48) 90000-0000 (junte o número da pergunta do WhatsApp quando o canal for WhatsApp) |
| Em quais dias e horários você responde aluno, e em quanto tempo responde? | `dias_horarios_suporte` e `prazo_resposta` | separe: dias e horários num campo, o prazo no outro. Se faltar um dos dois, o que falta fica vazio |
| Como o aluno recebe o treino? | `forma_entrega` | por extenso e sem gíria, ex.: "pelo app MFIT" vira "aplicativo MFIT" |
| De quanto em quanto tempo você troca ou ajusta o treino? | `periodicidade_ajustes` e `planos_por_mes` | periodicidade como "30 dias". planos_por_mes: 15 dias = 2; 30 dias = 1; qualquer outra resposta deixa planos_por_mes vazio (a skill de contrato pergunta) |
| Em quantos dias úteis você entrega o primeiro treino? | `prazo_primeiro_plano` | só o número, ex.: 3 |
| Pausa (por até quantos dias) | `dias_pausa` | só o número; "Ainda não sei" deixa vazio |
| Multa sobre os meses que faltam | `multa_percentual` | ex.: 20%; "Sem multa" vira 0%; "Ainda não sei" deixa vazio |
| Qual cidade vale se for para a justiça | `foro` | "cidade do aluno"; "A minha cidade" vira o valor de `cidade_uf`; "Ainda não sei" deixa vazio |
| (não está no formulário) | `aviso_juridico_lido` | deixe vazio: a skill de contrato mostra o aviso jurídico e grava o "sim" |

### Os outros arquivos

| Pergunta do formulário | Arquivo e seção |
|---|---|
| O que você vende hoje (nome, duração, preço, parcelas, o que recebe) | negocio.md, O que eu vendo: um bloco Produto por programa. Formato "online" só se a resposta disser; senão, a confirmar |
| Como o aluno pode pagar | negocio.md, formas de pagamento de cada Produto |
| Quantos alunos ativos você tem hoje | negocio.md, Números, alunos ativos hoje |
| Quanto você fatura por mês | negocio.md, Números, faturamento mensal (a faixa, como veio; "Prefiro não dizer" fica assim mesmo) |
| Como é esse aluno | aluno-ideal.md, Quem é (gênero e idade, rotina e profissão) |
| O que mais incomoda e o que já tentou | aluno-ideal.md, Ponto A e "o que já tentou antes" |
| O que ele quer conseguir, e em quanto tempo | aluno-ideal.md, Ponto B |
| O que fala quando fica na dúvida de comprar | aluno-ideal.md, Objeções (frases entre aspas também vão para Linguagem que ele usa) |
| 3 frases que você sempre fala | voz.md, Expressões que eu uso |
| Palavra ou jeito de falar que não usa | voz.md, O que eu nunca digo |
| 2 ou 3 textos seus | voz.md, Textos reais meus, copiados como estão, um por item. A partir deles, preencha Tom, Como eu chamo o aluno e Emoji, gírias e pontuação, marcados "(dedução dos textos do formulário, a confirmar)" |
| Passo a passo do primeiro contato ao fim | metodo.md, Pistas encontradas nos seus arquivos. Se o "o que está incluído" do produto ficou vazio, complete com o que aparece aqui |
| O que você faz que outros personais não fazem | negocio.md, Meu diferencial; e uma linha em metodo.md, Pistas |
| 2 ou 3 resultados de alunos | cases.md, um Case por resultado. Autorização "sim" só quando a resposta disser que o aluno autorizou (e com ou sem rosto). "Não perguntei", silêncio ou dúvida: "não", e o case fica sem nome (ex.: "aluna, 38 anos") |

### As perguntas novas do 100% IA Club

Só aparecem nos arquivos do Club; o título abaixo é o que vem na linha da pergunta. Se a pasta é de antes e não tem a linha ou a seção de destino, acrescente com Edit no mesmo lugar em que ela está, seguindo o modelo de mesmo nome em `${CLAUDE_SKILL_DIR}/modelos/`.

| Pergunta do formulário | Arquivo e seção |
|---|---|
| Como você começou como personal? Conte em poucas frases. | negocio.md, Minha história (curta) |
| Qual a sua formação e há quanto tempo você trabalha como personal? | negocio.md, Provas e resultados |
| Mais ou menos quantos alunos você já atendeu, somando tudo? | negocio.md, Números, alunos já atendidos |
| Quem você não quer atender? | aluno-ideal.md, Quem não é meu aluno |
| Que frases os seus alunos repetem muito? | aluno-ideal.md, Linguagem que ele usa, uma frase por item, entre aspas, sem nome de aluno |
| Você já tem um método próprio? | metodo.md, Pistas encontradas nos seus arquivos (ex.: "tem um jeito próprio, mas sem nome") |
| Se tem, qual o nome do método e quais são as etapas? | metodo.md, Pistas encontradas nos seus arquivos, como veio |
| Como está a sua oferta de consultoria online? | negocio.md, O que eu vendo, situação do Programa Personalizado online (a opção marcada; nunca escreva "consultoria") |
| De onde vêm os seus alunos hoje? | negocio.md, Como a venda acontece, de onde vêm os alunos |
| Em média, quantas pessoas te chamam por mês interessadas em treinar com você? | negocio.md, Como a venda acontece, pessoas interessadas por mês |
| Como a venda acontece, da primeira mensagem até o pagamento? | negocio.md, Como a venda acontece, da primeira mensagem até o pagamento |
| Em que momento da conversa de venda você mais trava? | negocio.md, Como a venda acontece, onde mais trava na conversa de venda. O que a pessoa interessada fala, entre aspas, também vai para aluno-ideal.md, Objeções |
| Por onde o aluno te paga? | negocio.md, Como a venda acontece, por onde o aluno paga (não mexe nas formas de pagamento de cada Produto) |
| Você tem página na internet para vender ou captar contatos? | negocio.md, Como a venda acontece, página na internet para vender ou captar contatos |
| Você faz anúncio pago hoje? | negocio.md, Como a venda acontece, anúncio pago |
| O seu perfil do Instagram é profissional? | negocio.md, Instagram, perfil profissional |
| Com que frequência você posta hoje? | negocio.md, Instagram, frequência de posts hoje |
| Escreva o @ de 3 perfis que você acompanha para se inspirar ou que são seus concorrentes. | negocio.md, Instagram, perfis de referência ou concorrentes, cada um com @ na frente |
| O que mais te trava na hora de produzir conteúdo? | negocio.md, Instagram, o que mais trava na hora de produzir conteúdo |
| Onde você controla seus alunos e as pessoas interessadas? | negocio.md, Rotina de trabalho, onde controla alunos e pessoas interessadas |
| Qual tarefa da sua semana toma mais tempo e você gostaria de parar de fazer na mão? | negocio.md, Rotina de trabalho, tarefa da semana que mais toma tempo |
| Como você monta um treino hoje, e quanto tempo leva cada um? | negocio.md, Rotina de trabalho, como monta um treino hoje e quanto tempo leva |
| Que informação você gostaria de receber no celular todo dia, sem precisar ir atrás? | negocio.md, Rotina de trabalho, informação que você quer receber no celular todo dia |

Estas não entram no segundo cérebro, e você pula sem comentar: "Qual computador você vai usar nos encontros?", "Como é a sua relação com o computador?", "Qual é o seu plano do Claude hoje?", "Quais ferramentas de inteligência artificial você já usa?", "Você tem conta no Telegram?", "Se só uma coisa ficasse funcionando no fim do Club, qual você escolheria?" e "Tem algo que pode atrapalhar você de acompanhar os encontros?".

## Passo 3. Marcar o que veio vago

Grave o que veio, com a marca "a confirmar" e o motivo curto, quando a resposta:
- não tem o número que a seção pede (preço "uns 600", "depende", duração "alguns meses");
- é genérica demais para uma skill usar (Ponto B "ficar bem", aluno "todo mundo");
- contradiz outra resposta (dois preços para o mesmo programa): guarde os dois e pergunte qual vale.

Exemplo: `- preço: R$ 600, a confirmar: no formulário veio "uns 600" (formulário do 100% IA Club, arquivo de respostas, 10/11/2026)`.

No perfil-profissional.md não existe marca: o campo vago fica vazio e vai para o "O que falta" do cabeçalho.

Depois de gravar, atualize o cabeçalho de cada arquivo: data, status ("em andamento" ou "completo") e "O que falta". No README.md: em "Arquivos já lidos", acrescente `formulário do 100% IA Club (<nome do arquivo, como respostas-maria-silva.txt>, dd/mm/aaaa)` (no arquivo antigo, `formulário pré-imersão (arquivo de respostas, dd/mm/aaaa)`); em Andamento, preencha `- Caminho: formulário` e marque `- [x] 2. Ler seus arquivos (formulário, dd/mm/aaaa)`, com a data de hoje (a data de "Enviado em" fica só nas fontes).

Status do perfil-profissional.md: "completo" quando só `aviso_juridico_lido` estiver vazio (esse campo é da skill de contrato).

## Passo 4. Mostrar o resumo

Uma mensagem só, em blocos curtos, cada item numerado, para a pessoa corrigir pelo número:

```
Li suas respostas e já preenchi o seu segundo cérebro. Confere:

Seus dados (vão para o contrato)
1. Carla Teste, CPF 000.000.000-00, CREF 000000-G/SC, Florianópolis/SC
2. Atendimento: WhatsApp, segunda a sexta das 7h às 19h, resposta em até 24 horas úteis
3. Treino no aplicativo MFIT, ajuste a cada 30 dias, primeiro treino em 3 dias úteis
4. Contrato: pausa de 30 dias, multa de 20%, vale a cidade do aluno

Seu negócio
5. Programa Leve e Forte: 3 meses, R$ 597, Pix ou cartão em até 6 vezes
...

Como o aluno chega e como você vende
...

Seu Instagram e sua rotina
...

Seu aluno ideal
...

Seu jeito de falar (eu deduzi dos seus textos, confere?)
...

Seus resultados
...

Ficou para confirmar: (lista curta do que veio vago)

Responda "tudo certo" ou corrija pelo número, tipo: "5 corrigir: é R$ 647".
```

Os blocos "Como o aluno chega e como você vende" e "Seu Instagram e sua rotina" só aparecem com o arquivo do Club. História, formação e alunos já atendidos entram no bloco "Seu negócio".

Correções: grave com Edit, fonte "(corrigido na conversa, dd/mm/aaaa)". Dedução confirmada perde a marca "a confirmar". Marque `- [x] 3. Confirmar o que foi entendido (dd/mm/aaaa)`.

## Passo 5. Arquivos que a pessoa trouxe

Pergunte uma vez: "Você trouxe os prints do Instagram, a logo, as fotos ou prints de depoimentos? Arrasta para a pasta arquivos e me avisa. Se não trouxe, a gente segue." Com arquivos, rode a Etapa 2 só para eles e confirme só o que for novo, como na Etapa 3. Logo e cores vão para identidade-visual.md, Pistas; fotos ficam em arquivos/ e são listadas em identidade-visual.md, Pistas; depoimento vira case com a autorização perguntada.

## Passo 6. Perguntar só as lacunas

Leia o "O que falta" de cada arquivo. Pergunte, uma por vez e com as perguntas da Etapa 4 (`${CLAUDE_SKILL_DIR}/etapas/4-entrevistar.md`), só o que é essencial e ficou vazio ou "a confirmar" (a lista de essenciais está em `${CLAUDE_SKILL_DIR}/etapas/essencial.md`, seção "O que é essencial"). Nunca pergunte o que o formulário já respondeu. Campos do contrato (`planos_por_mes`, `dias_pausa`, `multa_percentual`, `foro`): pergunte uma vez em grupinho; "não sei" deixa vazio, a skill de contrato pergunta na hora.

O que não é essencial e não veio (história, formação, números além dos alunos ativos, quem não é meu aluno, mais cases; no arquivo do Club, a maior parte disso já vem) não vira pergunta agora: grave na seção "a confirmar (completar no uso)" e ponha no "O que falta" do cabeçalho com "(completar no uso)".

Grave cada resposta na hora com Edit, fonte "(entrevista, dd/mm/aaaa)". Ao terminar, marque `- [x] 4. Entrevista do que faltou (lacunas do formulário, dd/mm/aaaa)` e vá para a Etapa 5 (teste do espelho). No fechamento dela, em "Ainda a confirmar", liste também os itens "(completar no uso)" e acrescente a linha de fechamento que está no fim de `essencial.md`.

## Modo atualizar pelo formulário

Para quem já tem a pasta brain e trouxe um arquivo do Club, curto ou completo. Não refaz a montagem, não roda a entrevista nem o teste do espelho, e não mexe no Andamento do README.md.

1. **Ler o brain.** Leia os arquivos .md da pasta (menos `arquivos/` e `contratos/`). Mostre o aviso de privacidade da Etapa 2 e siga a mesma regra de dado de aluno do Passo 1.
2. **Comparar.** Para cada resposta do arquivo, ache o destino nas tabelas do Passo 2 e compare com o que já está escrito lá. Pule, sem comentar, as perguntas que não entram no segundo cérebro. Resposta vazia não muda nada. Resposta que diz o mesmo que já está escrito, com outras palavras, também não.
3. **Mostrar o resumo.** Uma mensagem só, numerada, em dois blocos:

```
Li suas respostas do Club e comparei com o seu segundo cérebro.

O que é novo (vou acrescentar)
1. negocio.md, Como a venda acontece: os alunos vêm de indicação e do Instagram, sem anúncio
2. negocio.md, Instagram: perfis de referência @perfilum, @perfildois, @perfiltres
...

O que mudou (o valor antigo fica guardado)
7. negocio.md, Números, alunos ativos hoje: 18 (antes: 12)
...

Responda "tudo certo" ou corrija pelo número, tipo: "7 corrigir: são 16".
```

Bloco sem item não aparece. Se não houver nada novo, diga em uma linha que o seu segundo cérebro já estava em dia e pare.

4. **Esperar.** Só grave depois do "tudo certo" ou das correções. Item corrigido entra com o valor corrigido e a fonte "(corrigido na conversa, dd/mm/aaaa)". Item que a pessoa mandar tirar não é gravado.
5. **Gravar sem apagar.** Com Edit. O que é novo entra na seção, com a fonte do formulário. O que mudou: troque o valor e, logo abaixo, acrescente `- antes: <valor antigo> (até dd/mm/aaaa)`; preço segue a regra do Histórico de preços. No perfil-profissional.md, a linha do campo fica só com o valor novo, e o antigo vai para a lista Fontes no formato `- cref, valor anterior: <valor antigo> (até dd/mm/aaaa)`. Linha ou seção que não existe no arquivo da pessoa: acrescente no lugar em que está no modelo.
6. **Fechar.** Atualize o cabeçalho de cada arquivo alterado ("Última atualização" e "O que falta", tirando o que foi respondido). No README.md, em "Arquivos já lidos", acrescente `formulário do 100% IA Club (<nome do arquivo, como respostas-maria-silva.txt>, dd/mm/aaaa)`. Diga em uma linha: "Pronto: acrescentei X itens e atualizei Y no seu segundo cérebro."

# Etapa 5. Teste do espelho

Tempo no encontro: de 10 a 15 minutos.

## Passo 1. Escrever a legenda

Leia voz.md, aluno-ideal.md e negocio.md. Escreva uma legenda curta de Instagram (de 4 a 8 linhas) usando SÓ o que está nesses arquivos:
- fala com o aluno ideal, sobre uma dor ou desejo dele que está em aluno-ideal.md;
- usa expressões e o jeito de chamar o aluno que estão em voz.md;
- fecha com uma chamada simples para o produto principal de negocio.md (sem preço, a não ser que a pessoa use preço nas legendas dela);
- não inventa número, resultado ou história que não esteja nos arquivos.

Filtro antes de mostrar:
- sem travessão e sem emoji;
- sem estas palavras: descubra, transforme sua vida, imagine poder, desbloqueie, eleve, jornada, mergulhe, revolucione;
- sem "não é X, é Y" repetido, sem três itens em sequência por costume, sem frases curtas empilhadas uma atrás da outra.

## Passo 2. Perguntar

Mostre a legenda e pergunte só: **Isso parece você?**

## Passo 3. Ajustar

- "Sim": marque no README.md `- [x] 5. Teste do espelho (dd/mm/aaaa)` e grave a legenda aprovada em voz.md, em "Textos reais meus", com a fonte "(teste do espelho aprovado, dd/mm/aaaa)".
- "Não" ou "mais ou menos": pergunte o que soou estranho ("Qual parte não parece você?"). Grave a correção em voz.md, seção "Ajustes do teste do espelho" (ex.: "não uso 'mulherada', uso 'meninas'"; "escrevo mais curto"). Reescreva a legenda e pergunte de novo. No máximo 3 voltas; se ainda não parecer, peça mais 2 textos reais e tente de novo.

## Fechamento da montagem

```
Pronto: seu segundo cérebro está montado.
Ficou em: <caminho completo da pasta, ex.: /Users/ana/brain no Mac, C:\Users\ana\brain no Windows, /home/ana/brain no Linux>
Completo: perfil, negócio, aluno ideal, voz.
Ainda a confirmar: (lista curta, se houver)
Daqui para frente, quando tiver novidade (preço novo, depoimento, produto), diga "atualiza meu cérebro com isso" e cole.
```

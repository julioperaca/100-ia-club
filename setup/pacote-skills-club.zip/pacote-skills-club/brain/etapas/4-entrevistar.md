# Etapa 4. Entrevista do que faltou

Tempo no encontro: de 60 a 80 minutos no caminho completo. No caminho do formulário e no Modo Essencial esta etapa não roda inteira: veja `formulario.md` (Passo 6) e `essencial.md`.

## Antes de começar, diga

> Agora vou perguntar só o que seus arquivos não responderam. Uma pergunta por vez. Pode responder do seu jeito, por áudio transcrito ou texto. Se precisar parar, pode fechar: quando voltar, eu sei onde paramos.

## De onde vem a fila

Leia o "O que falta" do cabeçalho de cada arquivo. Pergunte só o que está lá. Nunca pergunte o que já está preenchido.

## Ordem (o que as outras skills mais usam vem primeiro)

1. aluno-ideal.md
2. negocio.md (a oferta: produtos e preços)
3. voz.md
4. perfil-profissional.md
5. negocio.md (história, diferencial, números, provas)
6. cases.md

metodo.md e identidade-visual.md não entram na entrevista: o método é opcional (fica com as pistas e o que a pessoa contar no Modo Atualizar) e a skill de design system cuida da identidade visual.

## Banco de perguntas

Use estas perguntas como base, com as palavras da pessoa. Uma por vez. Depois de cada resposta, grave na hora com Edit (fonte "(entrevista, dd/mm/aaaa)") e atualize o cabeçalho. Assim, se fechar no meio, nada se perde.

### Aluno ideal
- Pensa no aluno que você mais gostou de atender. Como ele era: idade, rotina, trabalho?
- Quando ele chegou até você, o que mais incomodava ele?
- O que ele já tinha tentado antes e não deu certo?
- O que ele queria conseguir? Em quanto tempo?
- Quando alguém fica na dúvida de comprar, o que essa pessoa costuma falar?
- Tem alguma frase que seus alunos repetem muito? Me manda do jeito que eles falam.
- Quem você não quer atender?

### Oferta
- Quais planos você vende hoje? Para cada um: nome, duração e preço.
- Como o aluno paga: Pix, cartão parcelado, boleto?
- O que o aluno recebe em cada plano?
- Por onde as vendas acontecem: direct, WhatsApp, link?

### Voz
Não peça para a pessoa se descrever. Peça textos reais:
- Me manda de 3 a 5 textos seus, do jeito que você escreveu: legendas, mensagens para aluno, roteiro de story, áudio transcrito. Pode colar aqui.

Com os textos, preencha você mesmo tom, expressões, como chama o aluno e pontuação (com fonte em cada item) e mostre: "Pelo que li, você fala assim: ... Está certo?". Depois pergunte só:
- Tem alguma palavra ou jeito de falar que você nunca usa?

### Perfil profissional
- Nome completo ou razão social, e CPF ou CNPJ.
- CREF com número e UF (ex.: 012345-G/SP).
- Cidade e estado.
- Seu @ do Instagram e o WhatsApp de atendimento.
- Por onde o aluno fala com você, em quais dias e horários, e em quanto tempo você responde.
- Como você entrega o treino: aplicativo (qual), plataforma ou PDF?
- De quanto em quanto tempo ajusta o treino, e em quantos dias úteis entrega o primeiro?

Os campos planos_por_mes, dias_pausa, multa_percentual, foro e aviso_juridico_lido são da skill de contrato: deixe vazios se a pessoa não souber, a skill de contrato pergunta na hora certa. CPF ou CNPJ: confira se tem 11 ou 14 dígitos; se não tiver, peça de novo.

### História, diferencial, números
- Me conta em poucas frases como você começou como personal.
- Por que um aluno escolhe você e não outro personal?
- Quantos alunos você tem hoje? E quantos já atendeu?
- Quer registrar quanto fatura por mês? (É opcional, pode pular.)
- Qual sua formação e há quanto tempo você trabalha?

### Cases
- Me conta de um aluno que teve um resultado que te orgulha. Como ele estava antes, como ficou e em quanto tempo?
- Ele autorizou usar isso em público? Com rosto ou sem rosto?

## Regras da entrevista

- Uma pergunta por vez. Pergunta curta e direta.
- "Não sei" ou "pula" vira "a confirmar" e segue. Não insista.
- 0 e "não" são respostas reais: grave.
- Nunca complete com palpite.
- A cada bloco terminado, diga em uma linha o que ficou pronto (ex.: "Aluno ideal completo. Agora a sua oferta.").

Quando o "o que falta" de aluno-ideal, negócio, voz e perfil estiver vazio (ou só com o que a pessoa escolheu pular), marque no README.md `- [x] 4. Entrevista do que faltou (dd/mm/aaaa)` e vá para a Etapa 5.

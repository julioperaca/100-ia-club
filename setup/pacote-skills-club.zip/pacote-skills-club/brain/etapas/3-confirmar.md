# Etapa 3. Confirmar

Tempo no encontro: 30 minutos no caminho completo; de 5 a 10 minutos no Modo Essencial (só o que veio dos arquivos trazidos).

## Como mostrar

Um arquivo por vez, nesta ordem: perfil profissional, negócio, aluno ideal, voz, cases, pistas de método e de visual. Para cada um, uma lista numerada em linguagem simples, cada item com a fonte:

```
Seu negócio. Entendi isto:

1. Você vende o Programa Seca em 3 meses por R$ 597 (apresentacao.pdf, página 2)
2. Também vende o plano de 6 meses por R$ 997 (apresentacao.pdf, página 2)
3. Você atende só mulheres (bio.txt)

Para cada número, responda: certo, corrigir (e diga o certo) ou descartar.
Pode responder tudo junto, tipo: "1 certo, 2 corrigir: é 1.097, 3 certo".
```

Itens marcados como dedução aparecem com "(eu deduzi, confere?)".

Em cases, pergunte a autorização de cada um: "A Fulana autorizou usar o depoimento dela em público? Com rosto ou sem rosto?". Sem autorização: o case fica sem nome e com "autorização para uso público: não".

## Gravar

- Certo: grava no arquivo, na seção certa, com a fonte entre parênteses.
- Corrigir: grava o valor corrigido com a fonte "(corrigido na conversa, dd/mm/aaaa)".
- Descartar: não grava. Se era um campo importante, vira pergunta na Etapa 4.

No perfil-profissional.md, grave só o valor depois dos dois pontos (ex.: `- cref: 012345-G/SC`) e coloque a fonte na lista Fontes do fim do arquivo, no formato `- cref, fonte: arquivos/bio.txt` (com vírgula depois do nome do campo). Isso mantém o arquivo legível pela skill de contrato.

Use Edit para preencher (nunca reescreva o arquivo inteiro com Write se ele já tem conteúdo).

Depois de cada arquivo, atualize o cabeçalho: data, status (em andamento ou completo) e "o que falta" (lista curta das seções ou campos vazios). Marque no README.md `- [x] 3. Confirmar o que foi entendido (dd/mm/aaaa)` quando terminar todos.

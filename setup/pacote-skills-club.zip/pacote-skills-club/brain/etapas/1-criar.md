# Etapa 1. Criar a pasta

Tempo no encontro: 10 minutos.

## Passo 1. Achar a pasta de casa

Rode `echo "$HOME"` com Bash. No Mac sai algo como `/Users/ana`. No Windows pode sair `/c/Users/ana`: para as ferramentas Read, Write e Edit use `C:\Users\ana`. A pasta do cérebro é `<casa>/brain` (se `CEREBRO_PATH` no SKILL.md estiver preenchido, use ele).

## Passo 2. Ver o que já existe

Use Glob em `<pasta>/*.md`.

- Pasta não existe: siga para o Passo 3.
- Pasta existe: NUNCA sobrescreva. Para cada arquivo da lista abaixo, crie só o que estiver faltando. Os que existem ficam como estão. Diga: "Sua pasta já existia. Mantive tudo e só criei o que faltava: X, Y." Depois leia o Andamento do README.md e siga de onde parou.

## Passo 3. Criar os arquivos

Leia cada modelo e grave com Write, trocando `[data de hoje]` pela data de hoje (dd/mm/aaaa):

| Modelo | Vira |
|---|---|
| `${CLAUDE_SKILL_DIR}/modelos/README.md` | `<pasta>/README.md` |
| `${CLAUDE_SKILL_DIR}/modelos/perfil-profissional.md` | `<pasta>/perfil-profissional.md` |
| `${CLAUDE_SKILL_DIR}/modelos/negocio.md` | `<pasta>/negocio.md` |
| `${CLAUDE_SKILL_DIR}/modelos/aluno-ideal.md` | `<pasta>/aluno-ideal.md` |
| `${CLAUDE_SKILL_DIR}/modelos/voz.md` | `<pasta>/voz.md` |
| `${CLAUDE_SKILL_DIR}/modelos/metodo.md` | `<pasta>/metodo.md` |
| `${CLAUDE_SKILL_DIR}/modelos/identidade-visual.md` | `<pasta>/identidade-visual.md` |
| `${CLAUDE_SKILL_DIR}/modelos/cases.md` | `<pasta>/cases.md` |
| `${CLAUDE_SKILL_DIR}/modelos/arquivos-leia-me.md` | `<pasta>/arquivos/_leia-me.md` |
| `${CLAUDE_SKILL_DIR}/modelos/contratos-leia-me.md` | `<pasta>/contratos/_leia-me.md` |

O Write cria as subpastas sozinho. Não precisa de mkdir.

Se já existir um `perfil-profissional.md` em `<casa>/meu-negocio/` (criado antes pela skill de contrato), copie os valores dele para o novo perfil e avise.

## Passo 4. Abrir a pasta arquivos para a pessoa

- Mac: `open "<pasta>/arquivos"`
- Windows: `cmd //c start "" "C:\Users\<nome>\brain\arquivos"`
- Linux: `xdg-open "<pasta>/arquivos"`
- Se o comando falhar, só mostre o caminho.

Diga, em texto simples:

> Criei sua pasta brain e abri a pasta arquivos. Arraste para lá o que você já tem: bio do Instagram (print ou texto), legendas que você gosta, apresentação do seu Programa Personalizado, tabela de preços, prints de depoimentos de quem autorizou. Não precisa organizar. Se preferir, cole aqui na conversa. Me avisa quando terminar.

No caminho do formulário, troque o fim da mensagem por "Se trouxe arquivos, arraste agora; eu leio depois das suas respostas." e não espere a pessoa juntar os arquivos: siga direto para `${CLAUDE_SKILL_DIR}/etapas/formulario.md` (os arquivos trazidos são lidos no Passo 5 dela).

Marque no README.md: `- [x] 1. Criar a pasta (dd/mm/aaaa)`.

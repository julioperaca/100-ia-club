# Modo Essencial

Para quem não trouxe o arquivo do formulário. Monta só o que as outras skills precisam para funcionar. O resto fica marcado "completar no uso".

Meta: de 60 a 75 minutos no total.

| Passo | O que é | Tempo |
|---|---|---|
| 1 | Etapa 1, criar a pasta | 10 min |
| 2 | Etapa 2 e Etapa 3, só com o que a pessoa trouxe (prints, logo, fotos, depoimentos). Sem arquivos, pule | 10 a 15 min |
| 3 | Entrevista essencial (abaixo) | 25 a 35 min |
| 4 | Etapa 5, teste do espelho | 10 a 15 min |

No README.md, em Andamento, preencha `- Caminho: essencial`.

## O que é essencial

É o mínimo para cada skill rodar sem travar:

| Arquivo | Essencial | Quem precisa |
|---|---|---|
| perfil-profissional.md | os 17 campos (todos menos `aviso_juridico_lido`, que é da skill de contrato) | contrato |
| negocio.md | cada programa com nome, duração, preço, formas de pagamento e o que está incluído | copy, conteúdo |
| aluno-ideal.md | Quem é, Ponto A (com o que já tentou), Ponto B (com prazo) e Objeções | conteúdo (com o modo Espiar), copy |
| voz.md | de 2 a 3 textos reais em "Textos reais meus" e "O que eu nunca digo" | conteúdo (sem texto real ela não escreve), copy |

Fica para "completar no uso": história, diferencial, formação, números (além dos alunos ativos), como a venda acontece, linguagem do aluno, quem não é meu aluno, cases, tom detalhado. Cada skill que precisar de um desses itens vai encontrar "a confirmar" e perguntar na hora. Para guardar a resposta no cérebro, a pessoa diz "atualiza meu cérebro com isso".

## A entrevista essencial

Antes de começar, diga:

> Como você não respondeu o formulário, vou fazer só as perguntas que as outras skills precisam. Umas 13, leva uns 30 minutos. O resto a gente completa quando for usar.

Pule o que os arquivos já responderam. Grave cada resposta na hora com Edit, fonte "(entrevista, dd/mm/aaaa)", e atualize o cabeçalho. Nos dados profissionais pode mandar o grupinho numa mensagem só (a pessoa responde tudo junto); no resto, uma pergunta por vez.

Dados profissionais (perfil-profissional.md, só o valor; fonte na lista Fontes):
1. "Me manda numa mensagem: nome completo ou razão social, CPF ou CNPJ, CREF com número e estado, e a cidade e estado onde você trabalha." (confira 11 ou 14 dígitos no CPF ou CNPJ e a UF no CREF)
2. "Agora: o nome pelo qual seus alunos te conhecem, seu @ do Instagram e o WhatsApp de atendimento com DDD."
3. "Por onde o aluno fala com você, em quais dias e horários, em quanto tempo você responde, e como ele recebe o treino (qual aplicativo, plataforma ou PDF)?"
4. "De quanto em quanto tempo você ajusta o treino, e em quantos dias úteis entrega o primeiro depois da avaliação?" (15 dias = `planos_por_mes` 2; 30 dias = 1; outra resposta deixa vazio)
5. "Três regras do contrato. Se não souber, diga não sei: por até quantos dias o aluno pode pausar, qual a multa se ele cancelar no meio, e se vale a cidade dele ou a sua se precisar ir para a justiça."

O que você vende (negocio.md):
6. "Quais programas você vende hoje? Para cada um: nome, duração, preço, em até quantas vezes e o que o aluno recebe."
7. "Como o aluno pode pagar: Pix, cartão parcelado, cartão recorrente, boleto?"

Para quem (aluno-ideal.md):
8. "Pensa no aluno que você mais gosta de atender. Como ele é: idade, rotina, trabalho?"
9. "Quando ele chega até você, o que mais incomoda? E o que ele já tentou antes que não deu certo?"
10. "O que ele quer conseguir, e em quanto tempo?"
11. "Quando alguém fica na dúvida de comprar, o que essa pessoa fala?"

Como você fala (voz.md):
12. "Cola aqui 2 ou 3 textos seus do jeito que escreveu: legenda, mensagem para aluno ou roteiro de story." Com os textos, preencha Tom, Como eu chamo o aluno e Emoji, gírias e pontuação, com fonte, e mostre: "Pelo que li, você fala assim: ... Está certo?"
13. "Tem alguma palavra ou jeito de falar que você nunca usa?"

"Não sei" e "pula" valem: o campo fica vazio (perfil) ou "a confirmar" (os outros). Não insista.

## Marcar o que ficou para depois

Em cada seção não essencial que ficou vazia, escreva `a confirmar (completar no uso)`. No cabeçalho de cada arquivo, em "O que falta", liste essas seções com "(completar no uso)" no fim, ex.: `> O que falta: Minha história, Meu diferencial, Números (completar no uso)`. Status: "em andamento".

Marque no README.md `- [x] 4. Entrevista do que faltou (essencial, dd/mm/aaaa)` e vá para a Etapa 5.

No fechamento da Etapa 5, acrescente uma linha:

```
Ficou para completar no uso: (lista curta). Quando outra skill perguntar, responda e diga "atualiza meu cérebro com isso". Se quiser completar tudo de uma vez em casa, rode /brain completo (leva cerca de 3 horas).
```

# conteudo

Skill para o personal trainer espiar perfis de referência, decidir o que postar e transformar o texto pronto em imagem, com as cores e fontes da marca. Sem Canva, sem chave de API e sem instalar nada. Quem escreve o texto do post é a skill `copy`.

## Como usar

| Você quer | Digite |
|---|---|
| Analisar o perfil de um concorrente ou de uma referência | `/conteudo espiar @perfil` (ou "analisa esse perfil") |
| Comparar até 3 perfis | `/conteudo espiar @perfil1 @perfil2` |
| Saber o que postar na semana | `/conteudo pauta da semana` |
| A pauta de um post só | `/conteudo pauta: tema` |
| Escrever o texto da pauta | `/copy` (outra skill) |
| Gerar as imagens do texto pronto | `/conteudo montar` |

O caminho completo de um post: `/conteudo espiar` (opcional), `/conteudo` (pauta), depois `/copy` (texto), depois `/conteudo montar` (imagens).

## Antes

A skill `brain` precisa ter rodado. Se o seu método estiver no `metodo.md` do brain, cada pauta e cada ideia se liga a um pilar do seu método e a um inimigo comum. Com o `/design-system` pronto, as imagens saem com as suas cores e fontes; sem ele, saem num visual neutro.

## O que ela faz

**Modo Espiar.** Tenta ler a página pública do perfil pelo link; se o Instagram bloquear (o normal), pede prints. Analisa posicionamento, oferta, temas, formatos, ganchos, estrutura de carrossel e reels, frequência e tom (só chama de padrão o que se repete em 3 posts ou mais). Compara com o seu cérebro: o que você pode aproveitar, o que não combina com a sua voz e o espaço que ela deixa vazio. Entrega 5 ideias de post com gancho e salva tudo em `brain/espiao/AAAA-MM-DD-@perfil.md`. No fim, oferece transformar as ideias na pauta da semana. Só analisa conteúdo público; o objetivo é aprender os padrões, não copiar.

**Modo Pauta.** Lê sua aluna ideal, seu método e o momento do negócio e monta 5 pautas da semana (ou uma só), do jeito que o Peraça ensina: tema que a aluna deseja, ligado a um pilar ou inimigo comum, com objetivo, formato e o porquê. Pode partir das ideias do Espiar. Grava cada pauta escolhida em `brain/conteudo/AAAA-MM-DD-tema/pauta.md`.

**Modo Montar.** Lê o `texto.md` que o `/copy` gravou na mesma pasta e gera:
- carrossel: `slide-01.png` a `slide-NN.png` (1080 x 1350);
- post único: `post.png` (1080 x 1350);
- reels: `capa-reels.png` (1080 x 1920);
- stories: `story-01.png` em diante (1080 x 1920), com espaço marcado para a figurinha.

**Meus modelos.** `/conteudo meus modelos` monta o seu banco de modelos, uma página que abre no navegador com os 7 modelos do Club nas suas cores, os modelos que você criou e os posts que já fez. `/conteudo novo modelo:` com o print de um post cria um modelo seu. Tudo fica em `brain/meus-modelos/`, e não some quando a skill é atualizada.

## Instalação

Copie a pasta `conteudo` para `~/.claude/skills/` (no Windows, `C:\Users\<nome>\.claude\skills\`).

## Arquivos da skill

| Arquivo | Para quê |
|---|---|
| `SKILL.md` | entrada, os modos, contrato com o segundo cérebro, regras |
| `etapas/espiar/1-coletar.md` a `etapas/espiar/4-ideias-e-salvar.md` | Modo Espiar, em 4 etapas |
| `etapas/1-pauta.md` | Modo Pauta |
| `etapas/2-montar.md` | Modo Montar |
| `etapas/3-meus-modelos.md` | banco de modelos e modelo novo |
| `referencias/metodo-de-analise.md` | o que olhar num perfil, como medir engajamento, tipos de gancho, quando é padrão |
| `referencias/jeito-do-peraca.md` | como o Peraça pensa conteúdo: tipos, objetivos, formatos, frequência, capa |
| `referencias/formatos.md` | os 7 modelos de post e as regras de todos (anúncio ou vitrine, prova com print, imagens) |
| `referencias/formato-do-texto.md` | o formato do `texto.md` combinado com a skill copy |
| `modelos/relatorio-espiao.md` | formato da análise salva pelo Modo Espiar |
| `modelos/pauta.md` | formato de cada pauta |
| `modelos/carrossel.html` | motor do carrossel e do post único (só o bloco DADOS muda) |
| `modelos/banco-de-modelos.html` | página do banco de modelos (só o bloco DADOS muda) |
| `modelos/meu-modelo.md` | formato de cada modelo criado pela pessoa |
| `modelos/vertical.html` | motor da capa de reels e dos stories (só o bloco DADOS muda) |

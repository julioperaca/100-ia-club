# Etapa 1. Entrevista

Cerca de 15 minutos. Uma pergunta por vez (ou duas que andam juntas), sempre com sugestão. A pessoa pode responder "pode ser" em qualquer uma. Se ela disser "não sei", use a sugestão e siga.

Antes da primeira pergunta, leia em silêncio o que o brain tiver (`perfil-profissional.md`, `negocio.md`, `voz.md`, `identidade-visual.md`). Não pergunte o que já está lá: confirme.

## Abertura

Mostre o que já sabe, em lista curta, e explique o caminho:

> Vou montar o seu painel de gestão: alunos, renovações, agenda, dinheiro e o que fazer em cada dia. Li o seu brain e já sei isto:
> - <nome público>, <@instagram>
> - Planos: <planos com duração e preço, se houver>
> - Cerca de <N> alunos
> - Suas cores: <nome das cores>, fontes <título> e <texto> (ou: "ainda sem identidade visual, vou usar um visual neutro")
>
> São umas 12 perguntas rápidas, em 6 blocos. Em todas eu dou uma sugestão, e você pode responder só "pode ser". Vamos?

## Bloco 1. Sua carteira hoje

1. Se o brain não disser: "Quantos alunos ativos você tem hoje? Desses, quantos são presenciais e quantos são online? Pode ser aproximado."
2. "Onde ficam os dados deles hoje?" Opções: planilha, MFIT ou outro aplicativo de treino, formulário de cadastro (o mesmo do /contrato), WhatsApp, caderno, na cabeça. Pode ser mais de uma.

Anote o caminho de importação que combina (planilha, formulário de recadastro, leitura pelo Chrome no aplicativo de treino, ou digitar pelo botão "+ Aluno"). Não importe agora: hoje o painel nasce com os exemplos.

## Bloco 2. O que se repete

3. "Qual tarefa você faz toda semana e não gosta de fazer?" Dê exemplos: cobrar renovação, lembrar de trocar treino, responder a mesma dúvida, montar a agenda, conferir quem pagou.
4. "E o que você já esqueceu de fazer e acabou perdendo aluno ou dinheiro?"

Cada resposta vira um aviso no "Foco de hoje", uma tarefa fixa ou uma ideia na aba Mais. Diga em uma linha onde ela vai aparecer.

## Bloco 3. Os avisos

5. "Vou te avisar das renovações assim: atenção 30 dias antes, urgente 7 dias antes. Pode ser?" (`atencao_dias`, `renovar_dias`)
6. "De quantas em quantas semanas você troca o treino? E quantos dias sem falar com um aluno já é sinal de que ele está sumindo? Eu sugiro avisar a troca 3 dias antes e considerar sumido depois de 10 dias." (`treino_dias`, `sumiu_dias`, e o intervalo em `treino_semanas`)

## Bloco 4. Os números e o dinheiro

7. "Qual a sua meta de faturamento por mês? Ela vira o anel no topo do painel." (`meta_mensal`). Sugestão, se a pessoa não souber: o que ela faturou no melhor mês, mais 20%.
8. "Como os alunos te pagam? E quando vende no cartão parcelado, o dinheiro cai uma parcela por mês ou a maquininha antecipa tudo?" Pix e dinheiro caem no dia. Boleto em 2 dias. Cartão: 30 dias por parcela, ou o prazo que ela disser (`cartao_dias`, `boleto_dias`).
9. "Quanto você tira do negócio por mês para a sua vida? Se não tiver um valor fixo, deixo em branco e você lança cada retirada quando fizer." Explique em uma linha: "O painel separa o que o negócio lucrou do que foi para você. No pessoal, entra só a retirada."

## Bloco 5. Os ritmos

10. Mostre a rotina pronta e peça para tirar ou acrescentar:

> - **Todo dia (10 min):** responder quem chamou, abrir conversa com quem vence, chamar quem sumiu, aniversários
> - **Toda semana (30 min):** atualizar alunos, pedir feedback do treino, conferir a agenda, baixar os dados do painel
> - **Todo mês (1 hora):** fechar o dinheiro do mês, listar as renovações do mês seguinte, pedir fotos de evolução
> - **Quando acontece:** aluno novo (cadastro, contrato, boas-vindas), pausa por lesão ou viagem, cancelamento com o motivo, renovação

O que ela mantiver vira tarefa de exemplo e vai para o plano de gestão.

## Bloco 6. As conversas prontas

11. Mostre os roteiros na voz dela (use o `voz.md`; sem voz, use o tom simples e caloroso). Siga `${CLAUDE_SKILL_DIR}/referencias/mensagens-que-abrem-conversa.md`:

> Agora a renovação. No painel ela é uma conversa, não um aviso de cobrança. O botão do WhatsApp manda só a abertura, e os passos seguintes aparecem no cartão do aluno para você usar depois que ele responder:
> 1. **Abrir:** "Oi, {nome}, tudo bem por aí?"
> 2. **Perguntar:** "{nome}, como você está se sentindo com os treinos? E com os resultados, com o nosso trabalho junto? Me conta um pouquinho mais, para eu ver quais pontos a gente pode melhorar."
> 3. **Acolher:** comentar o que ele contou. Exemplo: "Que legal que você está gostando, fico feliz. Temos muito trabalho pela frente ainda."
> 4. **Convidar:** "E aproveitando: o seu ciclo está para encerrar. Queria conversar com você sobre o próximo planejamento, para eu organizar o processo a médio e longo prazo, para os próximos {meses} meses."
>
> Troca de treino e aluno sumido seguem o mesmo caminho. Quer mudar alguma palavra para ficar mais com a sua cara?

12. Mostre a de aniversário (essa vai direta, é um parabéns) e pergunte se quer mudar.

## Gravar o plano

Crie a pasta do painel (e `backups/` dentro dela) se não existirem. Grave `<painel>/plano-de-gestao.md` seguindo `${CLAUDE_SKILL_DIR}/modelos/plano-de-gestao.md`. Diga em uma linha: "Anotei tudo no plano-de-gestao.md. Agora monto o painel." e siga para `${CLAUDE_SKILL_DIR}/etapas/2-montar.md`.

# Etapa 3. Ajustar o painel

A pessoa pede uma mudança em português. Você muda só aquilo, confere e abre.

## Qual arquivo

- Se existe `dashboard.html` (visual já escolhido): só ele.
- Se ainda existem os dois `dashboard-visual-*.html`: faça a mesma mudança nos dois, para continuarem iguais. Exceção: pedido que é sobre o desenho de um visual só ("no visual 2, a lateral mais clara").

## Passo a passo

1. **Entender.** Repita o pedido em uma linha, como você entendeu. Se der para entender de dois jeitos que mudam o resultado, pergunte qual (uma pergunta). Se não, siga.
2. **Backup.** Copie o arquivo para `backups/<nome>-AAAA-MM-DD-HHMM.html`.
3. **Mudar só o pedido.** Prefira mexer nos blocos de dados (NEGOCIO, TOKENS, SEMENTE: regras, mensagens, roteiros). Se o pedido exigir o motor (aba nova, campo novo, aviso novo), mude o mínimo e siga o estilo que já existe: mesmas classes de cartão (`card s4`, `s6`, `s12`), mesmos botões (`btn btn-p`, `btn btn-s`), formulário pela gaveta (`abrir(titulo, corpo, rodape)`), salvar com `salvar("mensagem")`.
4. **Dado novo no cadastro.** Campo novo entra no formulário do aluno (`formAluno`), aparece na ficha (`ficha`) e, se fizer sentido, num aviso do Foco de hoje (`acoes`). O que já está cadastrado continua: campo novo começa vazio.
5. **Conferir.** Releia o trecho mudado. Abra o arquivo no navegador.
6. **Contar.** Diga o que mudou em até 3 linhas e onde ver. Anote no `plano-de-gestao.md`, seção "Histórico": data e o pedido.

## Pedidos comuns e onde mexer

| Pedido | Onde |
|---|---|
| Mudar a meta | Pelo próprio painel (Hoje, "Mudar meta"). Ou `NEGOCIO.meta_mensal`. |
| Mudar prazos dos avisos ou do cartão | Pelo painel (Mais, Ajustes, Prazos). Ou `SEMENTE.regras`. |
| Mudar uma mensagem ou roteiro | Pelo painel (Mais, Ajustes, Mensagens prontas). Ou `SEMENTE.mensagens` e `SEMENTE.roteiros`. |
| Tirar uma aba | Lista `ABAS` no motor. |
| Trocar cores ou fontes | `TOKENS` (depois de rodar o /design-system de novo, se for o caso). |
| Novo grupo de despesa | `GRUPOS.Despesa` no motor. |

Atenção: o que a pessoa já mudou pelo próprio painel (meta, prazos, mensagens) fica salvo no navegador e vale por cima da SEMENTE. Se ela pedir pela conversa algo que já mudou pela tela, avise: "Você já tinha mudado isso pelo painel. Lá vale o que você salvou; mude pela tela em Mais, Ajustes."

## Mensagens e roteiros

Qualquer mensagem nova (pausa, volta de viagem, pedido de depoimento) segue `${CLAUDE_SKILL_DIR}/referencias/mensagens-que-abrem-conversa.md`: abre a conversa primeiro, o assunto vem depois.

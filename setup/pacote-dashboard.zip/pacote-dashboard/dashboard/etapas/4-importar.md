# Etapa 4. Trazer os alunos de verdade

Troca os exemplos pelos alunos reais. Os dados entram pelo bloco IMPORTACAO do painel: na próxima vez que a pessoa abrir, o painel acrescenta esses alunos uma vez só, sem apagar o que ela já cadastrou pela tela.

## 1. De onde vêm

Use o caminho anotado no `plano-de-gestao.md` (bloco 1). Ofereça do mais simples ao mais forte:

1. **O que já existe:** planilha (arraste o arquivo para a conversa ou diga onde está), foto do caderno, texto das notas, lista copiada do WhatsApp. Você organiza e pergunta só o que faltar.
2. **Formulário de recadastro:** se a pessoa usa o Formulário de Cadastro do /contrato, sugira duplicar com o título "Atualização de cadastro" e mandar para a lista de alunos. Quando as respostas chegarem, ela exporta a planilha e você lê.
3. **Pelo Chrome, no aplicativo de treino:** só se a extensão do Claude no Chrome estiver instalada e a pessoa abrir a lista de alunos do aplicativo logada. Você lê a tela e copia só nome, contato, plano e datas. Nada de anamnese ou dado de saúde. Nunca clique em apagar, desativar ou editar nada no aplicativo.

## 2. O que trazer de cada aluno

Campos do painel (use os que tiver; o resto fica vazio):
`nome`, `whatsapp` (só números, com DDD), `instagram`, `modalidade` ("Digital" ou "Presencial"), `plano` ("Mensal", "Trimestral", "Semestral", "Anual"), `valor_ciclo`, `duracao_meses`, `inicio_ciclo`, `fim_ciclo`, `troca_treino`, `frequencia` ("Assídua", "Mais ou menos", "Pouco"), `aniversario` ("MM-DD"), `objetivo` (curto, sem dado de saúde), `origem`, `status` ("Ativo" ou "Inativo"), `motivo_saida`, `forma_pagamento`, `parcelas`.

Datas sempre "AAAA-MM-DD". Sem `fim_ciclo`, calcule pelo início mais a duração. Sem início nem fim, pergunte: "Quando vence o plano da <nome>?" (uma pergunta por aluno que faltar, ou uma lista com todos de uma vez se forem muitos).

Mostre a lista final em tabela curta (nome, plano, vence em) e peça o "ok" antes de gravar.

## 3. Lançamentos (opcional)

Se a pessoa quiser trazer o dinheiro dos últimos meses, cada linha do `financeiro` tem:
`data` (quando caiu ou saiu), `data_venda`, `descricao`, `tipo` ("Receita" ou "Despesa"), `categoria` ("Profissional" ou "Pessoal"), `grupo`, `forma`, `parcela` ("2/6" ou ""), `valor`, `recorrente` (true para conta fixa).
Grupos de receita: "Plano ou mensalidade", "Avaliação ou avulso", "Outra entrada". Grupos de despesa: "Imposto", "Taxa da plataforma ou maquininha", "Aplicativos e ferramentas", "Anúncios", "Equipamento e cursos", "Retirada para você", "Moradia", "Mercado", "Transporte", "Saúde e academia", "Lazer", "Outra saída".

## 4. Gravar

1. Backup do arquivo do painel (ou dos dois visuais) em `backups/`.
2. Troque o bloco IMPORTACAO por:
```js
const IMPORTACAO = { id: "<AAAA-MM-DD-HHMM>", alunos: [ ... ], financeiro: [ ... ] };
```
O `id` é sempre novo a cada importação. Importação nova substitui a lista do bloco (os alunos da anterior já estão no navegador).
3. Nos dois visuais, se ainda existirem, o mesmo bloco.
4. Abra o painel. Diga: "Abri o painel. Os seus <N> alunos entraram. Agora, se quiser, clique em Apagar exemplos no topo para ficar só com os seus."
5. Anote no `plano-de-gestao.md`, seção "Histórico": data, quantos alunos, de onde vieram.

## Cuidado com dados

A planilha ou os prints podem ter CPF, endereço e dado de saúde. Esses campos não entram no painel. Não copie a planilha para a pasta do painel nem para o brain.

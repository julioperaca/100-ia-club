# Etapa 2. Montar os dois visuais

O modelo é `${CLAUDE_SKILL_DIR}/modelos/dashboard.html`. Ele já funciona inteiro, com uma personal de exemplo (Carla). Você troca só os blocos de dados, no topo do `<script>`. O motor (do comentário `MOTOR` para baixo) não é editado na montagem.

## 1. Copiar o modelo

Copie o modelo para `<painel>/dashboard-visual-1.html`. Se o arquivo já existir, antes mova o antigo para `backups/`.

## 2. Trocar os blocos (Edit, um por vez)

**VISUAL**
```js
const VISUAL = { modelo: 1, outro: "dashboard-visual-2.html" };
```

**NEGOCIO**
```js
const NEGOCIO = { nome: "<nome completo ou público>", marca: "<nome da marca, ex.: Carla Personal>", ddi: "55", meta_mensal: <meta, número sem pontos> };
```
`marca` é o que aparece no logo e dá nome aos dados no navegador. Depois de montado, não mude a marca sem avisar: se mudar, o painel abre vazio (os dados ficam guardados com o nome antigo). Se a pessoa pedir para mudar, explique isso e ofereça trazer os dados pelo "Baixar meus dados" e a Etapa 4.

**TOKENS**: copie do bloco `json` do `identidade-visual.md`:
```js
const TOKENS = {
  cores: {primaria:"…",secundaria:"…",destaque:"…",fundo:"…",fundo_alternativo:"…",texto:"…",texto_suave:"…",texto_sobre_primaria:"…",texto_sobre_secundaria:"…"},
  fontes: {titulo:{familia:"…"},texto:{familia:"…"},google_fonts:"<link do google_fonts>"},
  raios: {medio:"<raios.medio>"}
};
```
Sem identidade visual, mantenha o bloco do modelo (neutro, grafite e areia) e avise no fim.

Confira o contraste: o `fundo` precisa ser claro e o `texto` escuro. Se a identidade da pessoa tiver fundo escuro, use `fundo_alternativo` claro ou um tom bem claro da primária no `fundo` e diga isso em uma linha.

**SEMENTE**: só estes campos mudam; os exemplos (alunos, financeiro, agenda, tarefas) ficam como estão, marcados com `exemplo:true`:
- `regras`: `{renovar_dias, atencao_dias, treino_dias, treino_semanas, sumiu_dias, cartao_dias, boleto_dias}` com as respostas dos blocos 3 e 4. `treino_semanas` é o intervalo entre as trocas: o botão "Treino feito" marca a próxima troca para daqui a esse número de semanas.
- `mensagens`: `renovar`, `treino`, `sumiu` = a abertura aprovada (padrão "Oi, {nome}, tudo bem por aí?"); `aniversario` = o parabéns aprovado.
- `roteiros`: `renovar`, `treino`, `sumiu`, cada um uma lista com os passos 2, 3 e 4 aprovados. O passo de acolher começa com "Acolha o que ele contou." (o painel mostra esse passo sem botão de copiar).
- `tarefas`: troque os títulos de exemplo pelas tarefas da rotina que a pessoa manteve no bloco 5 (até 4, mantendo `exemplo:true` e as colunas "A fazer", "Fazendo", "Feito").
- Retirada mensal (bloco 4, pergunta 9): se a pessoa deu um valor, troque o `valor` das linhas de exemplo com `grupo: "Retirada para você"` por esse valor. Se não deu, mantenha.

Marcadores aceitos nos textos: `{nome}` (primeiro nome do aluno), `{dias}` (dias que faltam), `{meses}` (duração do plano do aluno).

## 3. O visual 2

Copie o `dashboard-visual-1.html` pronto para `dashboard-visual-2.html` e troque só o bloco VISUAL:
```js
const VISUAL = { modelo: 2, outro: "dashboard-visual-1.html" };
```

## 4. Conferir antes de mostrar

1. Leia de volta os blocos trocados nos dois arquivos: aspas fechadas, vírgulas entre os itens, chaves e colchetes fechados.
2. Procure sobras do exemplo onde devia estar a pessoa: `Carla Menezes`, `Carla Personal`, `meta_mensal: 3000` (se a meta dela for outra).
3. Se houver navegador sem interface no computador (Chrome), você pode tirar um print para conferir; se não, siga.

## 5. Abrir e explicar

Abra os dois arquivos no navegador (Mac: `open`; Windows: `Start-Process`). Depois diga, curto:

> Pronto. Abri o seu painel em dois visuais, com as suas cores:
> - **Visual 1:** menu em abas no topo.
> - **Visual 2:** menu na lateral esquerda.
>
> Os dois usam os mesmos dados: o que você cadastrar num aparece no outro. Tudo o que tem a etiqueta EXEMPLO é de mentira, para você ver funcionando. Quando quiser, o botão "Apagar exemplos" no topo tira todos de uma vez.
>
> Teste os dois esta semana e me diga "/dashboard fico com o visual 1" (ou 2).
>
> Uma coisa importante: o que você cadastra fica salvo neste navegador, neste computador. Uma vez por semana, use "Baixar meus dados" (aba Mais, Ajustes).

Feche com 3 sugestões de pedido tiradas das respostas da entrevista, no formato de frase pronta. Exemplos:
- "/dashboard põe um aviso quando a aluna presencial faltar 2 vezes seguidas"
- "/dashboard acrescenta pausa no cadastro do aluno, com a data de volta"
- "/dashboard troca os exemplos pelos meus alunos" (leva para a Etapa 4)

Anote no `plano-de-gestao.md`, seção "Histórico": data, "painel montado nos dois visuais".

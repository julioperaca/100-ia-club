# Etapa 5. Colocar no ar, com login

Só quando a pessoa pedir. Não é tarefa do Club: cada um faz no seu tempo, e as dúvidas vão para o encontro seguinte.

## O que muda para ela (explique antes, em 4 linhas)

> Hoje o painel mora no seu navegador. Colocando no ar:
> - ele abre no computador e no celular, num endereço seu;
> - cada pessoa entra com e-mail e senha;
> - você pode convidar alguém da equipe, que vê alunos, agenda, renovações e tarefas, mas não vê o Dinheiro;
> - os dados ficam num banco de dados, e não somem se você limpar o navegador.
>
> Custa R$ 0 no começo. O único gasto possível é o domínio próprio (cerca de R$ 40 por ano), se você quiser um.

Peça o "pode" antes de seguir.

## As três peças

1. **Banco de dados com login: Supabase**, plano free. Atenção: no plano free, o projeto "dorme" depois de 7 dias sem ninguém usar. Uso diário resolve; se dormir, é só entrar no site do Supabase e clicar em "Restore".
2. **Endereço das telas: Netlify** (ou Cloudflare Pages), plano free, que permite uso comercial. Não use a Vercel no plano free: ela é só para uso pessoal, não comercial.
3. **Domínio próprio, opcional:** um .com.br no registro.br, com o CPF ou o CNPJ da pessoa. Quem já tem site usa um subdomínio sem pagar nada a mais (por exemplo `gestao.seusite.com.br`).

A pessoa cria as contas, aceita os termos e paga. Você guia cada clique, uma tela por vez, e espera ela dizer "pronto".

## Chaves

- A chave pública do Supabase (anon key) e o endereço do projeto podem ir no arquivo do painel.
- A chave secreta (service_role) nunca passa pela conversa e nunca entra no painel. Se precisar dela para criar as tabelas, peça para a pessoa colar num arquivo `.env` na pasta do painel, que você lê sem mostrar, ou para ela rodar o SQL no próprio Supabase (SQL Editor) com o texto que você entrega.

## Estrutura do banco

Três tabelas, todas com trava de acesso (RLS) ligada:
- `membros (usuario uuid, papel text)`: quem entra e o papel, "dono" ou "colaborador". A primeira conta criada é a dona.
- `painel (id int, dados jsonb, atualizado timestamptz)`: uma linha com alunos, agenda, tarefas, regras, mensagens, roteiros e feitos.
- `dinheiro (id int, dados jsonb, atualizado timestamptz)`: uma linha com financeiro e meta.

Regras de acesso:
- `membros`: cada pessoa lê a própria linha; só o dono insere e remove.
- `painel`: lê e grava quem está em `membros`.
- `dinheiro`: lê e grava só quem está em `membros` com papel "dono".

## Telas

1. Backup do `dashboard.html` em `backups/`.
2. Crie `<painel>/no-ar/index.html` a partir do `dashboard.html`: acrescente `supabase-js` (versão fixa, por CDN), uma tela de entrada (e-mail e senha, "esqueci a senha") e troque o salvar e o carregar do motor: em vez de só o navegador, lê e grava `painel` e `dinheiro`. Para o colaborador, a aba Dinheiro e os números de dinheiro do Hoje não aparecem (e o banco também não entrega).
3. Primeira entrada da dona: se existir dado no navegador ou um "Baixar meus dados", ofereça subir tudo para o banco uma vez.
4. Convite de colaborador: na aba Mais, "Equipe": a dona digita o e-mail, o Supabase manda o convite, e a linha entra em `membros` como "colaborador".

## Teste obrigatório antes de publicar

1. Entre como dona: vê tudo, cadastra um aluno de teste.
2. Crie um usuário de teste que não está em `membros`: não pode ver nada.
3. Convide um colaborador de teste: vê alunos e agenda, não vê Dinheiro, nem pela tela nem pelo banco.
4. Apague os usuários e o aluno de teste.

Se qualquer teste falhar, não publique. Conserte e teste de novo.

## Publicar

Netlify: a pessoa entra em app.netlify.com, "Add new site", "Deploy manually" e arrasta a pasta `no-ar`. Sai um endereço do tipo `nome.netlify.app`. Abra no computador e no celular e teste a entrada.

## Cobrar o domínio

Logo depois que funcionar no endereço free, pergunte: "Você já tem um domínio, como o do seu site?". Se tiver, guie o subdomínio no painel do Netlify e no lugar onde o domínio foi comprado. Se não tiver, mostre o passo a passo do registro.br e espere. Comprar e pagar é sempre ela.

Anote tudo no `plano-de-gestao.md`, seção "No ar": endereço, data, quem tem acesso (só o e-mail e o papel).

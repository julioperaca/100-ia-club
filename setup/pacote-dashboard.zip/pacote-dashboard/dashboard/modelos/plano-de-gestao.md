# Plano de gestão: <marca>

> O que é: as respostas da entrevista do /dashboard e o histórico do painel.
> Última atualização: <AAAA-MM-DD>
> Status: <esboço com exemplos | alunos reais importados | no ar com login>
> O que falta: <ex.: escolher o visual, importar os alunos>

## Carteira
- Alunos ativos: <N> (<N> online, <N> presenciais)
- Onde estão os dados hoje: <planilha, MFIT, formulário, WhatsApp, caderno>
- Caminho para importar: <planilha | recadastro | Chrome no aplicativo | digitar no painel>

## O que se repete e o que escapa
- Tarefa da semana que não gosta: <resposta>
- O que já esqueceu e custou aluno ou dinheiro: <resposta>
- Onde isso aparece no painel: <ex.: aviso de renovação no Foco de hoje>

## Avisos
- Renovação: atenção <N> dias antes, urgente <N> dias antes
- Troca de treino: a cada <N> semanas, avisar <N> dias antes
- Sumiu: <N> dias sem contato

## Dinheiro
- Meta do mês: R$ <valor>
- Formas de pagamento: <Pix, cartão até Nx, boleto>
- Cartão: cai em <N> dias por parcela (ou antecipado)
- Retirada para a vida pessoal: <R$ por mês | lança quando fizer>

## Ritmos
- Todo dia: <lista>
- Toda semana: <lista>
- Todo mês: <lista>
- Quando acontece: <lista>

## Conversas prontas
- Abertura (renovação, treino, sumiu): "<texto>"
- Renovação depois que responder: <passos 2, 3 e 4>
- Troca de treino depois que responder: <passos>
- Sumiu depois que responder: <passos>
- Aniversário: "<texto>"

## Visual
- <os dois, em teste | visual N, escolhido em AAAA-MM-DD>

## No ar
- <ainda não | endereço, data, quem tem acesso: e-mail e papel>

## Histórico
- <AAAA-MM-DD>: <o que foi feito>

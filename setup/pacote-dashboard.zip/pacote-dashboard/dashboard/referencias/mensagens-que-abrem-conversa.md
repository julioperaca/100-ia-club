# Mensagens que abrem conversa

É assim que o Peraça ensina nas aulas de script, e é assim que o painel trabalha.

## O princípio

Mensagem nunca vai direto ao assunto, como um aviso de cobrança ("Oi, fulano, tá na hora da sua renovação"). Primeiro se abre a conversa, a pessoa responde, e o assunto entra em cima do que ela trouxe.

## Renovação em 4 passos

1. **Abrir.** Só isso: "Oi, João, tudo bem por aí?". Espera a resposta.
2. **Perguntar como ele está.** "João, como você está se sentindo com os treinos? E com os resultados, com o nosso trabalho junto? Me conta um pouquinho mais, para eu ver quais pontos a gente pode melhorar." Espera a resposta.
3. **Acolher.** Comentar de verdade o que ele disse. "Que legal que você está gostando, fico feliz. Temos muito trabalho pela frente ainda."
4. **Convidar.** "E aproveitando: o seu ciclo está para encerrar. Queria conversar com você sobre o próximo planejamento, para eu organizar o processo a médio e longo prazo, para os próximos 6 meses." O número de meses é o do plano do aluno.

Se no passo 2 o aluno trouxer algo negativo (está desanimado, não viu resultado, teve problema), o passo 3 acolhe e resolve primeiro. A renovação espera.

## No painel

- O botão do WhatsApp manda só o passo 1.
- Os passos 2, 3 e 4 aparecem no cartão do aluno, em "Depois que responder", com botão de copiar.
- O passo de acolher não tem botão de copiar: ele depende do que o aluno disse. No modelo, começa com "Acolha o que ele contou." e traz um exemplo.

## Outros casos, mesmo caminho

- **Troca de treino:** abrir; perguntar como está com o treino atual, o que ficou mais fácil e o que ainda pesa; acolher; contar que o treino novo sai em {dias} e que vai ser montado com o que ele contou.
- **Aluno sumido:** abrir; "senti sua falta por aqui, como está a rotina nessas últimas semanas?"; acolher, sem cobrança; propor ajustar o treino para caber na semana dele.
- **Pedido de depoimento ou foto de evolução:** abrir; perguntar como ele vê a evolução; acolher; só então pedir, explicando para que serve.
- **Aniversário:** é a exceção. Vai direto, porque é um parabéns.

## Tom

Na voz do personal (`voz.md`). Frases curtas, de WhatsApp. Sem "bora renovar", sem desconto na primeira mensagem, sem urgência inventada.

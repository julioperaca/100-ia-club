# <Nome do modelo>

> O que é: um modelo de post criado por <nome> com o /conteudo novo modelo. Fica no brain e não some quando a skill é atualizada.
> Criado em: AAAA-MM-DD
> Referência: <de onde veio: "print de um post de @perfil", "ideia minha", "post meu que deu certo">

Formato: carrossel | post único | reels | stories
Objetivo: atrair | conscientizar | converter | conectar | provar
Slides: <número, ou "de 6 a 10">
Pede: <nada | foto sua | print de aluna | foto de perfil>

## Para que serve

<Uma ou duas frases: o que este modelo faz com quem lê e por que funciona.>

## Estrutura (slide a slide)

1. Capa: <o que a capa faz. Ex.: "pergunta que a aluna faz a si mesma, com o nicho em cima">
2. <o que o slide 2 faz>
3. <...>
N-1. Conclusão: <a moral>
N. CTA: <a ação>

## Quando sugerir

<Em que situação o /conteudo pauta oferece este modelo. Ex.: "tema com uma dúvida comum, objetivo conscientizar".>

## Como fica na imagem

<Para o Modo Montar: que recurso do carrossel.html cada slide usa. Ex.:>
- Capa: `"tipo": "capa"` com `"nicho"` e `"imagem"` (foto da pessoa).
- Slides 2 a N-2: `"tipo": "miolo"`, alternando `"fundo": "escuro"` nos pares.
- Penúltimo: `"tipo": "miolo"` com `"estilo": "destaque"`.
- Último: `"tipo": "final"`.

## Estrutura de copy sugerida

<PEPO | PCS | PAS | AIDA | ADP | História com moral, e por quê, em uma linha.>

## Como pedir

`/conteudo pauta: o tema, no modelo <Nome do modelo>`

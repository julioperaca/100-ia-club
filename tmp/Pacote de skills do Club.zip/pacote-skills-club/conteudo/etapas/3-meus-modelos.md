# Meus modelos. O banco de modelos da pessoa

Dois pedidos usam esta etapa:
- **Ver o banco** ("meus modelos", "banco de modelos", "quais modelos eu tenho", "atualiza o banco"): Parte A.
- **Criar um modelo** ("novo modelo", "cria um modelo", "quero um modelo igual a esse post", print de um post com pedido de modelo): Parte B, e no fim a Parte A para o banco mostrar o modelo novo.

Tudo desta etapa mora em `<pasta>/meus-modelos/` (a pasta do brain). É a única pasta do brain em que esta skill escreve além de `conteudo/` e `espiao/`. Ela fica fora da skill de propósito: quando o Club manda uma versão nova das skills, a instalação copia por cima da skill, e o que está no brain não é tocado.

```
<pasta>/meus-modelos/
  banco-de-modelos.html     a página do banco (abre com dois cliques)
  <slug-do-modelo>.md       um arquivo por modelo criado pela pessoa
  capas/                    as imagens de exemplo (club-1.png ... club-7.png e <slug>.png)
  referencias/              os prints que a pessoa mandou para criar modelos
  foto.jpg                  foto da pessoa para as capas de exemplo (se ela mandar)
```

Crie as pastas que faltarem (Mac e Linux `mkdir -p`; Windows `New-Item -ItemType Directory -Force`). Nunca apague nada aqui. Para tirar um modelo do banco, mova o arquivo para `<pasta>/meus-modelos/arquivados/` e avise.

## Parte A. Montar o banco

### A1. As capas dos 7 modelos do Club, nas cores da pessoa

Se as 7 capas `capas/club-1.png` a `capas/club-7.png` já existem, pule para A2 (refaça só se a pessoa pedir "refaz as capas" ou se a identidade visual mudou depois delas).

Para fazer, siga o Modo Montar (`${CLAUDE_SKILL_DIR}/etapas/2-montar.md`) nos Passos 2 a 6 (cores, DADOS, conferência, PNG e olhar a imagem), com estas diferenças:
- **Foto:** se `<pasta>/meus-modelos/foto.jpg` (ou .png, .jpeg, .webp) não existe, crie a pasta `<pasta>/meus-modelos/`, abra ela para a pessoa (Mac `open`; Linux `xdg-open`; Windows `Start-Process`) e peça uma vez: "Abri a pasta meus-modelos. Para as capas de exemplo ficarem com a sua cara, arraste para dentro dela uma foto sua (de corpo ou rosto, boa luz) e me responda pronto. Se não quiser agora, responda faz sem foto." Imagem colada direto na conversa não vira arquivo: se ela colar, peça para arrastar o arquivo para a pasta. Quando disser pronto, ache a foto com Glob e copie para `foto.jpg` (ou mantenha a extensão dela). "Faz sem foto": siga sem `"imagem"`.
- **Textos das capas:** são exemplos para mostrar o modelo, e nesta etapa você escreve eles (é a única exceção à regra de não escrever texto de post), sempre a partir do brain: nada de número, resultado ou nome que não esteja lá. Use o nicho (de 1 a 3 palavras em caixa alta, tirado de para quem é o programa em `negocio.md` ou da descrição de `aluno-ideal.md`, ex.: MULHERES 40+), um desejo do Ponto B de `aluno-ideal.md` e uma frase de `voz.md`:
  1. Foto, nicho e headline: capa com `"nicho"`, `"imagem"` (se houver foto) e uma headline de desejo com curiosidade.
  2. Troque isso por isso: capa "Faça isso para *<desejo>*" com um complemento curto no `apoio`.
  3. Foi assim que: capa "Foi assim que a <nome> alcançou *<resultado do case>*", com o nome e o resultado de um case com `autorização para uso público: sim` em `cases.md`. Sem case autorizado: "Foi assim que a minha aluna alcançou *<desejo>*".
  4. Frase sobre foto: `"tipo": "frase"` com uma frase da `voz.md` e a foto (se houver).
  5. Esse é o segredo: capa "Esse é o segredo para *<desejo>*" com `"nicho"` e a foto.
  6. Plano prático: capa "Plano prático para *<desejo>*" com a foto.
  7. Carrossel tweet: `"modelo": "tweet"`, um slide de capa com uma opinião curta na voz da pessoa e `"foto_perfil"` (a mesma foto, se houver).
- **Arquivos:** copie `${CLAUDE_SKILL_DIR}/modelos/carrossel.html` sete vezes em `<pasta>/meus-modelos/capas/`, um por modelo, de `club-1.html` a `club-7.html`, cada um com um slide só (a capa daquele modelo). Assim a capa sozinha sai sem "Arraste para o lado", como post único. As fotos são lidas da mesma pasta do HTML: copie a foto para dentro de `capas/` antes de gerar.
- **PNGs:** um PNG por HTML, todos em 1080 x 1350. No Mac:
```bash
C="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; D="<pasta>/meus-modelos/capas"
for i in 1 2 3 4 5 6 7; do "$C" --headless=new --user-data-dir=/tmp/conteudo-navegador --hide-scrollbars --force-device-scale-factor=1 --window-size=1080,1350 --virtual-time-budget=6000 --screenshot="$D/club-$i.png" "file://$D/club-$i.html#1" 2>/dev/null; done; ls -l "$D"/club-*.png
```
No Linux, troque a primeira linha como no Modo Montar. No Windows:
```powershell
$d = "<pasta>\meus-modelos\capas"; $u = "file:///" + ($d -replace '\\','/')
1..7 | ForEach-Object { & $exe --headless=new --user-data-dir="$env:TEMP\conteudo-navegador" --hide-scrollbars --force-device-scale-factor=1 --window-size=1080,1350 --virtual-time-budget=6000 --screenshot="$d\club-$_.png" "$u/club-$_.html#1" 2>$null | Out-Null }
```
(o `$exe` é o navegador achado no Modo Montar, Passo 4).

### A2. Os modelos da pessoa

Liste com Glob `<pasta>/meus-modelos/*.md`. De cada um, leia: título (`# `), `Formato:`, `Objetivo:`, a seção "Para que serve" (primeira frase) e a seção "Como pedir". A capa é `capas/<slug>.png`; se não existir, gere como na Parte B, passo B5.

### A3. Os posts que ela já montou

Liste com Glob as pastas de `<pasta>/conteudo/` que têm PNG. De cada uma:
- `tema`: a primeira linha da `pauta.md` (`# Pauta: <tema>`, sem o "Pauta:"); sem ela, a primeira linha do `texto.md` (`# <tema>`); sem os dois, o nome da pasta sem a data.
- `data`: a data do nome da pasta, como DD/MM/AAAA.
- `modelo`: a linha `Modelo:` do texto de versão mais alta (`texto-v2.md` antes de `texto.md`) ou da `pauta.md`, se houver.
- `capa`: o primeiro que existir entre `slide-01.png`, `post.png`, `capa-reels.png`, `story-01.png`, com o caminho a partir do banco: `../conteudo/<nome-da-pasta>/slide-01.png`.
- `pasta`: `conteudo/<nome-da-pasta>`.
Ordene do mais novo para o mais antigo. Mais de 60 posts: use os 60 mais novos e diga quantos ficaram de fora.

### A4. Gravar e abrir

Leia `${CLAUDE_SKILL_DIR}/modelos/banco-de-modelos.html` e grave em `<pasta>/meus-modelos/banco-de-modelos.html`, trocando **só** o bloco entre `/* DADOS INICIO` e `/* DADOS FIM */`:
- `nome` e `instagram` de `perfil-profissional.md`; `atualizado` com a data de hoje (DD/MM/AAAA);
- `tokens`: o bloco `json` inteiro de `identidade-visual.md` (como no Modo Montar, Passo 2), ou `null`;
- `club`: os 7 itens, nesta ordem, com `nome`, `objetivo`, `formato`, `para_que` (uma frase, do "Para que serve" de `referencias/formatos.md`, adaptada ao nicho da pessoa), `comando` (`/conteudo pauta: o tema, no modelo <nome>`) e `capa` (`capas/club-N.png`);
- `meus`: um item por modelo da A2, com os mesmos campos (`capa`: `capas/<slug>.png`);
- `posts`: os itens da A3.

JSON válido, aspas duplas, texto sem travessão e sem emoji. Abra a página (Mac `open`; Linux `xdg-open`; Windows `Start-Process`).

Fechamento:
> Pronto, o seu banco de modelos abriu no navegador. Ele está em brain/meus-modelos/banco-de-modelos.html: para abrir de novo, é só dar dois cliques nele.
> Tem os 7 modelos do Club [, N modelos seus] [e N posts que você já fez].
> Para usar um modelo, clique em Copiar no cartão dele, troque "o tema" pelo seu e mande aqui.
> Para criar um modelo seu, tire print de um post que você gostou e digite: /conteudo novo modelo: (e mande o print junto).
> Agora digite: `/conteudo pauta: o tema, no modelo <um dos modelos>`

## Parte B. Criar um modelo novo

### B1. Entender o que a pessoa quer

Ela pode mandar print de um post (dela ou de outra pessoa), um link, ou descrever ("quero um carrossel de mito ou verdade"). Leia os prints com Read. Se mandou só o print da capa, peça os outros slides uma vez: "Se tiver, me manda o print dos outros slides também. Com eles eu entendo a ordem do post inteiro." Se não tiver, siga só com o que tem.

Os prints servem para você entender o post. Se a pessoa mandou um arquivo com caminho (arrastou o arquivo), guarde uma cópia depois do B3, quando o modelo já tem nome, em `<pasta>/meus-modelos/referencias/<slug>-1.<extensão original>`. Se colou a imagem direto na conversa, não precisa guardar.

### B2. Tirar a estrutura (nunca o texto)

Descreva o que cada slide **faz**, não o que diz: "capa com uma pergunta que a aluna se faz", "slide com um mito e a resposta embaixo". Regra 6 da skill: nenhuma frase, título ou roteiro do post de referência vai para o modelo. O modelo guarda a forma; o conteúdo vem sempre do brain da pessoa.

Veja o que o visual pede e ligue a um recurso do `modelos/carrossel.html`: capa, miolo, final, `"fundo": "escuro"`, `"estilo": "destaque"`, `"par"` (só para os rótulos Troque e Por; para outro par, como Mito e Verdade, escreva o rótulo no começo do Título e do Texto, "Mito: ..." e "Verdade: ...", e alterne `"fundo": "escuro"`), `"nicho"`, `"imagem"`, `"prints"`, `"tipo": "frase"`, `"modelo": "tweet"`. Se a referência tem algo que o motor não faz (vídeo, colagem de várias fotos, desenho), diga em uma linha e use o recurso mais próximo: "O post dela usa três fotos lado a lado. Aqui eu faço com uma foto por slide."

Se o modelo for quase igual a um dos 7 do Club, diga: "Esse post segue o modelo Troque isso por isso, que você já tem no banco." e pergunte se ela quer mesmo um modelo à parte.

### B3. Dar nome

Sugira um nome curto que diga o que o modelo faz ("Mito ou verdade", "3 erros", "Pergunta da aluna") e pergunte uma coisa só: "Vou chamar de Mito ou verdade. Pode ser, ou prefere outro nome?" O slug é o nome em minúsculas, sem acento, com hífen no lugar dos espaços (`mito-ou-verdade`). Se já existe um arquivo com esse slug, use `-2`.

### B4. Gravar o arquivo do modelo

Leia `${CLAUDE_SKILL_DIR}/modelos/meu-modelo.md` e grave `<pasta>/meus-modelos/<slug>.md` com tudo preenchido: formato, objetivo, número de slides, o que pede, para que serve, estrutura slide a slide, quando sugerir, como fica na imagem (os recursos do B2, slide a slide), estrutura de copy sugerida (do cardápio do /copy: PEPO, PCS, PAS, AIDA, ADP ou História com moral) e como pedir. Anúncio aceita no máximo 10 slides: se o modelo tem mais, escreva "Slides: N (no anúncio, até 10: junte os slides do meio)".

### B5. Fazer a capa de exemplo

Copie `${CLAUDE_SKILL_DIR}/modelos/carrossel.html` para `<pasta>/meus-modelos/capas/<slug>.html` com os tokens da pessoa e 2 ou 3 slides de exemplo, seguindo o "Como fica na imagem", com textos de exemplo escritos a partir do brain dela (nunca da referência). Gere `#1` como `capas/<slug>.png` (1080 x 1350), como no Modo Montar, Passos 4 e 5. Abra o PNG com Read e confira se ficou legível e com a cara dela.

### B6. Atualizar o banco e fechar

Rode a Parte A (as capas do Club que já existem não são refeitas). Fechamento:
> Pronto, o modelo "<Nome>" está guardado no seu banco, que abri no navegador.
> Ele fica em brain/meus-modelos/<slug>.md e não some quando a skill for atualizada.
> Para usar: /conteudo pauta: o tema, no modelo <Nome>
> Para mudar alguma coisa nele: /conteudo muda o modelo <Nome>: o que você quer mudar

### Mudar um modelo

"muda o modelo X: ..." edita só o `<pasta>/meus-modelos/<slug>.md` desse modelo, refaz a capa (B5) e o banco (Parte A). Mostre em uma linha o que mudou.

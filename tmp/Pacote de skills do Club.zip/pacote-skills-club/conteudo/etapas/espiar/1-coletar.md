# Modo Espiar, etapa 1. Coletar o material do perfil

Tempo no encontro: 5 a 10 minutos.

Objetivo: juntar o suficiente para enxergar padrão. Um post só não ensina nada; dez posts com número ensinam muito.

## Passo 1. Ler o cérebro do personal (sem perguntar nada)

Leia só o necessário, nesta ordem:
1. `<pasta>/voz.md`: Tom, Expressões, O que eu nunca digo, Textos reais.
2. `<pasta>/aluno-ideal.md`: Quem é, Ponto A, Ponto B, Linguagem, Objeções.
3. `<pasta>/metodo.md`: Nome, Promessa, Etapas ou pilares.
4. `<pasta>/negocio.md`: O que eu vendo, Meu diferencial, Provas.
5. `<pasta>/perfil-profissional.md`: as linhas `nome_publico` e `instagram`.
6. `<pasta>/cases.md`: só quais têm `autorização para uso público: sim`.

Se `metodo.md` estiver com `Status: vazio`, avise em uma linha ("Seu método ainda está vazio; as ideias vão sair da sua aluna ideal e da sua voz. Depois que contar seu método ao /brain, as ideias ficam melhores.") e siga.

## Passo 2. Saber qual perfil

Leia `$ARGUMENTS`. Pode vir:
- um @ (`@fulana.fit`) ou um link (`instagram.com/fulana.fit`);
- 2 ou 3 @ ou links: é comparação. Mais de 3, diga que a análise fica rasa e peça para escolher os 3 que mais importam;
- vazio: pergunte "Qual perfil você quer que eu espie? Pode mandar o @, o link ou já colar os prints."

Pergunte também, numa linha só: "Ela é concorrente (vende pra mesma aluna que você) ou referência (você admira o jeito, mesmo sendo de outro nicho)?" A resposta muda a comparação na etapa 3. Se a pessoa não souber, trate como concorrente.

## Passo 3. Tentar ler a página pública

Se veio link ou @, tente WebFetch em `https://www.instagram.com/<perfil>/` pedindo bio, número de seguidores, número de posts e as legendas visíveis.

- Se voltar conteúdo útil (bio, números, legendas): anote tudo com a fonte "página pública lida em <data de hoje>".
- Se voltar vazio, tela de login, erro ou só código: é o normal, o Instagram bloqueia. Não tente de novo nem por outro caminho. Diga: "O Instagram não deixou eu ler a página direto, isso é normal. Me manda os prints que eu analiso por eles." e siga para o Passo 4.

Nunca tente outro site que copie perfis do Instagram, nunca peça login.

Na primeira vez que pedir print nesta conversa, se a skill espiao estiver instalada (existe `${CLAUDE_SKILL_DIR}/../espiao/SKILL.md`), acrescente uma linha: "Se quiser a análise a fundo, com os números reais de 40 posts e os comentários, sem print, digite: /espiao @perfil (na primeira vez ela te ensina a criar a conta do Apify, no plano Free, sem cartão)."

## Passo 4. Pedir o material (uma mensagem só)

> Pra eu enxergar padrão, me manda o que conseguir, quanto mais melhor:
> 1. Print do topo do perfil: foto, bio, número de seguidores e o link.
> 2. Print da grade do feed (2 ou 3 prints rolando pra baixo, uns 15 a 30 posts).
> 3. Print dos destaques (as bolinhas abaixo da bio) e, se der, de dentro do destaque de depoimentos ou do destaque onde ela apresenta o que vende.
> 4. Print de 5 a 10 posts com os números aparecendo (curtidas, comentários, views). Dica: na aba Reels da pessoa aparece o número de views em cada vídeo, um print só mostra vários.
> 5. Legendas coladas aqui (copia e cola o texto dos posts que você achou bons).
> 6. Se tiver, o texto falado de 2 ou 3 reels (pode digitar o que ela fala nos primeiros segundos, ou colar a legenda automática).
>
> Pode colar aqui na conversa ou arrastar pra pasta `arquivos` do seu segundo cérebro.

Se for comparação, peça o mesmo para cada perfil e peça para dizer de quem é cada print, se não estiver claro pelo @ no topo.

## Passo 5. Ler o que chegou

1. Imagens coladas: leia cada uma. Imagens na pasta: Glob em `<pasta>/arquivos/**/*` e leia com Read só as que a pessoa disse que são do perfil espiado (ou que mostram o @ dele no topo).
2. Monte, para você, uma lista simples de cada post visível: número (post 1, post 2...), formato (carrossel, reels, foto única), tema, primeira frase ou texto da capa, curtidas, comentários, views, data se aparecer. Número que não aparece fica em branco, nunca estimado.
3. Anote de qual print veio cada coisa (ex.: "print-grade-1.png", "legenda colada 2").

## Passo 6. Conferir se dá para analisar

- Menos de 3 posts com tema identificável: diga que com isso dá para analisar só bio e posicionamento, e pergunte se quer mandar mais prints ou seguir assim. Se seguir, a análise de padrões fica marcada como "pista".
- Nenhum número de curtida ou view: siga, mas avise que "o que mais performa" vai ser julgado pelo que ela repete e destaca (fixados, destaques), não por número.
- Print de perfil privado, de conversa privada ou com dado de aluno: não use, e diga por quê em uma linha.

Confirme em uma linha o que tem em mãos ("Tenho a bio, 18 posts na grade e números de 7 deles. Bora analisar.") e vá para a etapa 2 (`${CLAUDE_SKILL_DIR}/etapas/espiar/2-analisar.md`).

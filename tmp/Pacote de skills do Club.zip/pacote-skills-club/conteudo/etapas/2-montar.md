# Modo Montar. Do texto pronto para a imagem

Tempo no encontro: 5 minutos.

`<peca>` é a pasta do post: `<pasta>/conteudo/AAAA-MM-DD-<slug>/`.

## Passo 1. Achar o texto

1. Se `$ARGUMENTS` traz uma pasta ou um tema, use. Se a pessoa diz "monta de novo" (depois de um ajuste no /copy), use a pasta do post mais recente que ela mexeu, mesmo que já tenha PNG: os PNGs são refeitos por cima. Senão, liste com Glob as pastas de `<pasta>/conteudo/` que têm `texto.md`. Uma só sem PNG: use essa. Várias: mostre as 3 mais recentes numeradas e pergunte qual.
2. Se a pasta da pauta mais recente tem `variacoes.md` e não tem `texto.md`, o /copy mostrou o texto mas a pessoa ainda não escolheu a versão. Diga: "O texto de \"<tema>\" ainda não foi gravado: o /copy está esperando você escolher a versão. Volte na conversa do /copy e responda A, B ou ajuste, ou mande /copy grava a versão A." e pare. Nunca grave o texto você mesmo.
   Sem nenhum `texto.md`: pare e diga "Ainda não tem texto pronto para montar. Rode /copy na pauta que você quer postar; ele grava o texto.md e aí eu monto as imagens." Se a pasta tem `pauta.md`, diga o tema dela. Nunca escreva o texto você mesmo.
3. Na pasta pode haver `texto.md`, `texto-v2.md`, `texto-v3.md`: o /copy nunca grava por cima, então use sempre o de número mais alto (o mais novo) e diga em uma linha qual usou. Leia esse arquivo seguindo `${CLAUDE_SKILL_DIR}/referencias/formato-do-texto.md`. Descubra o formato pela linha `Formato:` ou pelos títulos (`## Slide`, `## Gancho`, `## Story`, `## Post`).

| Formato | Modelo | Peças | Tamanho |
|---|---|---|---|
| carrossel | `modelos/carrossel.html` | `slide-01.png` ... | 1080 x 1350 |
| post único | `modelos/carrossel.html` com 1 slide de capa | `post.png` | 1080 x 1350 |
| reels | `modelos/vertical.html` com 1 tela `reels` | `capa-reels.png` | 1080 x 1920 |
| stories | `modelos/vertical.html` com 1 tela `story` por story | `story-01.png` ... | 1080 x 1920 |

4. Leia também as linhas `Modelo:` e `Uso:` logo abaixo de `Formato:` (veja `referencias/formatos.md`). Sem elas, monte como antes. Se o `Modelo:` termina com `(meu modelo)` ou não é um dos 7, leia `<pasta>/meus-modelos/<slug>.md` (o slug é o nome sem o "(meu modelo)", em minúsculas, sem acento, com hífen no lugar dos espaços) e monte cada slide pela seção "Como fica na imagem" dele.
5. **Uso: anúncio** aceita no máximo 10 slides. Se o texto.md tiver mais, avise em uma linha ("O anúncio aceita até 10 slides e o texto tem N. Juntei os slides X e Y.") e junte slides do meio, em pares vizinhos, até chegar a 10: o Título fica o do primeiro e os dois Textos vão juntos, separados por `\n`. Nunca junte a capa, a conclusão (penúltimo) nem o CTA (último). **Uso: vitrine** aceita até 20.
6. **Arquivos que faltam.** Procure no texto.md as linhas `Imagem:`, `Print:` e `Foto de perfil:`. Se alguma diz `pedir (...)`, ou cita um arquivo que não está na pasta `<peca>`, antes de montar abra a pasta do post para a pessoa (Mac `open "<peca>"`; Linux `xdg-open "<peca>"`; Windows `Start-Process "<peca>"`), peça o arquivo dizendo para que serve e espere: "Abri a pasta do post. Para o slide 4, arraste para dentro dela o print da mensagem da aluna contando que tinha medo de voltar (ele prova o que o texto diz) e me responda pronto." Imagem colada direto na conversa não vira arquivo: se a pessoa colar, peça para ela arrastar o arquivo para a pasta aberta. Quando ela disser pronto, liste a pasta com Glob e use o nome do arquivo novo. Use o que está entre parênteses para explicar. Se a pessoa disser que não tem, monte sem esse arquivo (o slide sai com o fundo da marca, sem o print ou com a inicial no lugar da foto de perfil) e avise em uma linha no fechamento: "O slide 4 ficou sem o print. Com ele, o post fica mais forte."

## Passo 2. Pegar as cores e fontes

1. Leia `<pasta>/identidade-visual.md`, a seção `## Tokens (para as outras skills)` e o bloco `json` dentro dela. Esse JSON é o `tokens`, inteiro: copie do jeito que está, sem resumir, sem tirar campo e sem trocar nome de fonte (o bloco `fontes` precisa ir com `titulo`, `texto` e `google_fonts`).
2. Status vazio, seção ausente ou JSON inválido: use `"tokens": null` (visual neutro, cinza e branco) e avise uma vez: "Usei um visual neutro porque sua identidade visual ainda não está pronta. Depois do /design-system, peça para montar de novo."
3. Leia também as seções `## Carrossel` e `## Stories` de `identidade-visual.md`. Se pedem limite de palavras diferente, use na conferência do Passo 4.
4. Leia `nome_publico` e `instagram` em `perfil-profissional.md`.

## Passo 3. Gravar o HTML da peça

Leia o modelo e grave uma cópia em `<peca>/carrossel.html` ou `<peca>/vertical.html`, trocando **só** o que está entre `/* DADOS INICIO` e `/* DADOS FIM */`. O resto fica igual: é o motor visual.

**carrossel.html** (`nome`, `instagram`, `tema`, `tokens`, `slides`):
- `## Slide 1`: `{ "tipo": "capa", "titulo": "<Título>", "apoio": "<Apoio>" }`
- slides do meio: `{ "tipo": "miolo", "titulo": "<Título>", "texto": "<Texto>" }`; com `Estilo: destaque`, acrescente `"estilo": "destaque"`.
- último slide: `{ "tipo": "final", "titulo": "<Título>", "texto": "<Texto>", "botao": "<Botão>" }`
- post único: um item só, `{ "tipo": "capa", "titulo": "<Título>", "apoio": "<Texto>" }`.

Opcionais do carrossel (sem eles, tudo sai como antes). Veja a linha `Modelo:` do texto.md (ou, em pauta antiga, a linha `Estrutura sugerida:` da `pauta.md`):
- **Troque isso por isso:** todo slide do meio com `Título:` começando por "Troque" e `Texto:` começando por "Por" ganha `"par": true` (rótulo "Troque" na cor de alerta, "Por" na cor de acerto, das cores `alerta` e `acerto` dos tokens; sem elas, destaque e primária). Alterne o fundo: nos pares em slide de número par, acrescente `"fundo": "escuro"`. Nos pares, `"fundo"` substitui o `"estilo": "destaque"`; fora dos pares, o `Estilo: destaque` continua valendo. O texto fica igual ao `texto.md`: o modelo só separa a primeira palavra como rótulo.
- **Plano prático:** procure na pasta `<peca>` uma foto do personal (`.jpg`, `.jpeg`, `.png`, `.webp`). Achou: acrescente `"imagem": "<nome do arquivo>"` no slide de capa (ela sai escurecida com a cor secundária). Mais de uma: use a que tem "capa" no nome, senão a primeira. Nenhuma: capa normal e, no fechamento, diga em uma linha: "Para a capa com foto, coloque uma foto sua na pasta do post e peça para montar de novo."
- `"fundo": "escuro"` e `"imagem"` também valem em qualquer slide do meio, se a pessoa pedir.

Rótulos dos modelos (texto.md com `Modelo:`). Cada rótulo vira um campo do mesmo slide:
- `Nicho: MULHERES 40+` vira `"nicho": "MULHERES 40+"` (faixa acima do título na capa; no miolo só aparece se o slide também tem imagem).
- `Imagem: foto-capa.jpg` vira `"imagem": "foto-capa.jpg"`. Quando o texto.md tem `Imagem:`, use esse arquivo e não procure outra foto na pasta.
- `Print: print-1.jpg` (pode repetir, uma linha por print) vira `"prints": ["print-1.jpg", "print-2.jpg"]`, na mesma ordem. Até 3 por slide; mais que isso, avise e use os 3 primeiros.
- `Modelo: Carrossel tweet` vira `"modelo": "tweet"` no nível do DADOS (ao lado de `nome` e `instagram`), e `Foto de perfil: perfil.jpg` vira `"foto_perfil": "perfil.jpg"`. Sem foto de perfil, deixe o campo fora: sai um círculo com a inicial do nome. No tweet, o texto de cada slide vai em `"titulo"` e `"texto"` como sempre; parágrafos separados por linha em branco viram `\n\n`. A letra é fixa (54 px, capa 62 px): se a conferência disser que não coube, siga a regra do Passo 4.
- `Modelo: Frase sobre foto` vira um item só: `{ "tipo": "frase", "titulo": "<a frase>", "imagem": "<arquivo>" }`. Sem imagem, sai sobre um degradê da cor secundária.
- `Modelo: Esse é o segredo` vira um item só: `{ "tipo": "capa", "titulo": "<headline>", "imagem": "<arquivo>", "nicho": "<Nicho>" }` (nicho só se houver). Capa sozinha sai sem "Arraste para o lado". Se a pessoa quiser como capa de reels, monte também o `vertical.html` com a mesma tela (veja abaixo).
- `Imagem: pedir (...)` ou `Print: pedir (...)` sem o arquivo: veja o Passo 1, item 6. Nunca escreva "pedir" dentro do DADOS.

**vertical.html** (`nome`, `instagram`, `tema`, `tokens`, `telas`):
- reels: `{ "tipo": "reels", "titulo": "<Título do Gancho>", "apoio": "<Apoio>" }`. Aceita `"imagem"` (foto escurecida) e `"nicho"` (faixa acima do título), como na capa do carrossel.
- cada story: `{ "tipo": "story", "titulo": "<Título>", "texto": "<Texto>", "figurinha": "<Figurinha>" }`. Alterne `"estilo": "claro"` em stories pares para a sequência não ficar igual.

O `tokens` entra no DADOS exatamente como está no `identidade-visual.md` (Passo 2), o bloco inteiro. Resumir ou reescrever o bloco `fontes` faz a peça sair com fonte padrão.

Regras do texto dentro do JSON:
- Exatamente o texto do `texto.md`. Não reescreve, não corta, não acrescenta. Campo ausente: deixe fora do item.
- `*palavra*` continua com asterisco (vira a cor de destaque). Quebra de linha: `\n`.
- JSON válido: aspas duplas, vírgula entre itens, nada sobrando no último. Aspas dentro do texto viram `\"`.

## Passo 4. Achar o navegador e conferir se coube

**Mac** (Bash): `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`; sem Chrome, `/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge`.

**Linux** (Bash): o primeiro que existir.

```bash
C=$(command -v google-chrome google-chrome-stable chromium chromium-browser microsoft-edge | head -n 1); echo "$C"
```

Se não sair nada, não há navegador: vá para "Se não der certo".

**Windows** (PowerShell): o primeiro que existir.

```powershell
$exe = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
         "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
         "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
         "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") |
       Where-Object { Test-Path $_ } | Select-Object -First 1
```

Conferência (troque `<peca>` pelo caminho completo e `<arquivo>` por `carrossel.html` ou `vertical.html`):

**Mac:**
```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --user-data-dir=/tmp/conteudo-navegador --virtual-time-budget=6000 --dump-dom "file://<peca>/<arquivo>" 2>/dev/null | grep -o 'id="relatorio">[^<]*'
```

**Linux** (com o `$C` achado acima):
```bash
"$C" --headless=new --user-data-dir=/tmp/conteudo-navegador --virtual-time-budget=6000 --dump-dom "file://<peca>/<arquivo>" 2>/dev/null | grep -o 'id="relatorio">[^<]*'
```

**Windows:**
```powershell
$url = "file:///" + ("<peca>" -replace '\\','/') + "/<arquivo>"
& $exe --headless=new --user-data-dir="$env:TEMP\conteudo-navegador" --virtual-time-budget=6000 --dump-dom $url 2>$null | Select-String 'id="relatorio">[^<]*' | ForEach-Object { $_.Matches.Value }
```

- "OK, todo texto coube": siga.
- "TEXTO NÃO COUBE nos slides 3, 5": não corte você. Gere as imagens mesmo assim e, no fechamento, diga: "Os slides 3 e 5 ficaram apertados. Peça ao /copy: encurta os slides 3 e 5 de <pasta>. Depois rode /conteudo montar de novo."
- "FONTE NÃO CARREGOU: <Família>": não gere em silêncio. Avise em uma linha simples e espere a resposta: "A fonte <Família> não está no Google Fonts, então as imagens sairiam com uma fonte padrão. Rode /design-system muda minha fonte para escolher uma parecida do Google Fonts. Quer que eu gere assim mesmo?" Só gere se a pessoa disser que quer.
- "PRINT NÃO ABRIU nos slides 4": o nome no DADOS não bate com o arquivo da pasta. Corrija o nome no DADOS (nunca o texto) e confira de novo.
- Sem resposta: siga, a conferência visual do Passo 6 cobre.

## Passo 5. Gerar os PNGs

Um PNG por peça. Troque `N` pelo número de slides ou de stories; `L,A` pelo tamanho (`1080,1350` para carrossel e post único; `1080,1920` para reels e stories); `<nome>` por `slide`, `story`; arquivo único usa `post.png` ou `capa-reels.png` com `#1`.

**Mac (sequência):**
```bash
C="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; D="<peca>"
for i in $(seq 1 N); do n=$(printf "%02d" $i); "$C" --headless=new --user-data-dir=/tmp/conteudo-navegador --hide-scrollbars --force-device-scale-factor=1 --window-size=L,A --virtual-time-budget=6000 --screenshot="$D/<nome>-$n.png" "file://$D/<arquivo>#$i" 2>/dev/null; done; ls -l "$D"/*.png
```

**Mac (peça única):**
```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --user-data-dir=/tmp/conteudo-navegador --hide-scrollbars --force-device-scale-factor=1 --window-size=L,A --virtual-time-budget=6000 --screenshot="<peca>/capa-reels.png" "file://<peca>/vertical.html#1" 2>/dev/null
```

**Linux:** os mesmos comandos do Mac, trocando a primeira linha da sequência por `C=$(command -v google-chrome google-chrome-stable chromium chromium-browser microsoft-edge | head -n 1); D="<peca>"` e, na peça única, o caminho do Chrome por `"$C"`.

**Windows (sequência):**
```powershell
$d = "<peca>"; $url = "file:///" + ($d -replace '\\','/') + "/<arquivo>"
1..N | ForEach-Object { $n = "{0:D2}" -f $_; & $exe --headless=new --user-data-dir="$env:TEMP\conteudo-navegador" --hide-scrollbars --force-device-scale-factor=1 --window-size=L,A --virtual-time-budget=6000 --screenshot="$d\<nome>-$n.png" "$url#$_" 2>$null | Out-Null }
Get-ChildItem "$d\*.png" | Select-Object Name, Length
```

Confira: um arquivo por peça, todos com tamanho maior que zero. Faltou algum: rode só aquele número de novo.

## Passo 6. Olhar as imagens antes de entregar

Abra com Read a capa e a peça com mais texto. Confira:
- texto inteiro, sem corte, longe das bordas (no vertical, nada no topo de 250 px nem na base de 340 px);
- dá para ler no celular: letra grande, contraste bom;
- cores e fontes da identidade visual (ou o neutro);
- no Troque isso por isso: rótulos "Troque" e "Por" com cores diferentes e fundos alternando; no Plano prático com foto: texto da capa legível sobre a foto;
- com nicho: a faixa legível acima do título; com prints: print inteiro, centralizado, sem corte; no tweet: cabeçalho no mesmo lugar em todos os slides e texto logo abaixo dele, nunca no meio da altura;
- @ e nome certos;
- nenhum caractere estranho (quadradinho, `&amp;`, asterisco sobrando), zero travessão, zero emoji.

Algo errado no visual: corrija o `DADOS` (nunca o texto), gere de novo só a peça afetada e olhe outra vez.

## Passo 7. Abrir a pasta e fechar

Abrir: Mac `open "<peca>"`; Linux `xdg-open "<peca>"`; Windows `Start-Process "<peca>"` (se não abrir, `explorer.exe "<peca>"`). Atualize o `Status:` da `pauta.md` para `imagens prontas` e a linha `Próximo passo:` para `postar`, se ela existir.

> Pronto, as imagens estão na pasta que abri.
> [Carrossel: N imagens, slide-01 a slide-N, na ordem.] [Capa do reels: capa-reels.png, escolha ela como capa na hora de postar.] [Stories: N imagens, coloque a figurinha no espaço marcado.]
> A legenda está no texto.md, na parte "Legenda".
> Para postar: no Instagram, toque no +, escolha as imagens na ordem, cole a legenda e publique. Se o celular não vê a pasta, mande as imagens para você mesma pelo WhatsApp.

Se `<pasta>/meus-modelos/banco-de-modelos.html` existe, acrescente este post na lista `posts` do DADOS dele (no começo da lista, com tema, data, modelo, capa e pasta, como em `etapas/3-meus-modelos.md`, A3). Se já existe um item com a mesma `pasta`, troque esse item em vez de acrescentar outro. Diga no fechamento: "O post também entrou no seu banco de modelos."

Última linha do fechamento:
> Agora digite: `/conteudo pauta: o tema do próximo post`

## Se não der certo

Sem navegador, ou PNG vazio depois de duas tentativas: abra o HTML da peça (Mac `open`; Linux `xdg-open`; Windows `Start-Process`). Ele mostra a prévia de todas as peças. Diga: "Não consegui gerar as imagens aqui. A prévia está aberta; dá para tirar print de cada uma ou montar no Canva com esses textos." No Linux sem navegador achado, acrescente: "Para gerar as imagens, instale o Google Chrome: baixe o arquivo .deb em google.com/chrome e dê dois cliques nele."

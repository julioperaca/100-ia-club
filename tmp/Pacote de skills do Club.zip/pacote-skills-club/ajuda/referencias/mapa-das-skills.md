# Mapa das skills do 100% IA Club

> O que é: o manual das skills do Club. O que cada uma faz, em que ordem usar e qual usar em cada situação. É a mesma fonte da página "Manual das skills" do material e da skill /ajuda.
> Última atualização: 19/11/2026
> Versão do pacote: 19/11/2026

## Antes de tudo

- Toda skill lê o seu **brain** (o segundo cérebro). Por isso a /brain vem primeiro. Sem ela, as outras não sabem quem você é.
- Você não precisa decorar nada. Toda skill termina dizendo o próximo passo e qual comando digitar. Ficou perdido? Digite `/ajuda` e conte o que você quer fazer.
- Para chamar uma skill, digite a barra e o nome dela (`/copy`). Depois do nome, você pode escrever o pedido do seu jeito (`/copy legenda para o post de amanhã`).

## O que eu quero fazer

| Quero... | Faça nesta ordem |
|---|---|
| Começar do zero no Club | `/brain`, depois `/design-system` |
| Contar uma novidade do meu negócio (preço, plano, depoimento) | `/brain atualiza: a novidade` |
| Mudar minhas cores ou fontes | `/design-system ajusta: o que mudar` |
| Criar o meu método | `/criador-de-metodo` |
| Montar a minha oferta ou saber quanto cobrar | `/oferta` |
| Fazer um post | 1. `/conteudo pauta: o tema` 2. `/copy` 3. `/conteudo montar` |
| Saber o que postar na semana | 1. `/conteudo pauta da semana` 2. `/copy` em cada pauta 3. `/conteudo montar` em cada uma |
| Usar um dos 7 modelos de post | `/conteudo pauta: o tema, no modelo Troque isso por isso` (ou outro modelo), depois `/copy` e `/conteudo montar` |
| Ver todos os modelos que eu tenho (e os posts que já fiz) | `/conteudo meus modelos` (abre o seu banco de modelos no navegador) |
| Criar um modelo meu a partir de um post que eu gostei | `/conteudo novo modelo:` e mande o print do post junto |
| Analisar o perfil de outra pessoa por print | `/conteudo espiar @perfil` e mande os prints |
| Analisar um perfil a fundo, com os números reais e os comentários, sem print | `/espiao @perfil` (chega no próximo encontro; até lá, `/conteudo espiar @perfil` com prints) |
| Melhorar um texto que eu já escrevi | `/copy melhora esse texto:` e cole o texto |
| Escrever legenda, roteiro de reels ou stories | `/copy` (a capa do reels e os stories em imagem saem depois no `/conteudo montar`) |
| Fechei um aluno novo | 1. `/contrato Nome do aluno` 2. cadastre o aluno no painel (`+ Aluno`) |
| Organizar alunos, renovações, agenda e dinheiro | `/dashboard` |
| Mudar alguma coisa no painel | `/dashboard o que você quer mudar` |
| Não sei qual usar | `/ajuda o que eu quero fazer` |
| Saber onde parei | `/ajuda onde parei?` |

## O caminho de um post

Um post passa por três passos, em duas skills:

1. **/conteudo (pauta):** decide o que postar. Tema, objetivo, formato e o modelo de post. Se for carrossel, pergunta se é para anúncio (até 10 slides) ou para a vitrine (até 20). Grava a `pauta.md`.
2. **/copy (texto):** escreve o texto de cada slide e a legenda. Antes, mostra o cardápio de estruturas de copy para você escolher e pergunta se você tem print de resultado para provar o que vai falar. Grava o `texto.md`.
3. **/conteudo montar (imagens):** pega o texto e monta as imagens com as suas cores e fontes. Pede as fotos e os prints que o modelo precisa. Grava os PNGs prontos para postar.

Quem escreve é o /copy. Quem decide e monta é o /conteudo.

## As skills

### /brain
- **O que faz:** monta e atualiza o seu segundo cérebro: quem você é, seu negócio, sua aluna ideal, sua voz, seus cases.
- **Quando usar:** primeiro de tudo. E sempre que algo mudar no seu negócio.
- **Como chamar:** `/brain` (montar ou continuar), `/brain atualiza: o plano de 6 meses agora custa R$ 1.097`.
- **Não faz:** post, contrato ou painel.
- **Depois dela:** `/design-system`.

### /design-system
- **O que faz:** monta a sua identidade visual: cores, fontes e o jeito das suas peças. Todas as imagens das outras skills saem com ela.
- **Quando usar:** depois do /brain, antes de montar o primeiro post ou o painel.
- **Como chamar:** `/design-system`, `/design-system ajusta: quero o rosa mais vivo`.
- **Não faz:** posts. Ela só define a cara deles.
- **Depois dela:** `/conteudo` para o primeiro post.

### /criador-de-metodo
- **O que faz:** monta o esboço do seu método: até 3 pilares, nome, conceito, inimigo comum e argumentos. Você leva o esboço para o encontro e fecha com o Peraça.
- **Quando usar:** antes do encontro de método.
- **Como chamar:** `/criador-de-metodo`, `/criador-de-metodo fechei: o que ficou decidido`.
- **Não faz:** oferta nem preço.
- **Depois dela:** `/oferta`.

### /oferta
- **O que faz:** monta a oferta do seu Programa Personalizado: entregas, bônus, garantia, preço e nome.
- **Quando usar:** com o método pronto, ou quando for mudar preço ou plano.
- **Como chamar:** `/oferta`, `/oferta ajusta: quero tirar a escassez`.
- **Não faz:** página de vendas nem post.
- **Depois dela:** `/brain atualiza` com o preço novo, se mudou.

### /conteudo
- **O que faz:** quatro coisas. Espiar: analisa o perfil de outra pessoa pelos prints que você manda e te dá ideias. Pauta: decide o que postar e em qual modelo. Montar: transforma o texto do /copy em imagens prontas. Meus modelos: abre o seu banco de modelos e cria modelos seus a partir de um print.
- **Quando usar:** no começo de todo post (pauta) e no fim (montar).
- **Como chamar:** `/conteudo pauta da semana`, `/conteudo pauta: o tema`, `/conteudo espiar @perfil`, `/conteudo montar`, `/conteudo meus modelos`, `/conteudo novo modelo:` com o print.
- **O seu banco de modelos:** fica em `brain/meus-modelos/banco-de-modelos.html` e abre com dois cliques. Os modelos que você cria ficam no brain, por isso não somem quando o Club manda uma atualização das skills.
- **Os 7 modelos de post:** Foto, nicho e headline; Troque isso por isso; Foi assim que; Frase sobre foto; Esse é o segredo; Plano prático; Carrossel tweet.
- **Não faz:** o texto do post. Isso é do /copy.
- **Depois dela:** da pauta, `/copy`. Do montar, é só postar.

### /espiao
- **Quando chega:** no próximo encontro. Até lá, use `/conteudo espiar @perfil` com prints.
- **O que faz:** analisa a fundo até 3 perfis do Instagram, sem print. Puxa pelo Apify os últimos 40 posts com curtidas, comentários e views e os comentários dos posts que mais funcionaram, abre um painel com as capas que mais funcionaram, compara com o seu brain e te dá 5 ideias de post.
- **Quando usar:** quando quiser entender de verdade o que funciona para um concorrente ou uma referência. Para algo rápido, por print, use `/conteudo espiar`.
- **Como chamar:** `/espiao @perfil` ou `/espiao @perfil1 @perfil2`.
- **Precisa de:** uma conta do Apify no plano Free (5 dólares de crédito por mês, sem cartão; dá umas 14 análises). Na primeira vez a skill ensina a criar a conta e guardar a chave, que nunca vai para a conversa.
- **Não faz:** login no Instagram nem perfil privado. Não escreve o post.
- **Depois dela:** `/conteudo pauta: a ideia que você escolheu`, ou `/conteudo novo modelo:` com a capa de um post dela.

### /copy
- **O que faz:** escreve o texto do post na sua voz: slides, legenda, roteiro de reels e stories. Mostra o cardápio de estruturas (PEPO, PCS, PAS, AIDA e outras) e explica cada uma.
- **Quando usar:** depois da pauta do /conteudo, ou para melhorar um texto seu.
- **Como chamar:** `/copy` (ele acha a pauta), `/copy legenda para o post de amanhã`, `/copy melhora esse texto:`.
- **Não faz:** imagens nem página de vendas.
- **Depois dela:** `/conteudo montar`.

### /contrato
- **O que faz:** gera o contrato do aluno do Programa Personalizado, em PDF, com os dados dele.
- **Quando usar:** toda vez que fechar um aluno novo. Uma vez só, use `/contrato integrar` para ligar o seu formulário de cadastro.
- **Como chamar:** `/contrato Nome do aluno`, `/contrato integrar`.
- **Não faz:** cobrança nem cadastro no painel.
- **Depois dela:** cadastre o aluno no painel do `/dashboard`.

### /dashboard
- **O que faz:** monta e ajusta o seu painel de gestão: alunos, renovações, agenda, dinheiro, tarefas e o que fazer hoje, com as suas cores.
- **Quando usar:** para montar o painel (Encontro 1) e sempre que quiser mudar alguma coisa nele.
- **Como chamar:** `/dashboard`, `/dashboard importar`, `/dashboard fico com o visual 1`, `/dashboard põe um aviso quando a aluna faltar 2 vezes`.
- **Não faz:** posts nem contrato.
- **Depois dela:** use o painel todo dia. Uma vez por semana, "Baixar meus dados".

### /ajuda
- **O que faz:** diz qual skill usar e em que ordem, a partir do que você quer fazer. Também olha o seu brain e diz onde você parou.
- **Quando usar:** sempre que ficar em dúvida.
- **Como chamar:** `/ajuda quero fazer um post para anúncio`, `/ajuda onde parei?`, `/ajuda o que faz a /oferta?`.
- **Não faz:** o trabalho das outras skills. Ela aponta o caminho e o comando.

## Ordem recomendada no Club

1. `/brain` (setup, 12/11)
2. `/design-system` (setup, 12/11)
3. `/copy` e `/conteudo` (setup, 12/11; os 7 modelos entraram em 19/11)
4. `/contrato` (setup, 12/11)
5. `/dashboard` (Encontro 1, 19/11)
6. `/espiao` (próximo encontro)
7. `/criador-de-metodo` e `/oferta` (encontros de método e oferta)

## Histórico do pacote

- 19/11/2026: /conteudo com os 7 modelos de post; /copy com o cardápio de estruturas (PEPO, PCS, PAS, AIDA, ADP e História com moral), anúncio ou vitrine e prova com print; banco de modelos de cada aluno (`/conteudo meus modelos` e `/conteudo novo modelo`); skill /ajuda nova; todas as skills terminam com o próximo passo.
- Próximo encontro: skill /espiao nova (análise a fundo pelo Apify).
- 12/11/2026: primeiro pacote do Club.

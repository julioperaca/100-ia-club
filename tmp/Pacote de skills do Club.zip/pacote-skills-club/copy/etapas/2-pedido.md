# Etapa 2. Só o que falta: tema, formato, objetivo, CTA, estrutura, uso e print

Tempo no encontro: 2 minutos.

Objetivo: ter as respostas que o agente de copy da mentoria pede antes de escrever (objetivo, público, dor ou desejo, inimigo, solução, resultado buscado, formato e CTA), perguntando só o que o cérebro e a pauta não responderam. Uma pergunta por vez, menos a Pergunta 4, que junta até 3 perguntas curtas numa mensagem só. No máximo 5 mensagens. Com pauta, a Pergunta 4 costuma ser a única.

O que já vem pronto, sem perguntar:
- público, dor e desejo, resultado buscado: `aluno-ideal.md`
- inimigo e solução: o pilar em `metodo.md`
- tudo que a pauta trouxe

## Pergunta 1. Tema (só sem pauta)

> Sobre o que você quer falar? Pode ser uma dor ou um desejo da tua aluna, um erro que ela comete, uma história que aconteceu. Se preferir, escolho um dos teus temas.

Se ela pedir para você escolher, ofereça 3 opções numeradas, cada uma ligando uma dor ou desejo de `aluno-ideal.md` a um pilar de `metodo.md` (ex.: "1. A barriga que não sai mesmo treinando (pilar Força que Evolui)").

Ache o pilar sozinho: o tema conversa com o inimigo comum de qual pilar? Diga em uma linha qual escolheu.

## Pergunta 2. Formato (só se não veio)

> Vai virar o quê?
> 1. Carrossel
> 2. Reels
> 3. Stories
> 4. Só a legenda
> 5. Só a headline ou o CTA

## Pergunta 3. Objetivo e CTA (só se não veio)

Uma pergunta, já com o CTA dentro:

> No fim, o que você quer que ela faça?
> 1. Te seguir (pra mais conteúdo assim)
> 2. Te mandar mensagem no direct
> 3. Te chamar no WhatsApp

Se a pessoa falar "comentar uma palavra", explique em uma linha que o Peraça não recomenda em perfil pequeno (quase ninguém quer ser o primeiro a comentar) e ofereça o direct. Se ela insistir, faça.

Direct com palavra: use a palavra que ela já usa (veja `voz.md`); se não houver, sugira "QUERO".

## Pergunta 4. Estrutura, uso e print (sempre, numa mensagem só)

Antes de escrever, o aluno escolhe a estrutura do desenrolar. Monte o cardápio assim:
- 2 ou 3 estruturas que combinam com o objetivo (tabela "Qual usar" de `${CLAUDE_SKILL_DIR}/referencias/jeito-do-peraca.md`). Com modelo de post na pauta, a sugerida é a que combina com o modelo (tabela logo abaixo da "Qual usar").
- A sugerida vem primeiro, marcada "(sugerida)".
- Cada uma com uma linha: o que a sigla quer dizer e quando usar. Use as linhas da lista abaixo, sem mudar.

Linhas do cardápio:
- PEPO: Promessa, Erros, Passo a passo, Oferta. Começa no desejo dela, mostra os erros, dá o caminho e convida. Bom para ganhar seguidor novo.
- PCS: Problema, Causa, Solução. Mostra o problema dela, explica por que acontece e diz o que fazer. Bom para fazer pensar e puxar conversa no direct.
- PAS: Problema, Agitação, Solução. Mostra o problema, o que ele custa se continuar e só então a saída. Bom quando ela ainda não viu o tamanho do problema.
- AIDA: Atenção, Interesse, Desejo, Ação. Prende a atenção, dá motivo para continuar lendo, faz querer o resultado e pede uma ação. Bom para post que leva direto a uma ação: avaliação, direct, formulário.
- ADP: Antes, Depois, Ponte. Como a vida dela é hoje, como pode ser e o que liga um ponto ao outro, que é o seu método. Bom para mostrar a mudança de uma aluna e para case.
- História com moral: uma cena real, o que ela mostra e a lição que fica. Bom para criar conexão.

Junte na mesma mensagem, no máximo, mais duas perguntas:
- **Uso**, só se for carrossel e a pauta não disser `Uso:`.
- **Print**, sempre. Só fica de fora se o cérebro já tem o case com o print anotado: aí use.

A mensagem, por exemplo para um carrossel de converter, sem `Uso:` na pauta:

> Antes de escrever, escolhe como eu conto o meio do post:
> 1. PCS (sugerida): Problema, Causa, Solução. Mostra o problema dela, explica por que acontece e diz o que fazer. Bom para fazer pensar e puxar conversa no direct.
> 2. AIDA: Atenção, Interesse, Desejo, Ação. Prende a atenção, dá motivo para continuar lendo, faz querer o resultado e pede uma ação. Bom para post que leva direto a uma ação: avaliação, direct, formulário.
>
> Você pretende usar este post em anúncio ou ele é só para ficar na sua vitrine? Pergunto porque o anúncio aceita no máximo 10 criativos, e o post normal do perfil até 20.
>
> Você tem print de resultado do que vai falar neste post? Mensagem de aluna, antes e depois, avaliação. Ele prova que é verdade.
>
> Pode responder tudo junto, tipo "1, vitrine, não tenho". Se quiser, só "pode ser" que eu sigo com a sugerida.

Como ler a resposta:
- Número ou nome da estrutura: é a da Variação A. A B usa outra da tabela, e a entrega diz qual.
- "Pode ser", "tanto faz" ou sem resposta sobre isso: vai a sugerida.
- Uso: anúncio limita o carrossel a 10 slides; vitrine aceita até 20. Sem resposta: vitrine, e diga isso em uma linha.
- Print: você não salva imagem (esta skill não copia arquivos). Se a pessoa tem o print, o texto marca `Print: pedir (o que o print prova)` e o /conteudo montar pede o arquivo na hora de montar. Se ela já colocou o arquivo na pasta do post, use o nome dele. Se tem mas não mandou agora, o texto marca `Print: pedir (o que o print prova)`. Se não tem, as frases de resultado ficam mais moderadas. Nunca invente resultado.

## Pergunta 5. Contexto real (opcional, uma vez)

Só quando a estrutura escolhida for História com moral, ou quando o tema pedir um gancho de contexto:

> Aconteceu alguma coisa real com isso? Uma mensagem de aluna, uma conversa na academia, algo seu. Se não, eu sigo sem.

Sem resposta ou "não": siga sem história. Nunca invente cena.

## Antes de seguir

Repita o pedido em uma linha, sem pedir confirmação:

> Combinado: [formato] no modelo [modelo] sobre [tema], pilar [pilar], pra [objetivo/CTA], em [estrutura], para [anúncio ou vitrine]. Escrevendo as duas versões.

Siga para a etapa 3.

# copy

Skill para o personal trainer escrever o texto dos conteúdos de Instagram no jeito que o Peraça ensina na mentoria, com a própria voz, sem instalar nada e sem chave de API: carrossel slide a slide, roteiro de reels, sequência de stories, legenda, headline e CTA para o direct ou o WhatsApp. Texto de página de vendas não é desta skill.

## Como usar

No Claude (aba Code), digite `/copy` ou fale "escreve o texto do carrossel", "roteiro do reels", "texto dos stories", "legenda".

Com pauta pronta da skill `conteudo`: `/copy pauta de hoje`. Ela lê a pauta e grava o texto na mesma pasta.

Direto: `/copy reels sobre barriga depois dos 40`.

Para melhorar um texto seu: `/copy melhora esse texto:` e cole o texto.

## Antes

A skill `brain` precisa ter rodado (voz, aluna ideal, planos, cases). O método com pilares (no `metodo.md` do brain) deixa a copy muito mais forte: o inimigo comum e os argumentos de cada pilar viram conteúdo.

## O que ela faz

1. Lê seu cérebro e a pauta, sem te perguntar o que já está lá.
2. Pergunta só o que falta: tema, formato, objetivo e CTA (seguir, direct ou WhatsApp). Antes de escrever, mostra o cardápio de estruturas que combinam com o post, com a sugerida marcada, e, numa mensagem só, pergunta se o post vai para anúncio ou vitrine e se você tem print de resultado.
3. Escreve 2 versões sobre a base de toda copy do Peraça (headline, introdução, desenrolar, conclusão e CTA): a A na estrutura que você escolheu, a B em outra (PEPO, PCS, PAS, AIDA, ADP ou História com moral), seguindo o modelo de post da pauta, com a headline de um modelo das aulas e o `Print:` onde o texto precisa de prova.
4. Confere: anti-IA (sem travessão, sem emoji, sem frase de robô), saúde (nada de quilos ou prazo prometidos) e o jeito do Peraça (tem ação, tem argumento, a solução é o seu método, tem moral).
5. Pergunta "isso parece você?" e ajusta em até 3 voltas, com as suas palavras.
6. Salva em `brain/conteudo/<data>-<tema>/texto.md`, pronto para a skill `conteudo` fazer a arte, e fecha com o próximo passo: "Texto pronto. Agora digite /conteudo montar para fazer as imagens." Headline e CTA soltos vão para `brain/copys/`.

## Instalação

Copie a pasta `copy` para `~/.claude/skills/` (no Windows, `C:\Users\<nome>\.claude\skills\`).

## Arquivos

| Arquivo | Para quê |
|---|---|
| `SKILL.md` | entrada, modos, contratos, regras |
| `etapas/1-ler.md` a `etapas/5-salvar.md` | as 5 etapas |
| `referencias/jeito-do-peraca.md` | as 10 regras, a base de toda copy e as 6 estruturas do desenrolar das aulas do Peraça |
| `referencias/formatos.md` | carrossel, reels, stories, legenda, CTA e o que muda no texto em cada um dos 7 modelos de post |
| `referencias/headlines.md` | os 13 modelos de headline do Peraça, cada um com a campeã de origem |
| `referencias/anti-ia.md` | a conferência final (segurança, 16 itens anti-IA, 5 do jeito do Peraça) |
| `modelos/texto.md` | o formato do `texto.md` e do `variacoes.md` |
| `modelos/copy-salva.md` | o formato de headline e CTA soltos |
